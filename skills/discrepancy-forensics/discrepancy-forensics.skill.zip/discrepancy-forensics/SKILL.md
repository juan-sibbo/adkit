---
name: discrepancy-forensics
description: Analiza discrepancias entre datasets de publisher (GAM), SSP y buyer/DSP. Actívalo cuando el buyer diga que recibe pocos avails, cuando los números no cuadren entre plataformas, cuando haya diferencias inexplicables de impresiones o revenue, o cuando alguien diga "el SSP dice X pero GAM dice Y", "el comprador reporta Z", "no cuadran los números", "discrepancia", "fill más bajo de lo esperado", o "el buyer no ve suficiente inventario". También actívalo para revisar logs OpenRTB o cuando se pida un diagnóstico cerrado de por qué un deal no escala.
---

# Discrepancy Forensics

**Versión:** 1.0.0
**Estado:** Estable
**Última actualización:** 2026-04-27
**Depende de:** gam-adops (contexto de ad units), programmatic-deals (contexto de deals)
**Usado por:** Agente α (Discrepancy Hunter)

> Aísla la causa raíz de discrepancias entre publisher, SSP y buyer.
> Produce hipótesis ordenadas por evidencia y plan de verificación.

---

## Modo de operación

Este skill tiene dos modos según el acceso a datos disponible. Detectar cuál aplica antes de empezar.

### Modo A — Con acceso a datos (logs, exports, APIs)
El usuario tiene al menos dos de los tres datasets: GAM export, SSP UI export, buyer report.
→ Ejecutar el flujo completo de cruce y aislamiento.

### Modo B — Sin logs raw (cuestionario estructurado)
El usuario no tiene exports o el SSP no da acceso a logs.
→ Ejecutar cuestionario dirigido a soporte del SSP para extraer telemetría equivalente.
→ Este modo cubre el 70% de los casos en tier de publisher autonómico.

---

## Flujo Modo A — Cruce de datasets

### Paso 1 — Solicitar los tres datasets

Si no están en el contexto, pedir exactamente estos datos:

```
Para el análisis necesito los tres datasets en el mismo período:

1. GAM (publisher-side):
   - Impresiones servidas
   - Revenue (si aplica)
   - Fill rate
   - Período: [fecha inicio] a [fecha fin], zona horaria GAM

2. SSP UI o export:
   - Bid requests enviados al buyer
   - Wins (impresiones ganadas)
   - Revenue bruto
   - Misma ventana temporal

3. Buyer/DSP report (si disponible):
   - Bid requests recibidos
   - Bids enviados
   - Wins
   - Spend

Adjunta los CSVs o pega los números directamente.
```

### Paso 2 — Normalización

Antes de cruzar, normalizar:

- **Zona horaria:** GAM reporta en la TZ del network. SSPs y DSPs suelen ser UTC. Ajustar todo a UTC.
- **Moneda:** verificar que todos los valores de revenue están en la misma moneda y misma tasa (bruto vs neto).
- **Definición de impresión:** GAM cuenta en render, SSPs en win notification, buyers en impression served. La discrepancia de 5-15% entre estas definiciones es estructuralmente normal.
- **Ventana temporal:** alinear exactamente. Un día desplazado explica discrepancias masivas.

Documentar las normalizaciones aplicadas al inicio del análisis.

### Paso 3 — Calcular divergencias

Calcular las siguientes métricas por par de datasets:

```
Discrepancia GAM vs SSP (impresiones):
  Δ_abs = GAM_impr - SSP_wins
  Δ_pct = (GAM_impr - SSP_wins) / SSP_wins × 100

Discrepancia SSP vs Buyer (bid requests):
  Δ_abs = SSP_bid_requests - Buyer_bid_requests_received
  Δ_pct = (SSP_br - Buyer_br) / SSP_br × 100

Bid rate del buyer:
  bid_rate = Buyer_bids / Buyer_bid_requests_received × 100

Win rate:
  win_rate = SSP_wins / SSP_bid_requests × 100
```

**Umbrales de referencia:**
- Discrepancia GAM vs SSP <15%: estructuralmente normal (definición distinta de impresión)
- Discrepancia GAM vs SSP >25%: anómala — investigar
- Discrepancia SSP vs Buyer >20%: filtrado en el camino — investigar
- Bid rate <1%: buyer casi no puja — problema de targeting/budget/CPM
- Bid rate >50%: buyer muy activo pero aún no gana — problema de floor o competencia

### Paso 4 — Aislar el eje de divergencia

Si los números divergen, determinar si la discrepancia es:

- **Total** (afecta a todo el inventario) → problema sistémico: floor, supply chain, consent
- **Segmentada por geo** → geotargeting del deal demasiado restrictivo o inventario mal mapeado
- **Segmentada por formato** → mediaType no declarado correctamente, creativos rechazados
- **Segmentada por hora del día** → pacing del buyer, frequency caps, budget diario agotado
- **Segmentada por dispositivo** → app-ads.txt, RDID ausente en CTV, player incompatible
- **Segmentada por deal ID** → problema específico del deal, no del inventario general

Para segmentar, pedir al usuario el desglose por dimensión si no está en los exports.

### Paso 5 — Ranking de hipótesis con niveles de evidencia

Producir hipótesis en formato tabular, ordenadas por probabilidad:

```
| # | Hipótesis | Evidencia | Nivel | Test de verificación |
|---|-----------|-----------|-------|---------------------|
| 1 | [hipótesis más probable] | [datos que la soportan] | [Verificado/Probable/Posible] | [acción concreta] |
| 2 | ... | ... | ... | ... |
```

**Niveles de evidencia:**
- **Verificado:** los datos lo confirman directamente
- **Probable:** consistente con los datos, requiere un test adicional para confirmar
- **Posible:** no descartable con los datos disponibles, test necesario
- **Descartado:** los datos lo contradicen

### Paso 6 — Plan de verificación

Para cada hipótesis "Probable" o "Posible", proponer el test más barato en tiempo e información:

```
Test T1 — [nombre]
  Acción: [qué hacer exactamente]
  Duración: [minutos/horas]
  Resultado esperado si confirma: [qué veríamos]
  Resultado esperado si descarta: [qué veríamos]
```

### Paso 7 — Output final

Producir `discrepancy_report.md` con:
- Resumen ejecutivo (3 líneas: magnitud, eje principal, hipótesis más probable)
- Tabla de normalizaciones aplicadas
- Métricas calculadas
- Ranking de hipótesis
- Plan de verificación
- Próximos pasos con propietario

Disparar `knowledge-capture` si la causa raíz queda confirmada.

---

## Flujo Modo B — Cuestionario sin logs

Cuando el usuario no tiene exports o el SSP no da acceso a datos granulares, usar este cuestionario estructurado para dirigir la conversación con soporte del SSP o con el buyer.

### Bloque 1 — Supply chain (verificar primero, siempre)
```
□ ¿El ads.txt/app-ads.txt del publisher incluye al SSP con el seller_account_id correcto?
□ ¿El sellers.json del SSP incluye al publisher como PUBLISHER (no INTERMEDIARY)?
□ ¿El deal está activo en ambos lados (publisher y buyer)?
□ ¿El seat del comprador está autorizado a ver este deal en el SSP?
```

### Bloque 2 — Avails (¿hay inventario que matchee el deal?)
```
□ ¿Cuál es el targeting del deal? (geo, device, format, dominio/bundle, horario)
□ ¿El inventario real del publisher incluye ese targeting?
□ ¿El floor del deal está por encima del floor efectivo en GAM/UPR?
□ ¿Hay competitive exclusions o brand safety que filtren al buyer?
□ ¿Hay frequency caps que limiten el número de requests enviados?
```

### Bloque 3 — Listening (¿el buyer recibe las requests?)
Preguntar al SSP:
```
□ ¿Cuántos QPS se envían al seat del buyer para este deal?
□ ¿Hay filtrado del SSP por QPS limit, timeout o traffic shaping?
□ ¿El buyer tiene este path de supply priorizado en su DSP (SPO)?
```

### Bloque 4 — Bidding (¿el buyer puja?)
Preguntar al buyer o al SSP:
```
□ ¿Cuál es el bid rate del buyer sobre las requests recibidas?
□ Si el bid rate es <5%: ¿motivo de no-bid? (budget, targeting DSP, CPM objetivo, creative)
□ ¿El creative está aprobado en el SSP y en GAM?
□ ¿El budget del comprador está agotado en las horas de mayor tráfico?
```

### Bloque 5 — Delivery (¿la puja gana?)
```
□ ¿Cuál es el win rate?
□ Si wins son bajos: ¿el floor efectivo de GAM es mayor que el bid del buyer?
□ ¿Hay discrepancia entre wins en SSP y impresiones servidas en GAM?
□ Si hay discrepancia: ¿el creative renderiza correctamente tras la win?
```

Con las respuestas al cuestionario, construir el ranking de hipótesis del Paso 5.

---

## Integración con Postman MCP

Cuando esté disponible, usar las colecciones Postman preconfiguradas para ejecutar calls directos a las APIs de SSP y automatizar la recolección de datos:

- Colección `SSP-PubMatic`: endpoint `/report/network/impression` para obtener datos de win rate
- Colección `SSP-Magnite`: endpoint para bid stream summary
- Colección `SSP-Xandr`: `report/analytics` con filtro por deal ID

Invocar con: "ejecuta la colección [SSP] en Postman para el deal [ID] y devuelve los resultados al análisis"

---

## Anti-patterns frecuentes

- **Aceptar el primer síntoma como causa:** "el fill es bajo" no es una causa. Siempre recorrer el funnel completo.
- **Comparar métricas con definiciones distintas:** GAM impresión ≠ SSP win ≠ buyer impression. Normalizar siempre.
- **Ampliar targeting antes de verificar supply chain:** el error más caro. Verificar ads.txt/sellers.json primero.
- **Confundir discrepancia estructural con error:** <15% entre GAM y SSP es normal por diseño.
- **No aislar el eje:** una discrepancia total y una segmentada por geo tienen causas raíz distintas.

---

## Changelog

### v1.0.0 — 2026-04-27
**Tipo:** MAJOR (creación)
**Origen:** Auditoría ecosistema abril 2026 — pain point P2
- Crear: skill inicial con Modo A (datasets) y Modo B (cuestionario)
- Crear: flujo de normalización y cruce de métricas
- Crear: ranking de hipótesis con niveles de evidencia
- Crear: integración futura con Postman MCP
- Crear: anti-patterns documentados
