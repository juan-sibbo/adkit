---
name: incident-response
description: Flujo estructurado de respuesta a incidencias en producción que afecten ad serving. Actívalo ante "incidencia", "caída", "no sirven ads", "fill a cero", "black screen masivo", "error VAST en producción", "rollback urgente", "el cliente reporta que no hay publicidad", "bajada brusca de fill" o cualquier situación de alta presión donde haya que actuar rápido y no cometer errores. Proporciona árbol de decisión, plantillas de comunicación y captura de post-mortem.
---

# Incident Response

**Versión:** 1.0.0
**Estado:** Estable
**Última actualización:** 2026-04-27
**Depende de:** gam-adops, video-adtech, programmatic-deals (para diagnóstico técnico)
**Usado por:** Standalone — se activa en situaciones de alta presión

> Este skill NO hace el diagnóstico técnico — eso lo hacen los skills especializados.
> Este skill gestiona el flujo de respuesta: triage, comunicación, escalado y post-mortem.
> La calidad bajo presión depende de tener el proceso cargado antes de necesitarlo.

---

## Paso 0 — Triage inmediato (primeros 5 minutos)

En cuanto se detecta una incidencia, responder estas 4 preguntas antes de hacer cualquier otra cosa:

```
1. ¿QUÉ está fallando?
   □ Fill a cero o fill anormalmente bajo
   □ Error VAST / black screen / ad no reproduce
   □ Revenue drop sin caída de fill
   □ Discrepancia masiva entre sistemas
   □ Otro: [describir]

2. ¿DÓNDE afecta?
   □ Un cliente específico: [cuál]
   □ Todos los clientes del portfolio
   □ Un dispositivo/entorno específico: [web / Android TV / Samsung / LG / tvOS / HbbTV]
   □ Un SSP específico: [cuál]
   □ Una franja horaria: [cuándo empezó, hora exacta]

3. ¿CUÁNTO es el blast radius?
   □ % de inventario afectado (estimado)
   □ Revenue en riesgo por hora (estimado)
   □ Número de usuarios/viewers afectados (si se puede estimar)

4. ¿CUÁNDO empezó?
   □ Hora exacta de inicio (o aproximada)
   □ ¿Coincide con algún deploy, cambio de configuración o evento externo?
```

Con estas 4 respuestas, activar el árbol de decisión del Paso 1.

---

## Paso 1 — Árbol de decisión: tipo de incidencia

### Rama A — Fill a cero o fill anormalmente bajo

```
¿Afecta a un solo cliente o a todos?
├── Solo un cliente:
│   → Verificar ads.txt/sellers.json del cliente (supply chain)
│   → Verificar si hay cambio reciente en GAM (pricing rule, competitive exclusion)
│   → Activar discrepancy-forensics para análisis rápido
│   → Severidad: MEDIA si <30 min, ALTA si >30 min
│
└── Todos los clientes:
    → Verificar status de GAM (https://www.google.com/appsstatus — Ad Manager)
    → Verificar status del SSP principal (página de status del proveedor)
    → Si problema externo (GAM/SSP) → comunicar y esperar, no hay acción publisher-side
    → Si problema interno → escalar inmediatamente
    → Severidad: CRÍTICA
```

### Rama B — Error VAST / black screen / ad no reproduce

```
¿Es generalizado o en un entorno específico?
├── Generalizado (todos los dispositivos):
│   → Verificar ad tag base: ¿responde el VAST URL?
│   → Verificar si hay wrapper roto (profundidad >5 niveles)
│   → Activar video-adtech para diagnóstico
│   → Severidad: ALTA
│
└── Entorno específico (ej. solo Samsung, solo tvOS):
    → Verificar IMA SDK en ese entorno (versión, compatibilidad)
    → Verificar RDID/señal en ese dispositivo
    → Activar video-adtech para diagnóstico específico de dispositivo
    → Severidad: MEDIA
```

### Rama C — Revenue drop sin caída de fill

```
→ Probable problema de pricing o discrepancia de reporting
→ Activar discrepancy-forensics
→ Verificar cambios en floors de GAM o pricing rules en los últimos 24h
→ Verificar si los SSPs cambiaron floors o deals
→ Severidad: MEDIA-ALTA (puede ser normal — verificar antes de escalar)
```

---

## Paso 2 — Clasificación de severidad y SLA de respuesta

| Severidad | Criterio | Tiempo de respuesta | Comunicación |
|-----------|----------|--------------------| -------------|
| **CRÍTICA** | Fill a cero en todo el portfolio, o pérdida de revenue >€500/h estimada | Inmediata (<5 min) | Cliente + interno |
| **ALTA** | Fill a cero en un cliente importante, o error VAST generalizado | <15 min | Cliente informado en <30 min |
| **MEDIA** | Fill bajo pero no cero, entorno específico, revenue drop moderado | <1 hora | Actualización al cliente en 1-2h |
| **BAJA** | Discrepancia menor, anomalía en reporting, problema que no afecta revenue directo | <4 horas | Solo si el cliente lo pregunta |

---

## Paso 3 — Vías de mitigación (en orden de preferencia)

**Antes de aplicar cualquier mitigación, documentar el estado actual** (screenshot, export de GAM, log del SSP).

### Mitigación 1 — Rollback a configuración anterior
Si el problema coincide con un deploy o cambio de configuración:
```
□ Identificar el cambio exacto (commit, config de GAM, versión de SDK)
□ Revertir el cambio
□ Verificar en 5 min que el fill se normaliza
□ Si no se normaliza → Mitigación 2
```

### Mitigación 2 — Fallback de inventario
Si el problema es en un SSP específico o un tipo de deal:
```
□ Desactivar temporalmente el deal o el SSP afectado en GAM
□ Verificar que el inventario fallback (open auction u otro SSP) está activo
□ Confirmar que el fill sube con el fallback activo
□ Documentar el fallback aplicado para revertirlo cuando se resuelva la causa raíz
```

### Mitigación 3 — Throttling
Si el problema es de capacidad o de un SSP que está enviando tráfico inválido:
```
□ Reducir el QPS al SSP problemático en GAM
□ Activar floor temporal más alto para filtrar tráfico de baja calidad
□ Comunicar al SSP el problema y solicitar diagnóstico desde su lado
```

### Mitigación 4 — Activar inventario de emergencia
Si el fill cae sin solución clara:
```
□ Verificar si hay house ads configuradas como fallback en GAM
□ Activar PSA (Public Service Announcements) como último recurso
□ Confirmar con el cliente antes de activar (puede afectar a la imagen)
```

---

## Paso 4 — Plantillas de comunicación

### Comunicación inicial al cliente (dentro de los primeros 30 min)

```
Asunto: [INCIDENCIA] Anomalía detectada en publicidad — [CLIENTE] — [HH:MM]

Hemos detectado una anomalía en el servicio de publicidad de [CLIENTE]
a partir de las [HH:MM] (hora Madrid).

Estado actual: [descripción breve — ej. "fill rate anormalmente bajo en dispositivos Android TV"]
Impacto estimado: [breve — ej. "aproximadamente 40% del inventario CTV afectado"]
Acción en curso: [qué estamos haciendo — ej. "diagnóstico activo, identificando causa raíz"]

Próxima actualización en 30 minutos.

[firma]
```

### Actualización de progreso (cada 30 min hasta resolución)

```
Asunto: [ACTUALIZACIÓN] Incidencia publicidad — [CLIENTE] — [HH:MM]

Actualización a las [HH:MM]:

Causa identificada: [sí/en progreso/no identificada aún]
[Si identificada]: [descripción en términos no técnicos]

Acción aplicada: [qué se hizo — o "diagnóstico en curso"]
Estado actual: [mejorando / sin cambios / empeorado]

Próxima actualización en [N] minutos.
```

### Comunicación de resolución

```
Asunto: [RESUELTO] Incidencia publicidad — [CLIENTE] — Resuelta [HH:MM]

La incidencia detectada a las [HH:MM] ha sido resuelta a las [HH:MM].

Duración total: [N horas N minutos]
Causa raíz: [descripción clara y no técnica]
Solución aplicada: [qué se hizo]

El servicio de publicidad está funcionando con normalidad.
Impacto estimado: [N impresiones afectadas / €X en revenue]

Prepararemos un informe post-mortem detallado en las próximas 24 horas.

[firma]
```

---

## Paso 5 — Escalado interno

### Cuándo escalar

```
□ Severidad CRÍTICA: escalar inmediatamente a dirección Sibbo
□ Severidad ALTA > 1 hora sin resolución: escalar
□ Causa raíz no identificada tras 45 min de diagnóstico: escalar a soporte del SSP/GAM
□ El cliente está escalando internamente en su organización: adelantarse y escalar también
```

### Contactos de soporte de proveedores

```
GAM/Google:
  - Support portal: https://support.google.com/admanager
  - Para GAM 360: soporte prioritario vía account manager
  - Prioridad: P0 para outages, P1 para incidencias de revenue

PubMatic:
  - Publisher support: [rellenar con contacto del account manager]
  - Abre ticket: [URL del portal de soporte PubMatic]

Magnite:
  - Publisher support: [rellenar]

Xandr:
  - Publisher support: [rellenar]
```

---

## Paso 6 — Post-mortem (dentro de las 24h siguientes)

Usar el template de post-mortem de `client-deliverable` para generar el documento firmable.

Datos mínimos a capturar antes de cerrar la incidencia:

```
□ Línea de tiempo exacta (inicio, detección, diagnóstico, resolución)
□ Causa raíz confirmada (no la hipótesis inicial — la causa real)
□ Blast radius final (impresiones, revenue, duración)
□ Solución aplicada
□ Acciones preventivas (con propietario y fecha)
□ Lecciones aprendidas
```

Disparar `knowledge-capture` con el anti-pattern aprendido si la causa raíz no estaba documentada.

---

## Anti-patterns de incident response

- **Aplicar cambios sin documentar el estado previo:** imposible hacer rollback limpio
- **Comunicar al cliente antes de entender el impacto real:** genera más alarma innecesaria
- **No escalar a tiempo:** el orgullo de resolver solo puede costar horas de revenue
- **Confundir síntoma con causa:** "fill a cero" es síntoma, no causa — siempre buscar la raíz
- **No hacer post-mortem:** la misma incidencia volverá

---

## Changelog

### v1.0.0 — 2026-04-27
**Tipo:** MAJOR (creación)
**Origen:** Auditoría ecosistema — pain point latente P_incident
- Crear: skill inicial con triage, árbol de decisión, mitigaciones y plantillas de comunicación
- Crear: tabla de severidad y SLAs de respuesta
- Crear: template de post-mortem integrado con client-deliverable
