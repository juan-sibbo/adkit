---
name: client-deliverable
description: Convierte hallazgos técnicos de una sesión en deliverables ejecutivos firmables para clientes. Actívalo cuando el usuario diga "informe para el cliente", "deliverable", "presentación de [tema]", "resumen ejecutivo", "post-mortem para [cliente]", "prepara algo para enviar al cliente", "necesito explicar esto al C-level", "draft de email con los resultados", o cuando una sesión técnica concluya y el usuario quiera comunicar los resultados. También activar con "/cerrar [cliente]" al final de una sesión.
---

# Client Deliverable

**Versión:** 1.0.0
**Estado:** Estable
**Última actualización:** 2026-04-27
**Depende de:** fact-checker (modo /verify-deliverable), context-guardian (optimización tokens)
**Usado por:** Agente γ (Deliverable Composer)

> Transforma conclusiones técnicas en documentos ejecutivos firmables,
> calibrados por audiencia y formato, con verificación de claims integrada.

---

## Flujo de ejecución

### Paso 1 — Identificar el material fuente

Extraer del contexto de la sesión:
- Diagnósticos o análisis realizados
- Decisiones técnicas tomadas
- Problemas resueltos o identificados
- Recomendaciones con impacto estimado

Si el material no está claro, preguntar:
```
¿Sobre qué sesión/análisis quieres el deliverable?
Resume los puntos clave en 3-5 líneas y genero el documento.
```

### Paso 2 — Determinar audiencia y formato

Preguntar si no está en el contexto (máximo una pregunta):

```
¿A quién va dirigido y en qué formato?
  a) Técnico del cliente → Markdown / DOCX técnico
  b) C-level / dirección → PPTX ejecutivo / PDF
  c) Mixto → DOCX con resumen ejecutivo + detalle técnico
  d) Slack/email → mensaje estructurado
```

### Paso 3 — Estructurar por nivel de audiencia

**Audiencia técnica (Modo T):**
```
# [Título técnico]
## Contexto
## Hallazgos
## Causa raíz identificada
## Solución aplicada / Recomendación
## Próximos pasos
## Anexo técnico (logs, configs, evidencia)
```

**Audiencia ejecutiva (Modo E):**
```
# [Título ejecutivo — orientado a impacto de negocio]
## Situación (1 párrafo)
## Qué ocurrió / Qué se encontró (sin jerga técnica)
## Impacto en revenue / operativa
## Acción tomada o recomendada
## Resultado esperado / obtenido
## Próximo hito
```

**Mixto (Modo M):**
Estructura ejecutiva en las primeras 2 páginas + anexo técnico separado.

**Slack/email (Modo S):**
```
Asunto/Título: [tema] — [cliente] — [fecha]

[2-3 líneas de contexto]

✓ [resultado o hallazgo principal]
• [detalle 1]
• [detalle 2]

Próximo paso: [acción concreta con fecha]

[Adjunto: nombre del documento si aplica]
```

### Paso 4 — Calibrar tono y terminología

**Para audiencia técnica del cliente:**
- Terminología AdTech estándar: VAST, fill rate, bid rate, RDID, PPID — sin explicar
- Incluir valores exactos, versiones, IDs de deals
- Referencias a logs o evidencia cuando estén disponibles

**Para C-level / dirección:**
- Traducir métricas a impacto: "fill rate subió de 42% a 67%" → "los ingresos programáticos de este bloque aumentaron un 59%"
- Evitar acrónimos sin definir en primera mención
- Orientar a decisión: cada sección debe concluir con una implicación de negocio

### Paso 5 — Verificación de claims (gate obligatorio)

Antes de finalizar cualquier deliverable que salga al cliente, activar el modo `/verify-deliverable` del skill `fact-checker`:

- Identificar todos los claims cuantitativos (porcentajes, impactos estimados, comparaciones)
- Verificar que están soportados por datos de la sesión
- Marcar con `[REVISAR]` los que no pueden confirmarse automáticamente
- No incluir claims especulativos sin etiquetarlos explícitamente como estimaciones

### Paso 6 — Generar el artefacto

Según el formato seleccionado:

**DOCX:** usar skill `docx` para generar documento Word descargable con estilos corporativos
**PPTX:** usar skill `pptx` para generar presentación descargable
**PDF:** usar skill `pdf` si se requiere formato sellado
**Markdown/texto:** generar inline en el chat o como archivo `.md`
**Slack draft:** usar Slack MCP para crear draft en el canal correspondiente

### Paso 7 — Draft de comunicación

Siempre incluir, al final del deliverable, un draft listo para copiar:

```
--- DRAFT [canal] ---
Para: [destinatario]
Asunto: [tema] — [fecha]

[Cuerpo del mensaje en 3-5 líneas máximo]

Adjunto el informe completo.

[firma]
```

---

## Templates por tipo de deliverable

### Post-mortem de incidencia

```markdown
# Post-mortem: [descripción breve] — [cliente] — [fecha]

**Severidad:** Alta / Media / Baja
**Duración de la incidencia:** [HH:MM] ([inicio] → [resolución])
**Impacto estimado:** [N impresiones perdidas / €X en revenue]
**Estado:** Resuelto ✓

## Línea de tiempo
| Hora (CET) | Evento |
|------------|--------|
| [HH:MM] | Detección |
| [HH:MM] | Diagnóstico iniciado |
| [HH:MM] | Causa identificada |
| [HH:MM] | Resolución aplicada |
| [HH:MM] | Verificación de normalización |

## Causa raíz
[Descripción técnica de la causa, una sola oración]

## Solución aplicada
[Qué se cambió/arregló exactamente]

## Acciones preventivas
- [ ] [Acción 1 — responsable — fecha]
- [ ] [Acción 2 — responsable — fecha]

## Lecciones aprendidas
[1-2 puntos concretos para el equipo]
```

### Informe de optimización

```markdown
# Informe de optimización programática — [cliente] — [período]

## Resumen ejecutivo
[2-3 líneas: qué se optimizó, resultado principal]

## Baseline vs resultado
| Métrica | Antes | Después | Δ |
|---------|-------|---------|---|
| Fill rate | X% | Y% | +Z% |
| CPM medio | €X | €Y | +Z% |
| Revenue | €X | €Y | +Z% |

## Cambios realizados
1. [Cambio 1 — fecha — impacto directo]
2. [Cambio 2 — fecha — impacto directo]

## Recomendaciones pendientes
[Próximas acciones con impacto estimado]
```

### Recomendación técnica para C-level

```markdown
# Recomendación: [título orientado a negocio] — [fecha]

## Situación actual
[1 párrafo sin jerga técnica]

## Oportunidad identificada
[Qué se puede mejorar y cuánto vale aproximadamente]

## Acción recomendada
[Qué hacer, en qué plazo, con qué recursos]

## Riesgo de no actuar
[Consecuencia de no implementar en términos de negocio]

## Próximo paso
[Acción concreta, responsable, fecha]
```

---

## Anti-patterns

- **Usar terminología técnica sin traducir en deliverables ejecutivos:** "el bid rate subió" no significa nada para un director de cadena
- **Claims sin soporte:** cualquier número que salga al cliente debe poder trazarse a un dato de la sesión
- **Formato demasiado largo para el canal:** un email de 5 páginas no se lee
- **Olvidar el draft de comunicación:** el documento sin el mensaje que lo acompaña no llega

---

## Changelog

### v1.0.0 — 2026-04-27
**Tipo:** MAJOR (creación)
**Origen:** Auditoría ecosistema abril 2026 — pain point P5
- Crear: skill inicial con flujo de 7 pasos
- Crear: tres modos de audiencia (T/E/M/S)
- Crear: templates para post-mortem, optimización y recomendación ejecutiva
- Crear: integración con fact-checker /verify-deliverable
- Crear: integración con skills de generación de archivos (docx, pptx, pdf)
