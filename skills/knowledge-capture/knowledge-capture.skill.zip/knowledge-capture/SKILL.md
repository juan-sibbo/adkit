---
name: knowledge-capture
description: >
  Skill transversal de meta-aprendizaje. Convierte hallazgos técnicos verificados
  de conversaciones en entradas estructuradas para los skills del ecosistema AdTech
  (gam-adops, prebid-adtech, video-adtech, programmatic-deals, cmp-consent-flows).
  Activación explícita con /aprender, /capturar o /knowledge, o autónoma al detectar
  una resolución técnica verificada en el hilo. Úsalo cuando se resuelve un bug,
  se confirma un comportamiento no documentado, se identifica un anti-pattern nuevo,
  o cuando el usuario dice "guarda esto", "esto hay que recordarlo", "añade esto al
  skill", "nuevo anti-pattern", "lección aprendida", o cualquier variante que indique
  intención de preservar conocimiento. No escribe nada sin aprobación explícita del usuario.
---

# Knowledge Capture — Skill de meta-aprendizaje

Capa de consolidación selectiva de conocimiento técnico verificado. Su función es evitar redescubrir los mismos hallazgos en conversaciones futuras — no acumular memoria, sino destilar lo que merece ser reutilizable.

---

## Triggers de activación

### Explícito
El usuario escribe `/aprender`, `/capturar`, `/knowledge`, "guarda esto", "añade esto al skill", "nuevo anti-pattern", "lección aprendida", o variantes similares.

### Autónomo
Activar cuando se detecten **todos** estos indicadores en el mismo hilo:
1. Se describió un síntoma o problema técnico concreto
2. Se llegó a un diagnóstico con causa raíz identificada (no solo un fix)
3. El hallazgo está validado — al menos uno de estos tres casos:
   - **Fix verificado:** se aplicó y el usuario confirmó que funcionó
   - **Comportamiento verificado:** demostrado por documentación oficial o prueba reproducible
   - **Anti-pattern probable:** patrón sólido pero sin validación en producción — capturable, pero solo en sección diferenciada
4. El hallazgo aporta novedad material: nuevo patrón, refinamiento relevante, o corrección de una entrada existente

Si hay duda sobre si activar autónomamente, **no activar**. Un falso positivo interrumpe el flujo; un falso negativo se puede recuperar con el trigger explícito.

---

## Proceso de captura

### Paso 1 — Escaneo del hilo

Extraer del hilo de conversación:

| Campo | Qué buscar |
|---|---|
| **Síntoma** | El problema tal como lo describió el usuario (comportamiento inesperado, error, discrepancia) |
| **Contexto** | Stack, plataforma, versión, entorno (GAM 360/non-360, Prebid versión, SSP, player) |
| **Diagnóstico** | Causa raíz identificada, mecanismo técnico explicado |
| **Resolución** | Qué cambio o acción lo resolvió |
| **Nivel de evidencia** | Verificado / Probable / Requiere datos (ver tabla abajo) |
| **Skill destino** | A qué skill pertenece el hallazgo (ver tabla de routing) |

Preguntar solo si la ausencia del dato impide clasificar o redactar correctamente. Si no, marcar el campo como *no confirmado* y continuar.

### Paso 1.5 — Test de elegibilidad

Antes de continuar, verificar que el hallazgo cumple **al menos uno** de estos criterios:

- Evita un error recurrente o un rediagnóstico futuro
- Ahorra tiempo de troubleshooting en un patrón no obvio
- Corrige una creencia errónea frecuente
- Documenta una limitación no documentada en fuentes oficiales
- Afecta decisiones de arquitectura o configuración

Si no cumple ninguno, no proponer captura. No es conocimiento reutilizable, es ruido.

Verificar también que **generaliza**:
- **Generaliza:** patrón reproducible en stacks similares → capturar como entrada general
- **Generaliza con condiciones:** válido solo en combinación específica (ej. Prebid 10.x + vídeo + caché) → capturar con condiciones operativas explícitas
- **No generaliza:** caso demasiado local o específico de cliente → no capturar, o capturar como *case note* no como anti-pattern

### Paso 2 — Routing al skill y archivo correctos

Cargar `references/routing-table.md` para determinar destino. Resumen rápido:

| Dominio del hallazgo | Skill destino | Archivo preferido |
|---|---|---|
| Line items, trafficking, delivery GAM, yield management | `gam-adops` | `references/anti-patterns.md` |
| Prebid.js, bid adapters, GPT/JS, TCF desde Prebid | `prebid-adtech` | `references/anti-patterns.md` |
| VAST, IMA SDK, SSAI/DAI, CTV, players | `video-adtech` | `references/anti-patterns.md` |
| Deal setup SSP-side, OpenRTB, sellers.json | `programmatic-deals` | `references/anti-patterns.md` |
| CMP, TCF string upstream, consent latency | `cmp-consent-flows` | `references/anti-patterns.md` |
| Hallazgo que cruza dos skills | Skill principal + mención en el otro | Ambos `anti-patterns.md` |

Ante duda de routing, proponer al usuario y esperar confirmación.

### Paso 2.5 — Deduplicación

Antes de redactar, revisar si el hallazgo ya existe en el archivo destino. Clasificar:

| Clasificación | Acción |
|---|---|
| **Nuevo** | Proceder a redactar entrada completa |
| **Refinamiento** | Proponer ampliar o corregir la entrada existente, no crear otra |
| **Duplicado** | No proponer captura — indicar que ya está documentado |

Si no se puede verificar el contenido del archivo destino, indicarlo antes de continuar.

### Paso 3 — Redactar la entrada

Usar el **formato canónico** definido en `references/entry-format.md`. Nunca inventar formato propio.

Principios de redacción:
- Síntoma en términos del usuario, no reescrito en abstracto
- Causa raíz con mecanismo técnico explicado, no solo el fix
- Resolución accionable: qué verificar, qué cambiar, en qué orden
- Nivel de evidencia etiquetado explícitamente
- Contexto mínimo necesario para que sea reproducible

**Política de no-sobregeneralización:** no elevar un caso local a regla general sin evidencia suficiente. Si el hallazgo depende de condiciones específicas (versión, player, SSP, wrapper), redactarlo con esas condiciones explícitas. Un anti-pattern con condiciones claras es más útil que una regla universal falsa.

### Paso 4 — Aprobación antes de escribir

**Nunca escribir en los archivos de skills sin aprobación explícita.**

Presentar al usuario:
1. La entrada redactada en formato canónico
2. El destino exacto: skill + archivo
3. Una pregunta de confirmación directa

Solo tras "sí", "aprobado", "adelante", o equivalente inequívoco proceder a escribir.

### Paso 5 — Escritura y confirmación

1. Localizar el archivo destino en el skill instalado
2. Añadir la entrada en la sección correcta (ver `references/entry-format.md` para secciones)
3. Confirmar al usuario: qué se escribió, en qué archivo, en qué sección

---

## Niveles de evidencia

| Nivel | Criterio para aplicarlo |
|---|---|
| **Verificado** | El usuario confirmó que la solución funcionó en producción, o el comportamiento está documentado en fuente oficial (GAM Help Center, IAB specs, Prebid docs) |
| **Probable** | El diagnóstico es consistente con la lógica técnica del sistema, pero no fue validado en el caso concreto |
| **Requiere datos** | El hallazgo es plausible pero depende de configuración específica que no fue compartida |

No capturar entradas con nivel "Sin evidencia suficiente" — si no hay base técnica, no pertenece a un anti-patterns.md.

---

## Qué NO capturar

- Comportamientos estándar ya documentados en los skills existentes
- Fixes que son workarounds sin causa raíz identificada
- Hallazgos marcados como "Requiere datos" sin el dato que los confirme
- Hipótesis que no fueron validadas
- Configuraciones específicas de un cliente que no generalizan

---

## Referencias — cuándo cargar cada una

| Referencia | Cuándo cargarla |
|---|---|
| `references/routing-table.md` | Siempre al determinar destino de un hallazgo — especialmente ante casos que cruzan skills |
| `references/entry-format.md` | Siempre antes de redactar una entrada — contiene el formato canónico y ejemplos por tipo |

---

## Formato de salida al usuario

### Activación autónoma detectada

Indicar brevemente que se detectó un hallazgo capturable y proponer la captura sin interrumpir innecesariamente:

> **[knowledge-capture]** He detectado un hallazgo técnico verificado en este hilo. ¿Lo capturo para el skill `[destino]`? Puedo redactar la entrada para tu revisión.

### Presentación para aprobación

```
HALLAZGO DETECTADO
─────────────────
Skill destino:    [nombre del skill] → [archivo]
Tipo de entrada:  [anti-pattern / verified-fix / behavioral-note / debug-note]
Clasificación:    [Nuevo / Refinamiento de entrada existente]

Motivo de captura:   [una línea — qué error futuro evita o qué diagnóstico acelera]
Novedad:             [Nueva entrada / Refinamiento de "[título entrada existente]"]
Generalización:      [General / Con condiciones: especificar / No generaliza: case note]

ENTRADA PROPUESTA:
[entrada en formato canónico]

─────────────────
¿Apruebas esta entrada tal como está, quieres modificarla, o la descartamos?
```

### Confirmación tras escritura

> ✓ Entrada añadida en `[skill]/references/anti-patterns.md` sección `[nombre sección]`.
