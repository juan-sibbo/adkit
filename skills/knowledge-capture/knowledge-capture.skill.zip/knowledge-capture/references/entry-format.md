# Entry Format — Formato canónico de entradas

Cargar antes de redactar cualquier entrada. Contiene la estructura canónica, secciones de cada archivo destino, y ejemplos por tipo de hallazgo.

---

## Tipos de entrada

No todo hallazgo es un anti-pattern. Usar el tipo correcto mantiene la nitidez del archivo destino.

| Tipo | Cuándo usar |
|---|---|
| `anti-pattern` | Configuración o decisión que parece correcta pero causa problemas — el riesgo no es obvio |
| `verified-fix` | Resolución confirmada en producción para un problema concreto con causa raíz identificada |
| `behavioral-note` | Comportamiento documentado de una plataforma/herramienta que no está en la doc oficial o es contraintuitivo |
| `debug-note` | Patrón de diagnóstico: síntomas → herramienta → qué buscar; útil para acelerar troubleshooting futuro |
| `case-note` | Hallazgo real pero demasiado local para generalizar; no va en las secciones principales — sección separada al final del archivo si se captura |

---

## Estructura canónica de una entrada

```markdown
### [Título descriptivo del síntoma — en términos del usuario]

**Tipo:** [anti-pattern / verified-fix / behavioral-note / debug-note / case-note]

**Síntoma:** [Comportamiento inesperado tal como lo experimentó el usuario. 1-2 frases.]

**Contexto:** [Stack mínimo necesario para reproducir: plataforma, versión, entorno, tipo de inventario. Omitir lo que no afecta a la reproducibilidad.]

**Causa raíz:** [Mecanismo técnico que explica el síntoma. No solo "qué" sino "por qué". Si hay ambigüedad, etiquetarla.]

**Resolución:** [Qué cambio resuelve el problema. Accionable y ordenado si hay pasos.]

**Verificación:** [Cómo confirmar que está resuelto — herramienta, log, comportamiento esperado.]

**Nivel de evidencia:** [Verificado / Probable / Requiere datos] — [una línea explicando por qué ese nivel]

**Metadatos:** Capturado: [YYYY-MM] · Versiones: [si aplica] · Vigencia: [Vigente / Pendiente revalidación / Histórico] *(campo opcional — omitir si no hay información de versión relevante)*

**Tags:** [palabras clave para búsqueda: síntoma, plataforma, feature GAM, etc.]
```

---

## Campos obligatorios vs opcionales

| Campo | Obligatorio | Puede omitirse si... |
|---|---|---|
| Síntoma | Sí | — |
| Contexto | Sí | Solo si es 100% agnóstico de plataforma/versión |
| Causa raíz | Sí | — |
| Resolución | Sí | — |
| Verificación | Recomendado | No existe herramienta obvia de verificación |
| Nivel de evidencia | Sí | — |
| Tags | Recomendado | El síntoma ya actúa como tag suficiente |

---

## Secciones de cada archivo anti-patterns.md

Cada `references/anti-patterns.md` tiene secciones. Añadir la entrada en la sección correcta, no al final del archivo sin más.

### gam-adops/references/anti-patterns.md

```
## Delivery y prioridades
## Targeting y ad units
## Creatives y trafficking
## Programmatic yield (PG, PD, PA, Open Bidding)
## Pricing rules y floors
## Discrepancias y reporting
## Troubleshooting tools
## Entornos mixtos display+vídeo
```

### prebid-adtech/references/anti-patterns.md

```
## Configuración de adUnits y bidders
## Auction y timeout
## GPT / googletag integration
## Price granularity y macros
## TCF/CMP desde Prebid
## Bid adapter específicos
## SPA y lazy loading
## User ID modules
```

### video-adtech/references/anti-patterns.md

```
## VAST y VMAP
## IMA SDK
## SSAI / DAI / SGAI
## CTV y Smart TV
## Players (Video.js, JW, Shaka, ExoPlayer)
## Señales de ID en entornos CTV
## Ad pods y frequency en vídeo
```

---

## Ejemplos por tipo de hallazgo

### Ejemplo 1 — anti-pattern (gam-adops)

```markdown
### Sponsorship no entrega en ad unit compartido con price priority activo

**Tipo:** anti-pattern

**Síntoma:** Line item de tipo Sponsorship con targeting a ad unit específico entrega 0 impresiones
durante las primeras horas del vuelo a pesar de tener prioridad teórica máxima.

**Contexto:** GAM non-360. Ad unit con múltiples line items activos incluyendo price priority
con floor CPM competitivo. Sponsorship sin competitive exclusion configurada.

**Causa raíz:** Un price priority con CPM alto puede ganar el auction en GAM antes de que el
Sponsorship sea evaluado si hay un bug de configuración en el roadblocking del Sponsorship
(master sin companion obligatorio). GAM evalúa roadblocking antes de prioridad en ciertos
flujos — si el companion no está disponible, el Sponsorship se descarta y el price priority gana.

**Resolución:**
1. Verificar configuración de roadblocking: si el Sponsorship usa master+companion, comprobar
   que el companion ad unit está declarado en el mismo ad request.
2. Si el inventario es solo display sin companion, eliminar configuración de roadblocking.
3. Añadir label de competitive exclusion al price priority si el Sponsorship debe tener
   exclusividad de página.

**Verificación:** Troubleshoot tab → seleccionar el ad unit afectado → verificar que Sponsorship
aparece como "eligible" y no como "excluded due to roadblocking".

**Nivel de evidencia:** Verificado — reproducido y confirmado en producción.

**Metadatos:** Capturado: 2025-04 · Versiones: GAM non-360 · Vigencia: Vigente

**Tags:** sponsorship, price-priority, roadblocking, companion, delivery-0
```

### Ejemplo 2 — behavioral-note (prebid-adtech)

```markdown
### appnexus bid adapter ignora floor cuando usePrebidCacheKey está activo

**Tipo:** behavioral-note

**Síntoma:** Bids de AppNexus (ahora Xandr) ganan subastas por debajo del floor declarado
en priceFloors module cuando el ad unit tiene video con usePrebidCacheKey: true.

**Contexto:** Prebid.js >= 7.x, módulo priceFloors activo, bid adapter appnexus,
ad unit de tipo video instream.

**Causa raíz:** El adapter AppNexus en modo video con caché activa envía el CPM neto sin
aplicar el floor enforcement del lado del adapter. El floor enforcement de Prebid core
se aplica post-bid, pero si el adapter sobreescribe el CPM en el procesado de la respuesta,
el check puede evaluarse contra el valor incorrecto.

**Resolución:** Desactivar usePrebidCacheKey si no es necesario para el setup de IMA.
Alternativamente, forzar floor enforcement a nivel de Prebid core con
`floors.enforcement.enforceJS: true`.

**Verificación:** Prebid debug mode → filtrar bids de appnexus → comparar cpm vs floor
declarado en priceFloors module para el ad unit afectado.

**Nivel de evidencia:** Probable — patrón observado en dos publishers, no confirmado
como bug documentado en Prebid GitHub.

**Metadatos:** Capturado: 2025-04 · Versiones: Prebid.js >= 7.x · Vigencia: Pendiente revalidación

**Tags:** appnexus, xandr, price-floors, video, prebid-cache, floor-enforcement
```

### Ejemplo 3 — verified-fix (video-adtech)

```markdown
### IMA SDK no dispara AdStarted en Safari iOS 16+ con autoplay bloqueado

**Tipo:** verified-fix

**Síntoma:** En Safari iOS 16+, el evento AdStarted no se dispara aunque el VAST
se carga correctamente y el ad manager inicializa sin error.

**Contexto:** IMA SDK HTML5 versión 3.x, player Video.js 7.x o nativo, iOS 16+,
inventario pre-roll.

**Causa raíz:** Safari iOS 16 endureció las restricciones de autoplay. Si el playback
del contenido no fue iniciado por un gesto del usuario, el ad playback también queda
bloqueado — incluso con `playAdsAfterTime: 0`. IMA SDK no propaga el error como
AdError sino que queda en estado de espera silenciosa.

**Resolución:** Iniciar el ad request dentro del handler del evento `click` o `touchend`
del botón de play del usuario. No iniciar `adsLoader.requestAds()` en el `ready` del player
si no hay gesto del usuario previo.

**Verificación:** Safari Web Inspector → Console → buscar mensajes de política de autoplay.
Probar con gesto explícito del usuario antes de iniciar el player.

**Nivel de evidencia:** Verificado — comportamiento documentado en Apple WebKit bugtracker
y reproducible en Safari iOS 16+.

**Metadatos:** Capturado: 2025-04 · Versiones: IMA SDK 3.x, Safari iOS 16+ · Vigencia: Vigente

**Tags:** ima-sdk, safari, ios-16, autoplay, AdStarted, pre-roll, Video.js
```

---

## Errores comunes a evitar

| Error | Corrección |
|---|---|
| Síntoma en abstracto ("el line item no entrega") | Síntoma en los términos del usuario con contexto mínimo |
| Resolución sin mecanismo ("reinicia el line item") | Explicar por qué funciona la resolución |
| Nivel de evidencia sin justificación | Siempre una línea explicando el nivel |
| Entrada añadida al final del archivo sin sección | Localizar la sección correcta y añadir ahí |
| Tags genéricos ("gam", "prebid") | Tags que reflejan el síntoma específico |
