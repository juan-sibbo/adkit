# Routing Table — Knowledge Capture

Guía para determinar a qué skill y archivo va cada hallazgo. Cargar cuando el dominio del hallazgo no sea inmediatamente obvio o cuando cruce más de un skill.

---

## Tabla de routing por síntoma/dominio

### gam-adops → `references/anti-patterns.md`

Señales de que el hallazgo pertenece aquí:
- El síntoma ocurre en la interfaz de GAM o en reportes de GAM
- La causa raíz está en configuración de line items, prioridades, targeting, creatives, ad rules
- El diagnóstico involucra yield groups, pricing rules, labels, Open Bidding desde GAM
- La discrepancia se analiza desde el lado de GAM (matched requests, unfulfilled, delivery curves)
- Herramientas involucradas: Troubleshoot tab, Ads Inspector, Publisher Console

### prebid-adtech → `references/anti-patterns.md`

Señales:
- El síntoma está en el auction del lado del publisher (browser DevTools, Prebid debug mode)
- La causa raíz está en configuración de Prebid.js (adUnits, bidders, timeout, price granularity)
- Involucra GPT/googletag, macros `hb_pb`, `hb_adid`, `hb_bidder`
- TCF/CMP como consumidor (módulo `consentManagement`, TC string llegando a Prebid)
- Bid adapter específico se comporta diferente a lo documentado

### video-adtech → `references/anti-patterns.md`

Señales:
- El síntoma es visual: black screen, ad no reproduce, player se queda en loading
- VAST response malformado o con error code específico
- IMA SDK no inicializa, evento no dispara, contenido no reanuda
- SSAI/DAI: ad no se inserta, marcadores no reconocidos
- CTV: rdid vacío, señales de ID no llegan, app-ads.txt no válido
- Entorno: Smart TV, Roku, Fire TV, Android TV, HbbTV

### programmatic-deals → `references/anti-patterns.md`

*(Skill en construcción — pre-routing para cuando exista)*

Señales:
- El setup ocurre en la interfaz del SSP (no en GAM)
- OpenRTB deal object, campos `dealid`, `at`, `wseat`, `wadomain`
- Deal no entrega desde el lado del comprador
- sellers.json, ads.txt, app-ads.txt como prerequisito fallido

### cmp-consent-flows → `references/anti-patterns.md`

*(Skill en construcción — pre-routing para cuando exista)*

Señales:
- El CMP (Didomi, Usercentrics, OneTrust) no muestra el banner o lo muestra incorrecto
- TC string malformado o con purposes incorrectos
- Consent latency medible (el auction se lanza antes de que el CMP resuelva)
- A/B test de banner impacta consent rate de forma inesperada
- GPP multi-state: jurisdiction detection falla

---

## Casos de cruce entre skills

| Síntoma | Skill principal | Skill secundario | Criterio |
|---|---|---|---|
| Line item directo compite con bid de Prebid que no debería ganar | `gam-adops` | `prebid-adtech` | Si la causa está en prioridad GAM → gam-adops; si está en price bucket → prebid-adtech |
| Video ad rule en GAM bloquea IMA SDK | `gam-adops` | `video-adtech` | Causa raíz en la regla → gam-adops; causa en el SDK → video-adtech |
| Open Bidding deal no entrega y hay discrepancia con el SSP | `gam-adops` | `programmatic-deals` | Setup GAM del deal → gam-adops; configuración SSP-side → programmatic-deals |
| TCF string llega vacío a Prebid | `cmp-consent-flows` | `prebid-adtech` | Si el CMP no genera la señal → cmp-consent-flows; si Prebid no la lee bien → prebid-adtech |

En cruces: añadir la entrada completa en el skill principal y una entrada de referencia cruzada breve en el secundario.

---

## Formato de referencia cruzada

En el skill secundario, añadir una entrada mínima que apunte al skill principal:

```
### [Síntoma breve] — ver [skill-principal]

**Cross-ref:** Este patrón se documenta en detalle en `[skill-principal]/references/anti-patterns.md`.
**Señal de routing:** [por qué puede confundirse con este skill].
**Causa raíz:** pertenece a [skill-principal] porque [razón de una línea].
```
