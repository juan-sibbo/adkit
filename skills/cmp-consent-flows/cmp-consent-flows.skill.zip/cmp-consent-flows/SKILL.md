---
name: cmp-consent-flows
description: >
  CMP como managed service publisher-side: configuración de plataforma (Didomi con foco
  principal, Usercentrics, OneTrust), vendor list management, purpose/feature mapping TCF,
  construcción de TC string upstream, GPP multi-state, jurisdiction detection, consent
  latency como variable operativa en subastas Prebid y ecosistema programático, diagnóstico
  de signal drop publisher-side, e impacto de configuración CMP en fill rate y revenue.
  Incluye A/B testing de banners de consent. Actívala ante: banner no aparece, TC string
  vacío o malformado, vendors bloqueados inesperadamente, consent rate bajo, subastas
  Prebid lanzadas antes de que el CMP resuelva, propósitos TCF mal mapeados, Didomi
  config, GPP jurisdiction, o cualquier problema upstream del módulo consentManagement
  de Prebid. No cubre: consentManagement en Prebid → prebid-adtech; VAST/IMA → video-adtech;
  deal setup SSP → programmatic-deals.
---

# CMP Consent Flows — Skill publisher-side upstream de Prebid

## Frontera de cobertura

**Cubre:** CMP como plataforma (Didomi, Usercentrics, OneTrust y CMPs agnósticas), vendor list management, purpose/feature/special feature mapping TCF 2.x, construcción y validación del TC string, GPP multi-state string y jurisdiction detection, consent latency como variable operativa, diagnóstico de signal drop entre CMP y Prebid/GAM, impacto de configuración CMP en fill rate, A/B testing de banners de consent.

**No cubre:** consumo del TC string en Prebid (módulo `consentManagement`, `allowAuctionWithoutConsent`, TCF Control Module) → `prebid-adtech`. Consent en contexto CTV o AMP → `video-adtech` / `prebid-adtech`. Deal eligibility y NPA en GAM → `gam-adops`.

**Foco de plataforma:** Didomi como referencia principal — es el CMP predominante en el ecosistema de publishers de este contexto. Los principios son agnósticos de plataforma; las referencias específicas de UI, API y configuración apuntan a Didomi por defecto. Cuando el comportamiento difiera en Usercentrics u OneTrust, se indica explícitamente.

**Indicador:** `[TCF]` para comportamiento específico del framework IAB TCF 2.x. `[GPP]` para Global Privacy Platform. `[Didomi]` para comportamiento específico de esa plataforma.

---

## Postura y nivel de análisis

Análisis técnico de nivel senior con perspectiva de consultoría: el objetivo es identificar el impacto operativo real de las decisiones de configuración CMP, no solo si algo "cumple" técnicamente. Las decisiones de CMP tienen consecuencias directas en revenue — hay que tratarlas como tal.

El usuario conoce el ecosistema programático. No explicar TCF desde cero salvo petición. Sí señalar implicaciones no obvias de configuración, especialmente cuando una decisión que parece "segura" legalmente tiene impacto en fill rate o latencia de subasta.

### Niveles de evidencia

| Nivel | Cuándo aplica |
|---|---|
| **Verificado** | Comportamiento documentado en IAB TCF specs, Didomi docs, o reproducible en la interfaz/API |
| **Probable** | Patrón consistente con la lógica del framework o de la plataforma, sin confirmación directa para el caso concreto |
| **Requiere datos** | No se puede concluir sin TC string real, logs de CMP, o métricas de consent rate |
| **Sin evidencia suficiente** | No hay base para afirmar ni refutar — indicarlo explícitamente |

---

## Modos de operación

### Modo A — Diagnóstico de signal drop o TC string problemático

El síntoma más frecuente: Prebid lanza bids sin consent, vendors reciben señal incorrecta, o la subasta se bloquea esperando al CMP.

1. Emitir hipótesis preliminares si hay base suficiente, etiquetadas con nivel de evidencia.
2. Cargar `references/tcf-signal-flow.md` — contiene el flujo completo desde CMP hasta Prebid/GAM.
3. Identificar en qué punto del flujo se pierde o corrompe la señal.
4. Pedir datos solo si cambiarían el diagnóstico: TC string real (`__tcfapi('getTCData', 2, cb)`), logs de Didomi console, o evento `tcloaded`/`useractioncomplete`.

### Modo B — Revisión de configuración CMP existente

1. Entender el stack completo: CMP vendor + versión, jurisdicción, tipo de inventario, integración con Prebid.
2. Cargar `references/cmp-config.md` — contiene checklist por capa: vendor list, purposes, UI, integración técnica.
3. Identificar riesgos de configuración antes de que impacten en producción o en una auditoría de compliance.
4. Señalar explícitamente cuando una decisión de configuración tiene trade-off revenue/compliance.

### Modo C — Escéptico (revisión de terceros)

Activar cuando el usuario dice "revisa lo que configuró...", "evalúa esta integración de CMP", "¿es correcta esta vendor list?". Tratar como hipótesis. Rehacer razonamiento desde cero. Clasificar cada claim con nivel de evidencia.

### Modo D — Consent latency y optimización de auction timing

Foco en el impacto operativo de la latencia CMP sobre las subastas Prebid y el ecosistema programático.

1. Identificar la fuente de latencia: tiempo de carga del script CMP, tiempo de resolución (nuevo usuario vs returning), lógica de `auctionDelay` en Prebid.
2. Cargar `references/consent-latency.md` — contiene métricas de referencia, estrategias de mitigación y trade-offs.
3. Proponer estrategia según el perfil de tráfico: % usuarios sin cookie, jurisdicción, tipo de dispositivo.

### Modo E — A/B testing de banners

No es modo core pero aplica cuando el usuario quiere optimizar consent rate.

1. Definir la métrica objetivo: consent rate global, consent rate por propósito, o impacto en fill rate programático.
2. Identificar variables a testear: copy, diseño, estructura de propósitos, accept-all vs granular.
3. Cargar `references/ab-testing-consent.md` — contiene metodología, métricas y anti-patterns de diseño de experimentos.

---

## Intake mínimo de diagnóstico

No pedir todo en bloque. Con los datos disponibles, emitir hipótesis y pedir solo lo que resolvería la ambigüedad concreta.

- **CMP vendor y versión** (Didomi SDK versión, Usercentrics UC versión, etc.)
- **TC string real** — extraído via `__tcfapi('getTCData', 2, cb)` en consola
- **Evento CMP** que dispara la integración con Prebid (`tcloaded`, `useractioncomplete`, o custom)
- **Configuración `consentManagement`** en Prebid (timeout, `allowAuctionWithoutConsent`)
- **Jurisdicción activa** — GDPR, CCPA/CPRA, multi-state GPP
- **Vendor list** — versión de GVL usada, vendors custom si los hay
- **Propósitos declarados** — purposes 1-10, special purposes, features, special features
- **Métricas de consent rate** si el problema es de revenue/fill (global y por propósito si disponible)
- **Logs de consola** — errores de CMP, eventos `__tcfapi`, tiempos de resolución

---

## Checks troncales — aplicar siempre

- CMP inicializada y resuelta **antes** de que Prebid lance bid requests — verificar con timeline de `pbjs.getEvents()`
- TC string contiene Purpose 1 (almacenamiento/acceso) si se usan cookies o localStorage en la subasta
- Vendors de SSPs y DSPs relevantes presentes en la vendor list con los purposes correctos declarados
- `consentableData` en Didomi no bloquea vendors que deberían estar activos por defecto `[Didomi]`
- `auctionDelay` en Prebid suficiente para el perfil de usuarios sin cookie (nuevo usuario tarda más que returning)
- Jurisdiction detection correcta — GDPR no debe activarse en tráfico US si no es requerido
- TC string version 2 — no version 1 (deprecada)
- Propósito de medición (Purpose 7/8/9/10) declarado si se usan módulos de User ID en Prebid
- `legitimateInterests` vs `consent` — verificar que el lawful basis declarado coincide con lo que espera cada vendor
- GPP string presente y bien formado si hay tráfico multi-jurisdicción `[GPP]`

---

## TCF — mapa de propósitos y su impacto en el ecosistema programático

Cargar `references/tcf-signal-flow.md` para detalle completo. Tabla de referencia rápida:

| Purpose | Nombre | Impacto si está bloqueado |
|---|---|---|
| 1 | Almacenamiento/acceso en dispositivo | Sin cookies → User ID modules sin datos, frecuencia no controlable |
| 2 | Publicidad básica personalizada | La mayoría de bidders no pujan sin P2 |
| 3 | Perfil personalizado de publicidad | DSPs premium no pujan → CPM cae significativamente |
| 4 | Publicidad personalizada | Mismo impacto que P3, acumulativo |
| 7 | Medición de rendimiento | Analytics y frecuency capping se degradan |
| 9 | Investigación de audiencias | Segmentación de audiencias en SSPs se limita |
| 10 | Desarrollo de producto | Menor impacto directo en revenue |

Special Feature 1 (geolocalización precisa) y Special Feature 2 (fingerprinting activo) — alto impacto en compliance si se activan sin base legal adecuada.

---

## Consent latency — impacto en subastas

La latencia CMP afecta directamente el timing de la subasta Prebid. Hay tres escenarios:

**Escenario 1 — CMP resuelve antes del timeout de Prebid**
Normal. El `auctionDelay` absorbe la espera. Sin impacto en fill.

**Escenario 2 — CMP tarda más que `auctionDelay`**
Prebid lanza la subasta sin consent completo si `allowAuctionWithoutConsent: true`. Los bidders que requieren consent para TCF pueden no pujar o pujar con CPM reducido.

**Escenario 3 — CMP no resuelve (error, bloqueo, script no cargado)**
Si `allowAuctionWithoutConsent: false`, la subasta queda bloqueada indefinidamente. Si es `true`, se lanza sin señal — impacto en compliance y en fill de demanda TCF-compliant.

El valor correcto de `auctionDelay` depende del perfil de tráfico. Cargar `references/consent-latency.md` para metodología de medición y valores de referencia por tipo de usuario y dispositivo.

---

## Referencias — cuándo cargar cada una

| Referencia | Cuándo cargarla |
|---|---|
| `references/tcf-signal-flow.md` | Diagnóstico de TC string, signal drop, vendors bloqueados, flujo CMP→Prebid→GAM |
| `references/cmp-config.md` | Revisión de configuración CMP: vendor list, purposes, UI, integración técnica, Didomi specifics |
| `references/consent-latency.md` | Impacto de latencia CMP en subastas Prebid, métricas, estrategias de mitigación, auctionDelay |
| `references/ab-testing-consent.md` | Diseño de experimentos de consent rate, métricas, anti-patterns |
| `references/anti-patterns.md` | Diagnóstico, revisión de terceros, tabla síntoma → diagnóstico |

---

## Formato de salida

### Modo A — Diagnóstico signal drop

Hipótesis etiquetadas con nivel de evidencia. Formato: `[punto de fallo en el flujo] → [mecanismo] → [cómo verificarlo]`. Pedir solo los datos que cambiarían el diagnóstico.

### Modo B — Revisión de configuración

Secciones: **Stack entendido** · **Riesgos críticos** (compliance + revenue) · **Observaciones importantes** · **Mejoras menores** · **Veredicto** en una frase.

### Modo C — Escéptico

Secciones: **Análisis independiente** · **Comparación crítica** · **Veredicto** · **Checklist de evidencia**: `[claim] → [nivel de evidencia] → [fuente o razonamiento]`.

### Modo D — Consent latency

Diagnóstico del perfil de latencia + impacto estimado en fill + estrategia recomendada con trade-offs explícitos.

### Modo E — A/B testing

Propuesta de experimento: hipótesis · variable · métrica primaria · métrica secundaria · criterio de decisión · riesgos del diseño.
