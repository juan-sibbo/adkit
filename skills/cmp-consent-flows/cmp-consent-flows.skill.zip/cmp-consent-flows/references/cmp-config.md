# CMP Config — Checklist de configuración publisher-side

Foco en Didomi como plataforma de referencia. Los principios son agnósticos; las rutas de UI y parámetros de API son específicos de Didomi salvo indicación contraria.

---

## Checklist por capa

### Vendor list

- [ ] GVL version actualizada — verificar en Didomi dashboard → Vendors → GVL version `[Didomi]`
- [ ] Todos los SSPs y DSPs activos del publisher presentes en la vendor list
- [ ] Vendors que no están en la GVL declarados como vendors custom con purposes correctos
- [ ] Vendors desactivados o legacy eliminados de la lista (reducen confianza del usuario y tamaño del TC string)
- [ ] `legitimateInterests` purposes declarados para vendors que los requieren como lawful basis
- [ ] Vendors de analytics y medición (GA, Adobe, etc.) incluidos si se usan

### Purpose y feature mapping

- [ ] Purposes P1–P4 activos si se hace publicidad personalizada
- [ ] Purposes P7–P10 activos si se usan módulos de medición, User ID, o investigación
- [ ] Special Features (SF1 geolocalización, SF2 fingerprinting) solo activos si hay base legal validada
- [ ] `purposeLegitimateInterests` configurados para publishers que usan LI como lawful basis para P2–P10
- [ ] Purposes no usados desactivados — menos propósitos = menor fricción en el banner = mejor consent rate
- [ ] Stack de propósitos revisado por legal/DPO — no solo por AdOps

### Configuración de regulación `[Didomi]`

- [ ] Regulation GDPR activa para tráfico europeo
- [ ] Jurisdiction detection configurada correctamente — no activar GDPR en tráfico US salvo requerimiento
- [ ] Regulation CCPA/CPRA activa si hay tráfico California
- [ ] GPP habilitado si hay tráfico multi-estado US `[GPP]`
- [ ] `consentableData` no bloquea vendors que deberían estar activos por defecto
- [ ] "Apply publisher restrictions" — verificar que no restringe purposes que el publisher necesita activos

### Configuración de UI / banner

- [ ] Banner aparece en el primer scroll o carga — no retrasado artificialmente (riesgo compliance en GDPR)
- [ ] Botón "Rechazar todo" visible y accesible con el mismo nivel de prominencia que "Aceptar todo" (requisito GDPR)
- [ ] Opción de configuración granular disponible
- [ ] Idioma del banner coincide con el idioma de la página — no solo con la geolocalización
- [ ] Enlace a política de privacidad presente y correcto
- [ ] Banner no bloquea el acceso al contenido (dark patterns — riesgo de sanción)

### Almacenamiento del consent

- [ ] Cookie first-party configurada con dominio raíz del publisher (no subdominio) `[Didomi]`
- [ ] TTL de la cookie suficiente (IAB recomienda 13 meses para GDPR)
- [ ] `euconsent-v2` es la cookie estándar IAB — verificar que es la que se lee en `__tcfapi`
- [ ] `didomi_token` y `didomi_popup_seen` con TTL coherente con la política de consent `[Didomi]`
- [ ] Almacenamiento alternativo en localStorage si las cookies están bloqueadas — verificar que el fallback funciona

### Integración técnica con Prebid

- [ ] Script CMP cargado **antes** de Prebid en el `<head>` — sin defer/async si el timing es crítico
- [ ] Stub `__tcfapi` disponible inmediatamente (antes de que el script CMP completo cargue)
- [ ] `consentManagement` configurado en `pbjs.setConfig` con timeout coherente con la latencia real medida
- [ ] `allowAuctionWithoutConsent` — decisión tomada con criterio legal, no técnico
- [ ] Evento correcto configurado: `tcloaded` para returning users, `useractioncomplete` para nuevos
- [ ] Prebid TCF Control Module cargado si se requiere enforcement de actividades por purposes `[TCF]`

### Integración técnica con GAM/GPT

- [ ] NPA (Non-Personalized Ads) se activa condicionalmente — solo cuando consent no fue dado, no por defecto
- [ ] `setPrivacySettings({ nonPersonalizedAds: true })` solo cuando `purposeConsents[2] === false` o similar
- [ ] Si se usa `googletag.pubads().setRequestNonPersonalizedAds(1)` — verificar que se llama después de que el CMP resuelve, no antes

---

## Didomi — configuración específica de plataforma `[Didomi]`

### Didomi SDK v2 — parámetros clave

```javascript
window.didomiConfig = {
  app: {
    vendors: {
      iab: { all: true },              // Incluir todos los vendors IAB GVL
      include: ['custom-vendor-id'],    // Vendors custom adicionales
    },
    gdprAppliesGlobally: false,        // true solo si el publisher quiere GDPR en todo el tráfico
  },
  consent: {
    duration: 13 * 30,                 // TTL en días (13 meses)
  },
  languages: {
    enabled: ['es', 'en', 'fr'],
    default: 'es',
  },
};
```

### API Didomi — métodos de diagnóstico

```javascript
// Estado del consent de un vendor
window.Didomi.getUserConsentStatusForVendor('vendor-id') // true/false/null

// Estado del consent de un purpose
window.Didomi.getUserConsentStatusForPurpose('cookies') // true/false/null
// Equivalentes IAB: 'iab.1', 'iab.2', etc.

// TC string actual
window.Didomi.getUserConsentToken() // Devuelve el TC string

// Verificar si el usuario ha tomado una acción
window.Didomi.getUserStatus().consent.status // 'pending', 'complete', 'partial'

// Lista de vendors con consent
window.Didomi.getUserStatus().vendors.consent.enabled // array de vendor IDs
```

### Didomi + Prebid — integración recomendada

```javascript
// Esperar a que Didomi esté listo antes de inicializar Prebid
window.didomiOnReady = window.didomiOnReady || [];
window.didomiOnReady.push(function(Didomi) {
  // Didomi está listo — Prebid puede inicializarse
  // El módulo consentManagement de Prebid leerá el TC string via __tcfapi
});
```

Alternativa: confiar en el módulo `consentManagement` de Prebid con `auctionDelay` suficiente — no necesita integración explícita si el script CMP cargó antes que Prebid.

---

## Anti-patterns de configuración frecuentes

### 1. Legitimate interest desactivado globalmente

**Síntoma:** Vendors con lawful basis LI reciben señal de "no consent" aunque el usuario no haya rechazado.

**Causa:** Configuración del CMP que desactiva `legitimateInterests` a nivel global como medida "conservadora". Esto bloquea propósitos que los vendors declaran vía LI, que incluyen muchos DSPs.

**Impacto:** CPM cae en SSPs que requieren P2/P3 vía LI para pujar. Fill rate baja.

### 2. Purposes P1-P4 restringidos por el publisher

**Síntoma:** TC string tiene consent del usuario pero los vendors no reciben los purposes activos.

**Causa:** El publisher ha aplicado "publisher restrictions" en la configuración del CMP que anulan el consent del usuario para ciertos purposes.

**Verificación:** TC string decodificado → campo `publisherRestrictions`. Si está presente con purposes restringidos, esa es la causa.

### 3. Script CMP cargado después de Prebid

**Síntoma:** `__tcfapi` no disponible cuando Prebid inicializa → módulo `consentManagement` falla o lanza sin consent.

**Causa:** Script CMP añadido al final del body o con `defer` mientras Prebid está en el `<head>`.

### 4. Dominio de cookie incorrecto

**Síntoma:** Usuarios returning tratados como nuevos en subdominio diferente al de la cookie.

**Causa:** Cookie de consent guardada en `www.publisher.com` pero el usuario visita `noticias.publisher.com`. La cookie no es accesible en subdominios distintos si no está configurada en el dominio raíz.

**Corrección `[Didomi]`:** Configurar `domain: '.publisher.com'` (con punto inicial) en la configuración de almacenamiento de Didomi.
