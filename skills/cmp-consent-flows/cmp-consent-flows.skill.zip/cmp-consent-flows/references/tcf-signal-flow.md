# TCF Signal Flow — CMP → Prebid → GAM

## El flujo completo

```
Usuario llega a la página
        │
        ▼
[1] Script CMP cargado (async)
        │
        ▼
[2] CMP inicializa → stub __tcfapi disponible
        │
        ▼
[3] ¿Usuario tiene cookie/localStorage con consent previo?
        ├── Sí → [4a] CMP resuelve en <50ms (returning user)
        └── No → [4b] Banner de consent mostrado → espera interacción usuario
                        │
                        ▼
                [4c] Usuario acepta/rechaza/configura
                        │
                        ▼
[5] CMP emite evento tcloaded o useractioncomplete
        │
        ▼
[6] TC string construido y disponible via __tcfapi('getTCData', 2, cb)
        │
        ├──→ [7a] Prebid: módulo consentManagement recibe TC string
        │           └── Si auctionDelay ha expirado: subasta se lanzó sin consent
        │
        ├──→ [7b] GPT/GAM: googletag recibe señal NPA o consent completo
        │
        └──→ [7c] Vendors: cada SSP/DSP recibe TC string en bid request
```

---

## Puntos de fallo por etapa

### [1-2] Script CMP no carga o carga tarde

**Síntomas:** `__tcfapi` no definida en consola, Prebid lanza sin consent, vendors sin señal.

**Causas frecuentes:**
- Script CMP bloqueado por ad blocker o firewall de red corporativa
- Script cargado síncronamente bloqueando el parser → carga tarde → Prebid ya lanzó
- Conflicto con otro script que define `__tcfapi` antes que el CMP real (stub mal implementado)

**Verificación:** `typeof __tcfapi` en consola antes y después de que el script cargue. Si devuelve `undefined`, el script no ha cargado.

### [3-4] Cookie/localStorage de consent no disponible o corrupta

**Síntomas:** Banner aparece en usuarios que deberían ser returning, consent rate artificialmente bajo.

**Causas frecuentes:** `[Didomi]`
- `euconsent-v2` corrupta o con version mismatch (TC string v1 guardado, CMP espera v2)
- Dominio de la cookie incorrecto — cookie guardada en subdominio, no en dominio raíz
- Política SameSite/Secure que impide lectura en contexto de iframe
- ITP en Safari borrando la cookie antes del TTL declarado

**Verificación:** Application tab → Cookies → buscar `euconsent-v2` (IAB) o `didomi_token` / `didomi_popup_seen` `[Didomi]`. Comprobar dominio, expiración y valor.

### [5] Evento CMP no dispara o dispara con datos incorrectos

**Síntomas:** Prebid espera indefinidamente, `tcloaded` nunca llega al módulo `consentManagement`.

**Causas frecuentes:**
- CMP configurada para emitir solo `useractioncomplete` pero Prebid espera `tcloaded`
- CMP en modo "soft opt-in" que marca consent implícito sin emitir el evento correcto
- Race condition: listener de Prebid registrado después del evento → se pierde

**Verificación:**
```javascript
__tcfapi('addEventListener', 2, (tcData, success) => {
  console.log('eventStatus:', tcData.eventStatus);
  console.log('tcString:', tcData.tcString);
  console.log('gdprApplies:', tcData.gdprApplies);
});
```
`eventStatus` debe ser `tcloaded` (returning) o `useractioncomplete` (tras interacción).

### [6] TC string malformado o con purposes incorrectos

**Síntomas:** Vendors reciben señal pero no pujan, CPM cae, adapters Prebid ignoran la subasta.

**Cómo decodificar el TC string:**
- https://iabeurope.eu/tcf-2-0/ → TCF Consent String Decoder
- Librería: `@iabtechlab/consent-string` (npm)
- Didomi console → "TC String" tab `[Didomi]`

**Qué verificar en el string decodificado:**
- `version` = 2 (no 1)
- `gdprApplies` = true si estamos en tráfico europeo
- `purposeConsents` — mapa de purposes con consent dado (1 = granted)
- `purposeLegitimateInterests` — purposes con legitimate interest como lawful basis
- `vendorConsents` — vendors con consent (por ID de GVL)
- `isServiceSpecific` — si es true, el string es válido solo para ese dominio

**Problema frecuente — legitimate interest vs consent:**
Muchos vendors declaran purposes vía legitimate interest (LI) en la GVL. Si el publisher bloquea LI globalmente en la configuración del CMP, esos vendors aparecen como "sin consent" aunque el usuario no haya rechazado activamente. Verificar `purposeLegitimateInterests` además de `purposeConsents`.

### [7a] Prebid recibe TC string pero lanza antes de que esté listo

Ver `references/consent-latency.md` para análisis completo.

**Verificación rápida:**
```javascript
pbjs.getEvents().filter(e => e.eventType === 'auctionInit')
// Comparar timestamp con el evento useractioncomplete del CMP
```

---

## Vendor list — puntos críticos

### GVL (Global Vendor List) versión

El CMP descarga la GVL periódicamente. Si usa una versión antigua:
- Vendors nuevos no aparecen en la UI del banner
- Vendors con purposes actualizados muestran purposes desactualizados
- TC string generado puede no ser válido para vendors que migaron a nuevos purposes

`[Didomi]` — la versión de GVL activa se puede verificar en el dashboard de Didomi → "Vendor list" → "GVL version".

### Vendors custom vs GVL

Los vendors que no están en la GVL deben declararse como vendors custom. Si un SSP o DSP no está en la GVL y no está declarado como vendor custom, no recibirá señal de consent aunque el usuario haya aceptado.

**Anti-pattern frecuente:** publishers que usan un SSP relativamente nuevo (fuera de la GVL) pero no lo han añadido como vendor custom. El SSP opera sin señal TCF y algunos DSPs lo rechazan.

### Propósitos y el mapeo publisher-side

El publisher puede restringir propósitos aunque el usuario los haya aceptado. En Didomi esto se configura a nivel de "regulation" y puede desactivar purposes globalmente. `[Didomi]`

**Verificar que:**
- Los purposes necesarios para la subasta (P1, P2, P3, P4 mínimo) no están restringidos a nivel de configuración de la regulation
- `legitimateInterestsPurposes` declarados para vendors que lo requieren como lawful basis

---

## GPP (Global Privacy Platform)

`[GPP]` — aplica cuando hay tráfico multi-jurisdicción (US estados + GDPR).

**Estructura del GPP string:**
- Header: qué secciones están presentes
- Sección TCF (GDPR): TC string embebido
- Secciones US: CPRA (California), VCDPA (Virginia), etc.

**Jurisdiction detection — cómo funciona:**
La CMP detecta la jurisdicción del usuario (IP geolocation + headers) y activa la regulación correspondiente. Los problemas más frecuentes:

1. **False positive GDPR en tráfico US** — geolocation incorrecta → banner GDPR para usuarios americanos → consent rate bajo innecesariamente
2. **False negative GDPR en tráfico europeo** — lo contrario → compliance risk
3. **Multi-jurisdicción mal manejada** — usuario con VPN que activa dos regulaciones simultáneamente → GPP string malformado

**Verificación de jurisdiction detection:** `[Didomi]`
```javascript
window.Didomi.getUserConsentStatusForPurpose('cookies') // undefined si GDPR no aplica
// vs
__tcfapi('getTCData', 2, (data) => console.log(data.gdprApplies))
```
