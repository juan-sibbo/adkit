# Consent Latency — Impacto en subastas y ecosistema programático

## Por qué la latencia CMP importa en subastas

La subasta Prebid tiene un timeout total (`bidderTimeout`) típicamente de 1000–3000ms. Dentro de ese timeout, el módulo `consentManagement` añade una espera adicional (`auctionDelay`) para que el CMP resuelva antes de lanzar bid requests.

Si el CMP tarda más que `auctionDelay`:
- Con `allowAuctionWithoutConsent: true` → subasta se lanza sin TC string completo → bidders TCF-compliant reciben señal vacía o incompleta → CPM se degrada o no pujan
- Con `allowAuctionWithoutConsent: false` → subasta bloqueada hasta que el CMP resuelve → latencia total de la página se incrementa → riesgo de timeout total

**La latencia CMP no es uniforme** — depende del tipo de usuario y dispositivo:

| Tipo de usuario | Latencia típica | Fuente de variabilidad |
|---|---|---|
| Returning (cookie válida) | 20–80ms | Lectura de localStorage/cookie |
| Returning (cookie expirada) | 100–300ms | Re-fetch de consent previo |
| Nuevo usuario (GDPR) | 500ms–5s+ | Depende de cuándo interactúa |
| Nuevo usuario (no GDPR) | 30–100ms | CMP resuelve sin mostrar banner |
| Safari/ITP | 200–500ms extra | ITP borra cookies → más "nuevos" |
| Mobile lento | 2x–3x desktop | Tiempo de carga del script CMP |

---

## Cómo medir la latencia CMP en producción

### Método 1 — Timeline manual en DevTools

```javascript
// En consola, antes de que la página cargue
const t0 = performance.now();
__tcfapi('addEventListener', 2, (tcData) => {
  if (tcData.eventStatus === 'tcloaded' || tcData.eventStatus === 'useractioncomplete') {
    console.log('CMP resolvió en:', performance.now() - t0, 'ms');
    console.log('eventStatus:', tcData.eventStatus);
  }
});
```

### Método 2 — Correlación con pbjs.getEvents()

```javascript
// Después de la subasta
const events = pbjs.getEvents();
const auctionInit = events.find(e => e.eventType === 'auctionInit');
const firstBidRequested = events.find(e => e.eventType === 'bidRequested');

console.log('Auction init:', auctionInit?.ts);
console.log('First bid requested:', firstBidRequested?.ts);
// Si hay gap > auctionDelay configurado → CMP tardó más de lo esperado
```

### Método 3 — Didomi SDK events `[Didomi]`

```javascript
window.didomiOnReady = window.didomiOnReady || [];
window.didomiOnReady.push(function(Didomi) {
  console.log('Didomi ready at:', performance.now());
  Didomi.on('consent.changed', function(e) {
    console.log('Consent changed at:', performance.now());
  });
});
```

### Método 4 — RUM / Analytics

Instrumentar en producción con eventos custom:
- `cmp_resolved` con dimensiones: `eventStatus`, `gdprApplies`, `tiempo_ms`, `tipo_usuario` (returning/new)
- Correlacionar con `auction_started` y con métricas de fill rate

---

## Estrategias de mitigación por escenario

### Escenario A — Mayoría de tráfico returning (>70%)

**Síntoma:** Latencia media baja pero percentil 95 alto (los nuevos usuarios elevan la cola).

**Estrategia:** `auctionDelay` calibrado para returning users (200–400ms). Para nuevos usuarios, aceptar que la primera subasta puede lanzarse sin consent completo si `allowAuctionWithoutConsent: true`. El revenue en primera sesión es menor de todas formas.

**Trade-off:** Compliance risk si se activa `allowAuctionWithoutConsent: true` en jurisdicción GDPR estricta. Decisión legal, no técnica.

### Escenario B — Alto % de tráfico nuevo (publishers de noticias virales, redes sociales)

**Síntoma:** Latencia media alta, fill rate bajo en primera visita.

**Estrategias por orden de impacto:**

1. **Optimizar tiempo de carga del script CMP** — cargar CMP lo antes posible en el `<head>`, antes que Prebid. Nunca defer/async si puede evitarse para la CMP.

2. **Precargar la decisión de consent** — si el publisher puede asumir que usuarios fuera de GDPR no necesitan banner, configurar jurisdiction detection para no mostrar banner en tráfico no-GDPR. Reduce drásticamente la latencia para esos usuarios.

3. **Soft opt-in / implied consent** — en jurisdicciones donde está permitido, la CMP puede resolver con un consent "implícito" antes de la interacción del usuario. Reduce latencia a <100ms. Requiere validación legal.

4. **Scroll/click como trigger de banner** — retrasar el banner hasta que el usuario interactúa reduce la fricción percibida pero no reduce la latencia de subasta (la subasta sigue esperando).

5. **`auctionDelay` adaptativo** — no existe nativamente en Prebid, pero puede implementarse con lógica custom: si la cookie de consent ya existe, reducir `auctionDelay`; si no, usar el valor largo. Requiere código custom antes de `pbjs.setConfig`.

### Escenario C — Safari / ITP dominante (publishers Apple-heavy, iOS)

**Síntoma:** Consent rate aparentemente normal pero latencia alta y fill bajo en Safari.

**Causa:** ITP borra cookies de terceros y puede borrar localStorage antes del TTL → más usuarios tratados como nuevos → banner más frecuente → latencia más alta.

**Estrategia:** Almacenar consent en cookie first-party con dominio explícito del publisher. `[Didomi]` Didomi soporta almacenamiento en cookie first-party — verificar que está configurado y que el dominio coincide con el dominio raíz (no subdominio).

### Escenario D — CMP script como single point of failure

**Síntoma:** Cuando la CDN de la CMP tiene incidencia, la subasta queda bloqueada o se lanza sin consent.

**Estrategia:** Configurar un timeout máximo en `consentManagement` de Prebid (distinto del `auctionDelay` — es el timeout absoluto). Si se supera, Prebid actúa según `allowAuctionWithoutConsent`. Tener definida una política clara para este caso.

---

## Métricas de diagnóstico de consent latency

| Métrica | Qué indica | Umbral de alerta |
|---|---|---|
| P50 latencia CMP | Experiencia del usuario mediano | >300ms merece investigación |
| P95 latencia CMP | Experiencia del percentil problemático | >2000ms → fill rate en riesgo |
| % subastas sin TC string | Subastas que arrancaron antes de CMP | >5% → auctionDelay insuficiente |
| Fill rate returning vs new | Impacto de consent en monetización | >20% de diferencia → optimizable |
| Consent rate por propósito | Qué propósitos bloquean los usuarios | P2 < 60% → CPM se degrada significativamente |

---

## Interacción con módulos de User ID en Prebid

Los módulos de User ID (ID5, LiveRamp, UID2, SharedID) requieren Purpose 1 para acceder a cookies/localStorage. Si el TC string no tiene P1 granted:

- Los módulos no pueden leer ni escribir identificadores → bid requests sin user ID → CPM reducido
- `auctionDelay` debe ser suficiente para que tanto el CMP como los módulos de User ID resuelvan

**Timing crítico:**
```
CMP resuelve (TC string con P1)
        → User ID modules leen/escriben identificadores
                → Prebid lanza bid requests con user IDs
```

Si el `auctionDelay` es correcto para el CMP pero insuficiente para que los User ID modules resuelvan después, los bids se lanzan sin identificadores. Verificar con `pbjs.getUserIds()` que los IDs están presentes antes del primer `bidRequested`.
