# A/B Testing de Consent — Metodología y métricas

El A/B testing de banners de consent es un área donde el impacto en revenue es significativo pero los riesgos de diseño del experimento son altos. Una mejora de consent rate del 10% puede traducirse en un incremento de fill rate programático sustancial.

---

## Métricas objetivo

### Métrica primaria (elegir una)

| Métrica | Cuándo usarla |
|---|---|
| **Consent rate global** (% usuarios que aceptan al menos P1-P4) | Cuando el objetivo es maximizar fill programático |
| **Consent rate por propósito** (% usuarios que aceptan cada purpose) | Cuando hay purposes específicos que bloquean vendors de alto valor |
| **Revenue por sesión en usuarios nuevos** | Cuando el objetivo es impacto directo en negocio, no en tasa de consent |

### Métricas secundarias (medir siempre)

- **Bounce rate tras banner** — un banner más agresivo puede mejorar consent rate pero aumentar abandono
- **Tiempo hasta interacción con el banner** — indica fricción percibida
- **% usuarios que eligen configuración granular** vs aceptar/rechazar todo — indica nivel de sofisticación
- **Consent rate por dispositivo** — mobile y desktop pueden reaccionar muy diferente al mismo diseño

---

## Variables a testear — por impacto típico

### Alto impacto
- **Copy del botón principal** — "Aceptar todo" vs "Entendido" vs "Continuar" puede mover 5-15% de consent rate
- **Prominencia del botón "Rechazar"** — reducir su visibilidad mejora consent rate pero es dark pattern en GDPR (riesgo regulatorio)
- **Estructura: accept-all vs granular como primera opción** — mostrar granular primero reduce consent global pero mejora consent en propósitos específicos

### Impacto medio
- **Número de propósitos declarados** — menos propósitos = menos fricción = mayor consent rate
- **Copy del cuerpo del banner** — lenguaje técnico vs lenguaje llano
- **Posición del banner** — bottom bar vs modal vs top bar

### Impacto bajo (pero fácil de testear)
- **Colores y diseño** — raramente mueve más del 2-3%
- **Idioma automático vs forzado** — impacto en tráfico multi-idioma

---

## Diseño del experimento

### Criterios mínimos de validez

1. **Aleatorización correcta** — la asignación A/B debe ser por usuario (persistent), no por sesión ni por pageview. Un usuario debe ver siempre la misma variante.

2. **Segmentación limpia** — separar el análisis por:
   - Nuevos vs returning (los returning tienen consent previo — no verán el banner)
   - Jurisdicción (GDPR vs no-GDPR)
   - Dispositivo (mobile vs desktop)

3. **Tamaño de muestra suficiente** — para detectar diferencias de 5% en consent rate con 80% de potencia estadística, se necesitan ~3.000–5.000 usuarios nuevos por variante. Calcular antes de lanzar.

4. **Duración mínima** — al menos 2 semanas completas para capturar variación día/semana. Los lunes y domingos se comportan diferente.

5. **Una variable por experimento** — no cambiar copy + diseño + estructura simultáneamente. Si el experimento gana, no sabrás qué funcionó.

### Anti-patterns de diseño de experimento

**Split por pageview en lugar de por usuario**
El mismo usuario puede ver variante A en una visita y variante B en otra. Contamina los datos y puede generar usuarios que interactúan con ambas variantes.

**No excluir usuarios returning con consent previo**
Estos usuarios no ven el banner — incluirlos en el análisis diluye el efecto real del experimento.

**Medir solo consent rate, no impacto en revenue**
Un banner que mejora consent rate pero aumenta bounce rate puede ser negativo en términos de revenue. Siempre correlacionar con fill rate y RPM.

**Parar el experimento demasiado pronto (peeking)**
Si el experimento muestra resultados positivos a los 3 días, la tentación es pararlo. Hacerlo antes del tamaño de muestra calculado produce falsos positivos. Usar corrección de Bonferroni o metodología bayesiana si se necesita monitoreo continuo.

---

## Impacto esperado en el ecosistema programático

La relación entre consent rate y revenue no es lineal. Los propósitos tienen distinto peso:

| Escenario de consent | Impacto estimado en CPM programático |
|---|---|
| P1+P2+P3+P4 granted | Línea base — 100% |
| Solo P1+P2 | -30% a -50% (DSPs premium no pujan sin P3/P4) |
| Solo P1 | -70% a -80% (publicidad no personalizada solamente) |
| Sin consent (NPA) | -85% a -95% (solo demand no personalizada) |

Estas cifras son orientativas y varían significativamente por vertical, audiencia y mix de demanda. Medir el impacto real en el propio ecosistema antes de tomar decisiones de configuración basadas en benchmarks de terceros.
