# Anti-patterns — CMP Consent Flows

Tabla síntoma → diagnóstico para diagnóstico rápido. Ampliar con entradas de knowledge-capture.

---

## Signal drop y TC string

### TC string vacío en bid requests aunque el usuario aceptó

**Tipo:** anti-pattern

**Síntoma:** Los adaptadores Prebid envían bid requests sin TC string o con `gdprApplies: false` en tráfico europeo donde el usuario sí interactuó con el banner.

**Contexto:** Stack con Prebid.js + módulo consentManagement + Didomi o similar. Ocurre especialmente en primera carga.

**Causa raíz:** Race condition — Prebid lanza la subasta antes de que el módulo `consentManagement` recibe el evento `tcloaded` de la CMP. Esto ocurre cuando el script CMP se carga después de Prebid o cuando `auctionDelay` es 0 o muy bajo.

**Resolución:**
1. Verificar que el script CMP se carga antes que Prebid en el HTML.
2. Aumentar `auctionDelay` en `consentManagement` a un valor que refleje la latencia real medida (ver `references/consent-latency.md`).
3. Verificar con `pbjs.getEvents()` que `auctionInit` ocurre después del evento `tcloaded`.

**Verificación:** `__tcfapi('getTCData', 2, cb)` en consola → `tcString` debe estar presente y no vacío.

**Nivel de evidencia:** Verificado — patrón documentado y reproducible.

**Metadatos:** Capturado: 2025-04 · Versiones: Prebid.js >= 5.x, TCF 2.x · Vigencia: Vigente

**Tags:** tc-string, race-condition, auctionDelay, consentManagement, signal-drop

---

## Configuración de vendor list

### Vendors activos en la subasta no reciben señal de consent

**Tipo:** anti-pattern

**Síntoma:** Un SSP o DSP nuevo no puja o puja sin señal TCF. El publisher asume que el vendor está configurado pero no aparece en el TC string como vendor con consent.

**Contexto:** Vendor incorporado recientemente al stack. No está en la GVL o fue añadido después de que la vendor list del CMP se configuró.

**Causa raíz:** El vendor no está en la vendor list activa del CMP. Puede ser porque: (1) no está en la GVL y no fue añadido como vendor custom, o (2) está en la GVL pero la vendor list del publisher no fue actualizada para incluirlo.

**Resolución:**
1. Verificar si el vendor está en la GVL (iabeurope.eu/vendor-list/).
2. Si está en GVL: actualizar la vendor list del CMP para incluirlo. `[Didomi]` En Didomi → Vendors → buscar por nombre o ID.
3. Si no está en GVL: añadir como vendor custom con los purposes correspondientes declarados por el vendor.

**Nivel de evidencia:** Verificado.

**Metadatos:** Capturado: 2025-04 · Vigencia: Vigente

**Tags:** vendor-list, gvl, custom-vendor, signal-drop, new-ssp

---

## Consent latency

### Subastas lanzadas sin consent en usuarios nuevos con `allowAuctionWithoutConsent: true`

**Tipo:** behavioral-note

**Síntoma:** En análisis de logs, un % de subastas (especialmente de usuarios nuevos) se lanza con TC string vacío o sin `purposeConsents`. Los bidders TCF-compliant devuelven no-bid o CPM reducido.

**Contexto:** Publisher con tráfico europeo significativo, alto % de usuarios nuevos o Safari/ITP, `allowAuctionWithoutConsent: true` en config Prebid.

**Causa raíz:** Comportamiento esperado cuando `auctionDelay` expira antes de que el usuario interactúe con el banner. No es un bug — es una decisión de configuración con implicaciones de compliance y revenue.

**Resolución:** No hay una resolución única — es un trade-off:
- Aumentar `auctionDelay` → más usuarios esperan → mejora fill pero incrementa latencia de página
- Reducir fricción del banner → más usuarios aceptan más rápido → reduce ventana de subasta sin consent
- Revisar si `allowAuctionWithoutConsent: true` es la política correcta con el equipo legal

**Nivel de evidencia:** Verificado — comportamiento documentado en Prebid docs.

**Metadatos:** Capturado: 2025-04 · Vigencia: Vigente

**Tags:** consent-latency, allowAuctionWithoutConsent, new-users, auction-timing, compliance

---

## Legitimate interest

### CPM cae después de activar "máxima privacidad" en la configuración del CMP

**Tipo:** anti-pattern

**Síntoma:** El publisher activa una opción de "máxima privacidad" o "modo conservador" en el CMP y el CPM programático cae significativamente aunque el consent rate no haya cambiado.

**Causa raíz:** La opción de "máxima privacidad" desactiva `legitimateInterests` globalmente para todos los purposes. Muchos vendors (especialmente DSPs) usan LI como lawful basis para P2-P7. Al desactivar LI, reciben señal negativa para esos purposes aunque el usuario no haya rechazado activamente.

**Resolución:**
1. Decodificar el TC string antes y después del cambio — comparar `purposeLegitimateInterests`.
2. Identificar qué vendors usan LI como lawful basis para los purposes afectados.
3. Evaluar con legal si desactivar LI globalmente es un requisito o una elección.
4. Si es una elección, cuantificar el impacto en CPM antes de mantenerlo activo.

**Nivel de evidencia:** Verificado — mecanismo documentado en TCF 2.x spec.

**Metadatos:** Capturado: 2025-04 · Versiones: TCF 2.x · Vigencia: Vigente

**Tags:** legitimate-interest, CPM-drop, publisher-restrictions, tcf, lawful-basis
