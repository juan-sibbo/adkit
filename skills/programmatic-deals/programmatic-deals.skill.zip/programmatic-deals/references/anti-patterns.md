# Anti-patterns — Programmatic Deals (publisher-side)

Entradas organizadas por escalón del funnel. Cada entrada en formato knowledge-capture.

---

## Escalón 3 — Inventario elegible insuficiente

### AP-PD-301
- **Tipo:** Anti-pattern
- **Síntoma:** Deal activo, buyer confirmado listening, pero spend muy por debajo del volumen prometido comercialmente
- **Contexto:** PMP o PG negociado con volumen estimado "alto", buyer empieza a comprar pero a un ritmo muy inferior al esperado
- **Causa raíz:** El forecast o la expectativa comercial se basó en inventario amplio del publisher. El deal quedó restringido a una combinación estrecha de formato + geo + device + ad unit + domain que en realidad representa una fracción pequeña de ese inventario. El buyer escucha correctamente, pero hay muy poco que comprar.
- **Resolución:** Solicitar avail estimate al SSP con exactamente los filtros del deal (no una estimación general). Comparar con el volumen prometido. Si hay gap → renegociar el scope del deal o ampliar el targeting.
- **Verificación:** Avail estimate del SSP con filtros exactos << volumen prometido
- **Nivel de evidencia:** Verificado
- **Tags:** `avails`, `forecasting`, `mismatch-comercial`, `supply`, `PMP`, `PG`

### AP-PD-302
- **Tipo:** Anti-pattern
- **Síntoma:** Deal en SSP correcto, pero el buyer "no ve suficientes requests" y el SSP tampoco ve muchas pujas
- **Contexto:** Publisher con inventario en varios SSPs; deal creado en el SSP incorrecto para el inventario objetivo
- **Causa raíz:** El inventario del publisher que realmente le interesa al buyer vive en un SSP diferente al donde se configuró el deal. El deal está tecnicamente activo pero apuntando al sitio equivocado.
- **Resolución:** Identificar en qué SSP vive realmente el inventario objetivo (por volumen, por floor, por tipo de formato) y mover o replicar el deal ahí.
- **Verificación:** Avails en el SSP donde está el deal son mínimos; avails en el SSP correcto son significativos
- **Nivel de evidencia:** Probable
- **Tags:** `avails`, `SSP-selection`, `supply`, `multi-SSP`

---

## Escalones 4–5 — Activación buyer / supply path

### AP-PD-401
- **Tipo:** Anti-pattern
- **Síntoma:** Deal activo en SSP, cero pujas, buyer dice que "lo está mirando" o "lo tienen en setup"
- **Contexto:** Deal PMP o PG recién activado, cualquier buyer/DSP
- **Causa raíz:** El deal está en estado "Pending" o "Saved" en el DSP del buyer — configurado pero sin un insertion order o line item activo con presupuesto apuntando a él. El SSP no puede ver el estado interno del DSP. "Lo tenemos activado" no siempre significa lo mismo para el SSP y para el buyer.
- **Resolución:** Pedir al buyer screenshot o confirmación explícita de: (1) deal en estado "Active" — no solo "added", (2) line item / IO activo con budget asignado que apunta al deal, (3) fechas del line item del buyer coinciden con las del deal.
- **Verificación:** Buyer confirma estado con evidencia → empiezan a aparecer pujas en <2h
- **Nivel de evidencia:** Verificado
- **Tags:** `activación-buyer`, `DSP`, `pending`, `TTD`, `DV360`, `Xandr`

### AP-PD-402
- **Tipo:** Anti-pattern
- **Síntoma:** El SSP ve bid requests con el deal ID correctamente, pero el buyer dice que "no recibe requests" o "el volumen es muy bajo"
- **Contexto:** Cualquier combinación SSP/DSP
- **Causa raíz:** El buyer está targetando el SSP pero no el seat correcto, o el exchange/supply source no está habilitado en el DSP para ese publisher. El deal llega al buyer solo si el buyer está escuchando exactamente ese seat en ese SSP. Un DSP puede tener múltiples integraciones con el mismo SSP.
- **Resolución:** Confirmar con el buyer el seat ID exacto con el que el SSP está enviando el deal. Comparar con el seat que el buyer tiene configurado. Para TTD: verificar Merchant ID. Para DV360: verificar que el deal está asociado al IO correcto que tiene esa fuente de inventario habilitada.
- **Verificación:** Buyer actualiza seat o supply source → volumen de requests sube en UI del buyer
- **Nivel de evidencia:** Verificado
- **Tags:** `activación-buyer`, `seat-id`, `supply-path`, `TTD`, `DV360`, `exchange`

### AP-PD-403
- **Tipo:** Anti-pattern
- **Síntoma:** Deal activo, buyer escucha, pero el SSP reporta muy pocos bid requests enviados al buyer (el problema está antes del buyer)
- **Contexto:** Deal con targeting muy específico en el SSP
- **Causa raíz:** El targeting del deal en el SSP está filtrando casi todo el inventario antes de enviar requests al buyer. Geo demasiado específico, ad unit restringido a uno solo, domain list demasiado corta, o horario limitado. El buyer nunca ve suficiente inventario porque el SSP no se lo ofrece.
- **Resolución:** Revisar el targeting del deal en el SSP y ampliar gradualmente los filtros más restrictivos. Pedir al SSP el breakout de impresiones elegibles por parámetro de targeting para identificar cuál está cortando más.
- **Verificación:** Ampliación de targeting → aumento de bid requests enviados al buyer → aumento de pujas
- **Nivel de evidencia:** Verificado
- **Tags:** `targeting`, `supply`, `bid-requests`, `SSP-config`

### AP-PD-404
- **Tipo:** Anti-pattern
- **Síntoma:** Deal ID confirmado en el SSP, buyer dice que lo tienen configurado, pero no aparecen pujas; al cruzar el ID carácter a carácter hay discrepancia
- **Contexto:** Cualquier SSP con Deal IDs alfanuméricos (especialmente Triplelift, Magnite, IX, PubMatic); también en deals comunicados por email o PDF
- **Causa raíz:** El Deal ID copiado incluye un espacio al final, un guión largo en lugar de corto, una mayúscula incorrecta, o un carácter especial alterado por el cliente de correo. Los Deal IDs son case-sensitive y la mayoría de SSPs no hacen normalización — un carácter diferente es un ID diferente.
- **Resolución:** Pedir al SSP el Deal ID en texto plano sin formato (no PDF, no email con HTML). Compartirlo con el buyer en el mismo formato. Pedir al buyer que confirme el ID copiado directamente desde su DSP.
- **Verificación:** Buyer muestra el Deal ID tal como está en su DSP → comparar carácter a carácter con el del SSP
- **Nivel de evidencia:** Verificado
- **Tags:** `deal-id`, `formato`, `case-sensitive`, `activación-buyer`

### AP-PD-405
- **Tipo:** Anti-pattern
- **Síntoma:** Deal activo, seat correcto, bid requests llegan al buyer, pero el buyer no puja en dominios específicos del publisher (el problema es selectivo por dominio)
- **Contexto:** Buyers que usan domain allowlists o app bundle allowlists en su DSP (frecuente en TTD, DV360, Xandr); publisher con subdominios, dominios de marcas o dominios internacionales que no estaban en el deal original
- **Causa raíz:** El buyer tiene una allowlist de dominios o app bundles en su DSP que no incluye el dominio exacto desde el que llega el bid request. Los dominios nuevos, subdominios, o variantes internacionales (e.g., `marca.es` vs `marca.com`) no aparecen en la whitelist del buyer aunque el publisher los considere parte del mismo inventario.
- **Resolución:** (1) Pedir al SSP el breakout de dominios en los bid requests del deal. (2) Confirmar con el buyer si tiene allowlist activa y si esos dominios están incluidos. (3) Coordinar con el buyer para añadir los dominios que faltan, o ajustar el targeting del deal para excluir dominios que el buyer no acepta.
- **Verificación:** Buyer actualiza su allowlist → aparecen pujas en los dominios antes bloqueados
- **Nivel de evidencia:** Probable
- **Tags:** `allowlist`, `domain-whitelist`, `app-bundle`, `TTD`, `DV360`, `buyer-side`

### AP-PD-406
- **Tipo:** Anti-pattern
- **Síntoma:** Deal con fechas aparentemente correctas, pero el buyer reporta que "el deal no está activo cuando intenta comprar" o hay ventanas de entrega inesperadamente cortas
- **Contexto:** Deals entre publisher y buyer en zonas horarias distintas; frecuente en deals con publishers españoles/europeos y buyers con operaciones en UTC o US timezones
- **Causa raíz:** El deal se configuró con fechas en la timezone del SSP (habitualmente UTC) pero el buyer interpretó las fechas en su timezone local, o viceversa. Un deal que empieza el 1 de enero a las 00:00 UTC ya lleva una hora activo para un buyer en CET, pero un deal que termina el 31 de diciembre a las 23:59 CET ya ha expirado en UTC. La diferencia puede hacer que el deal parezca inactivo en los momentos de mayor tráfico del publisher.
- **Resolución:** Confirmar con el SSP en qué timezone están configuradas las fechas del deal. Comunicar al buyer las fechas equivalentes en su timezone. Si hay discrepancia, ajustar las fechas del deal.
- **Verificación:** Timezone del SSP confirmada → fechas recalculadas → buyer confirma que coinciden con sus expectativas
- **Nivel de evidencia:** Probable
- **Tags:** `timezone`, `fechas`, `activación-buyer`, `UTC`, `CET`

---

## Escalón 6 — Buyer puja pero poco o a CPMs bajos

### AP-PD-601
- **Tipo:** Anti-pattern
- **Síntoma:** Bid rate bajo, el buyer puja ocasionalmente pero a CPMs consistentemente por debajo del floor
- **Contexto:** PMP con floor configurado en el SSP
- **Causa raíz (a):** Floor calculado sobre CPM neto (revenue publisher) pero comunicado al buyer como CPM bruto — o al revés. La diferencia del fee del SSP crea una discrepancia sistemática. El buyer cree que está pujando por encima del floor, pero el SSP aplica el floor sobre una base diferente. Ejemplo: floor de €3.00 neto con fee del SSP del 20% → el buyer necesita pujar €3.75 bruto para superar el floor, pero si le dijeron "el floor es €3.00" pujará €3.10 y perderá sistemáticamente.
- **Causa raíz (b):** El floor no es competitivo con el mercado real para ese inventario en ese buyer. El buyer tiene una bid ceiling interna más baja que el floor del deal.
- **Resolución (a):** Confirmar con el SSP si el floor configurado es neto o bruto. Recalcular el floor equivalente en la base que usa el buyer. Comunicar al buyer el floor en la misma base que usa el SSP para evaluar las pujas.
- **Resolución (b):** Verificar CPMs de mercado para ese inventario (open auction o deals similares). Ajustar el floor o renegociar con el buyer.
- **Verificación:** Win rate cercano a cero con muchas pujas registradas en el rango de CPM esperado
- **Nivel de evidencia:** Probable
- **Tags:** `floor`, `CPM`, `neto-bruto`, `win-rate`, `pricing`

### AP-PD-602
- **Tipo:** Anti-pattern
- **Síntoma:** Buyer puja bien en bid rate, win rate aceptable, pero spend total es bajo
- **Contexto:** Deal con volumen potencial alto pero spend real mucho menor
- **Causa raíz:** El buyer tiene un presupuesto diario bajo asignado al deal, pacing restrictivo, o frequency caps agresivos que limitan el número de impresiones por usuario. El deal funciona técnicamente pero está limitado por parámetros internos del DSP del buyer.
- **Resolución:** Pedir al buyer confirmación explícita de: budget diario asignado al deal, pacing configurado, frequency cap si aplica, y si hay KPI goals (e.g., CTR, viewability) que están frenando el spend por performance. Algunos DSPs (Amazon DSP, DV360, TTD) exponen bid loss reason codes en sus reportes — pedir al buyer que los comparta si los tiene disponibles: códigos de frequency limit, viewability threshold, o audience mismatch son diagnóstico directo sin necesidad de inferir.
- **Verificación:** Buyer revisa parámetros internos → spend sube en 24-48h; o bid loss reason codes identifican la restricción exacta
- **Nivel de evidencia:** Probable
- **Tags:** `budget`, `pacing`, `frequency-cap`, `DSP-internals`, `bid-loss-reasons`, `buyer-side`

---

## Escalones 7–9 — Delivery / Creative / GAM

### AP-PD-701
- **Tipo:** Anti-pattern
- **Síntoma:** SSP reporta wins correctamente, pero GAM no registra impresiones para ese deal
- **Contexto:** Cualquier deal con line item correspondiente en GAM
- **Causa raíz:** El line item PG/PD en GAM está en paused, tiene el deal ID mal mapeado, o el yield group no tiene al SSP/buyer como fuente elegible. El SSP gana la subasta, pero GAM rechaza la impresión o no la asocia al line item correcto.
- **Resolución:** Verificar en `gam-adops`: (1) line item activo con deal ID correcto, (2) yield group activo con el SSP como fuente, (3) discrepancia entre wins del SSP y impresiones en GAM como señal de diagnóstico.
- **Verificación:** GAM Ads Inspector en una page view con el deal activo — confirmar si el creative del deal está siendo servido
- **Nivel de evidencia:** Verificado
- **Tags:** `GAM`, `line-item`, `yield-group`, `discrepancia`, `gam-adops`

### AP-PD-702
- **Tipo:** Anti-pattern
- **Síntoma:** Deal activo, buyer confirmado listening con pujas, pero cero o muy pocas impresiones entregadas
- **Contexto:** Cualquier SSP con proceso de creative review; especialmente frecuente en formatos no estándar (native, outstream, skin, high impact)
- **Causa raíz:** La creative del buyer no ha pasado el proceso de revisión editorial del SSP, está rechazada por motivos de ad quality, o está bloqueada por categorías de contenido. El SSP gana la subasta pero bloquea la impresión antes de servirla. No siempre hay notificación activa al publisher — el deal simplemente no entrega sin explicación aparente.
- **Resolución:** Verificar en el panel del SSP el estado de la creative asociada al deal. Si está en "pending review" o "rejected", identificar el motivo y coordinar con el buyer para corregirla o escalar con el account manager del SSP.
- **Verificación:** Panel de creatives del SSP → estado de aprobación; motivo de rechazo si lo hay
- **Nivel de evidencia:** Verificado
- **Tags:** `creative-review`, `ad-quality`, `brand-safety`, `native`, `outstream`

**SSPs con creative review obligatorio o frecuente:**

| SSP | Formatos afectados | Tiempo típico de revisión | Notas |
|---|---|---|---|
| Triplelift | Native (todos) | 24-72h | Revisión editorial obligatoria antes de primera entrega |
| Teads | Outstream vídeo, inRead | 24-48h | Revisión de calidad de vídeo y landing page |
| Xandr | Display, vídeo, native | 24-48h | Ad quality automático + revisión manual si hay flags |
| PubMatic | Display, vídeo | 24h | Brand safety automático; categorías bloqueadas por publisher |
| Magnite | Display, vídeo, CTV | 24h | Brand safety automático; algunos publishers tienen listas propias |
| Adagio | Display, outstream | 24-48h | Revisión de attention-compatibility del formato |

### AP-PD-703
- **Tipo:** Anti-pattern
- **Síntoma:** SSP registra win correctamente, GAM no registra impresión, no hay error de renderizado obvio en la página — el win "desaparece" entre el SSP y GAM
- **Contexto:** Cualquier deal, especialmente en inventario con SafeFrame activo o restricciones de cross-domain en el publisher
- **Causa raíz:** El SSP inyecta un wrapper de tracking o renderizado (JS, iframe, pixel) que el contenedor de GAM bloquea o no ejecuta. SafeFrame restringe el acceso al DOM y a recursos externos — un wrapper que funciona en open iframe falla en SafeFrame sin error visible para el publisher. También ocurre cuando el SSP inyecta recursos desde dominios no autorizados por la CSP del publisher (Content Security Policy).
- **Resolución:** (1) Forzar el renderizado del creative del deal en una página de test con las mismas condiciones (SafeFrame / friendly iframe). (2) Abrir DevTools → Network → buscar recursos bloqueados (403/404) o errores CORS/CSP. (3) Buscar errores de JS cross-domain en la consola. (4) Si el problema es SafeFrame: coordinar con el SSP para que el creative sea compatible, o evaluar si el ad unit puede servirse en friendly iframe para ese deal específico.
- **Verificación:** Test de renderizado en página aislada → error JS o recurso bloqueado identificado en DevTools
- **Nivel de evidencia:** Verificado
- **Tags:** `creative-wrapper`, `SafeFrame`, `CSP`, `renderizado`, `discrepancia`, `SSP-GAM`

---

## Escalón 10 — Problema comercial, no técnico

### AP-PD-1001
- **Tipo:** Anti-pattern
- **Síntoma:** Deal técnicamente correcto en todos los escalones, buyer escucha y puja, pero el spend total es persistentemente bajo semanas después de la activación
- **Contexto:** PMP o PG firmado, setup completo, pero sin escalada de volumen
- **Causa raíz:** El buyer aceptó el deal comercialmente pero sin compromiso real de volumen, o estaba haciendo un test limitado. El problema no es técnico — es un mismatch entre lo que el publisher entendió del deal y la intención real del buyer. Esto pasa con frecuencia en deals firmados bajo presión comercial o en buyers que "están probando el inventario".
- **Resolución:** Separar validación técnica (el deal funciona) de validación comercial (el buyer tiene intención de gastar). Escalar a la conversación comercial: ¿cuál es el presupuesto real asignado? ¿Hay un objetivo de CPM o de performance que no se está alcanzando? ¿El buyer está esperando ver mejoras en alguna métrica antes de escalar?
- **Verificación:** El problema desaparece cuando se clarifica el commitment comercial — no cuando se hace un cambio técnico
- **Nivel de evidencia:** Verificado
- **Tags:** `comercial`, `compromiso-buyer`, `test`, `mismatch`, `no-técnico`

### AP-PD-1002
- **Tipo:** Anti-pattern
- **Síntoma:** Buyer escala en otros publishers similares pero no en este
- **Contexto:** Deal PMP con buyer activo en el mercado
- **Causa raíz:** El buyer tiene alguna restricción específica para el publisher: brand safety, categorías de contenido bloqueadas, viewability o attention score por debajo de su threshold, o simplemente el inventario no está teniendo buen performance (CTR, conversiones) y el DSP está optimizando away.
- **Resolución:** (1) Verificar con el SSP si hay motivos de rechazo de creative o brand safety específicos para el publisher. (2) Pedir al buyer si tiene metrics de performance del inventario de este publisher vs. otros. (3) Si es DSP con optimización automática: el buyer puede necesitar ajustar su bidding strategy o dar más tiempo al algoritmo.
- **Verificación:** Buyer comparte performance data → se identifica la métrica que está fallando
- **Nivel de evidencia:** Probable
- **Tags:** `brand-safety`, `performance`, `viewability`, `attention`, `DSP-optimization`

---

## Supply chain — checks laterales (prerrequisitos)

### AP-SC-001
- **Tipo:** Anti-pattern
- **Síntoma:** Deal no entrega con DV360 o The Trade Desk aunque parece correctamente configurado en el SSP
- **Contexto:** Cualquier deal, buyers con validación estricta de ads.txt
- **Causa raíz:** ads.txt no incluye la línea correcta para el SSP (account ID incorrecto, ausente, o dominio mal escrito). DV360 y TTD tienen validación estricta — rechazan silenciosamente el inventario si no pasa.
- **Resolución:** Verificar `https://[publisher-domain]/ads.txt`, buscar la línea del SSP, confirmar account ID con el SSP dashboard. Corregir y esperar 24-48h para re-crawleo.
- **Verificación:** ads.txt validator → línea del SSP ausente o con account ID incorrecto
- **Nivel de evidencia:** Verificado
- **Tags:** `ads.txt`, `DV360`, `TTD`, `supply-chain`, `prerequisito`

### AP-SC-002
- **Tipo:** Anti-pattern
- **Síntoma:** Deal activo en Xandr, cero entrega, todo parece correcto
- **Contexto:** Deal con Xandr como SSP o Xandr como buyer DSP
- **Causa raíz:** El member ID del publisher en Xandr no coincide con el seller_id declarado en ads.txt. Xandr valida la cadena de supply de forma estricta — un mismatch bloquea el deal silenciosamente.
- **Resolución:** Verificar en el panel de Xandr el member ID del publisher → confirmar que coincide con la línea en ads.txt (`appnexus.com, [member_id], DIRECT`) y con sellers.json de Xandr.
- **Verificación:** Corregir ads.txt con el member ID correcto → propagación 24-48h → deal empieza a entregar
- **Nivel de evidencia:** Verificado
- **Tags:** `Xandr`, `member-id`, `ads.txt`, `supply-chain`
