# Supply Chain — Prerrequisitos de deal health

Este archivo cubre los cimientos que deben estar en orden **antes** de entrar en el funnel del deal. Si alguno de estos prerrequisitos falla, el diagnóstico del deal en sí es estéril.

---

## Check 0 — Higiene de privacidad / TCF v2.2

El prerrequisito más invisible. Si el inventario no emite señales de consentimiento válidas, el inventario programático es invisible para buyers Tier-1 — especialmente DV360 — independientemente de cómo esté configurado el deal.

**Qué verificar:**
- El bid request incluye `regs.ext.gdpr=1` y `user.ext.consent` con un TC string válido y no vacío
- El TC string incluye consentimiento para **Propósito 1** (almacenamiento y acceso a información en el dispositivo) — sin él, la mayoría de DSPs descartan el bid request antes de evaluar el deal
- El CMP está disparando correctamente y el TC string llega a Prebid / al ad server antes de que se lance la subasta

**Síntoma de fallo:** el buyer no puja en ningún deal del publisher, o el bid rate cae drásticamente en tráfico europeo (GDPR scope) sin cambios de configuración. El problema es transversal — no específico de un deal.

**Dónde diagnosticar en profundidad:** → `cmp-consent-flows`

**Regla práctica:** si el síntoma afecta a todos los deals y a todo el tráfico programático, verificar TCF antes de entrar en el funnel del deal. Si el síntoma es específico de un deal o un buyer, el TCF probablemente no es la causa.

---

## Check 1 — ads.txt / sellers.json / supply chain

Un deal mal configurado en ads.txt o sellers.json no produce un error explícito — simplemente el comprador no puja o el SSP rechaza las bid responses silenciosamente. Es el prerrequisito de deal health más frecuentemente ignorado.

**Regla práctica:** antes de diagnosticar el deal object o el DSP, verificar supply chain. Un ads.txt incompleto bloquea deals completamente en buyers con validación estricta (la mayoría de DSPs tier-1).

---

## ads.txt — Publisher Authorized Digital Sellers

### Formato de línea ads.txt

```
[dominio SSP], [publisher account ID / seller ID], [tipo de relación], [TAGs Certification ID opcional]
```

Ejemplo:
```
google.com, pub-1234567890123456, DIRECT, f08c47fec0942fa0
rubiconproject.com, 12345, DIRECT, 0bfd66d529a55807
triplelift.com, 10000-EB, DIRECT
appnexus.com, 9876, RESELLER
```

### Campos obligatorios

| Campo | Descripción | Valores válidos |
|---|---|---|
| Dominio SSP | Dominio canónico del SSP exactamente como aparece en sellers.json | Verificar en sellers.json del SSP |
| Account ID | Publisher ID en el SSP — el que el SSP usa para identificarte | Obtener desde el SSP dashboard |
| Tipo de relación | `DIRECT` si el publisher tiene acuerdo directo con el SSP; `RESELLER` si hay intermediario | Casi siempre `DIRECT` para publisher |
| TAGs ID | ID de certificación IAB opcional — mejora confianza pero no obligatorio | Obtener de ads.txt TAGs lookup |

### Errores frecuentes en ads.txt para deals

| Error | Síntoma | Diagnóstico |
|---|---|---|
| Account ID incorrecto | Deal no entrega con buyers que validan ads.txt | Comparar con el ID en el dashboard del SSP |
| Dominio SSP mal escrito | Validadores no encuentran la línea | `rubiconproject.com` ≠ `rubicon.com` |
| Relación como `RESELLER` cuando debería ser `DIRECT` | Algunos buyers rechazan inventory RESELLER para deals directos | Verificar con el SSP |
| Línea ausente para un SSP con deal activo | Deal completamente bloqueado en buyers con validación estricta | Añadir línea correcta |
| ads.txt vacío o inaccesible (error 404/500) | Todos los buyers con validación strict rechazan el inventario | Verificar accesibilidad desde URL del publisher |

### Herramientas de verificación
- [ads.txt validator IAB](https://iabtechlab.com/ads-txt/) — verificación oficial
- [ads.txt crawler Google](https://adstxt.guru/) — herramienta de terceros
- Directamente: `https://[dominio-publisher]/ads.txt`

---

## sellers.json — SSP Authorized Sellers

sellers.json lo mantiene el **SSP**, no el publisher. El publisher no puede editarlo directamente — debe coordinar con el SSP si hay errores.

### Estructura relevante

```json
{
  "sellers": [
    {
      "seller_id": "12345",
      "name": "Publisher Name",
      "domain": "publisher.com",
      "seller_type": "PUBLISHER",
      "is_confidential": 0
    }
  ]
}
```

### Campos críticos para deals

| Campo | Descripción | Impacto en deals |
|---|---|---|
| `seller_id` | ID del publisher en el SSP — debe coincidir con el account ID en ads.txt | Discrepancia bloquea validación supply chain |
| `domain` | Dominio canónico del publisher | Buyers validan que coincide con el site del bid request |
| `seller_type` | `PUBLISHER`, `INTERMEDIARY`, o `BOTH` | Debe ser `PUBLISHER` para relación directa |
| `is_confidential` | `1` = SSP no publica nombre/dominio del publisher | Algunos buyers rechazan sellers confidenciales para deals |

### Diagnóstico sellers.json

1. Localizar la URL sellers.json del SSP (normalmente `https://[ssp-domain]/sellers.json`)
2. Buscar el `seller_id` que aparece en el ads.txt del publisher
3. Verificar que `domain` coincide con el dominio del publisher
4. Verificar `seller_type: PUBLISHER`
5. Si `is_confidential: 1`, coordinar con el SSP para hacerlo público — bloquea deals con algunos compradores

**URLs sellers.json de SSPs frecuentes:**
- Google AdX: `https://storage.googleapis.com/adx-rtb-dictionaries/sellers.json`
- Magnite: `https://rubiconproject.com/sellers.json`
- Triplelift: `https://triplelift.com/sellers.json`

---

## app-ads.txt — Para inventario de aplicaciones

Mismo formato que ads.txt pero alojado en el dominio del desarrollador de la app (no de la app store). El comprador valida que el bundle ID de la app corresponde al desarrollador declarado en el store y que el desarrollador tiene ads.txt correcto.

**Ruta:** `https://[developer-domain]/app-ads.txt`

**Requisito adicional:** el developer domain debe estar declarado en la ficha de la app en Google Play / App Store para que los compradores puedan encontrarlo.

**Diagnóstico específico app-ads.txt:**
1. Verificar que el bundle ID del bid request coincide con la app en el store
2. Verificar que el store tiene el developer domain correcto
3. Verificar que el developer domain tiene app-ads.txt accesible
4. Verificar que la línea del SSP en app-ads.txt tiene el account ID correcto

---

## SupplyChain object (OpenRTB schain)

El SupplyChain object viaja en el bid request para que el comprador pueda verificar la cadena de reventa. Para publishers con relación directa con el SSP, la cadena debe tener exactamente un nodo.

```json
"schain": {
  "complete": 1,
  "ver": "1.0",
  "nodes": [
    {
      "asi": "rubiconproject.com",
      "sid": "12345",
      "hp": 1
    }
  ]
}
```

| Campo | Descripción |
|---|---|
| `complete` | `1` = la cadena está completa desde el publisher hasta el SSP |
| `asi` | Dominio del SSP — debe coincidir con ads.txt y sellers.json |
| `sid` | Seller ID en el SSP — debe coincidir con ads.txt |
| `hp` | `1` = este nodo está pagando al publisher |

**Diagnóstico schain para deals:**
- Si `complete=0`, algunos buyers rechazan el bid request
- Si `sid` no coincide con ads.txt, la validación falla
- Si hay más de un nodo para una relación directa publisher → SSP, revisar la cadena de reventa

---

## Checklist supply chain antes de diagnosticar el deal object

- [ ] ads.txt accesible en `https://[publisher-domain]/ads.txt` (HTTP 200)
- [ ] Línea del SSP presente con dominio correcto, account ID correcto, `DIRECT`
- [ ] sellers.json del SSP incluye al publisher con `seller_type: PUBLISHER`
- [ ] `seller_id` en sellers.json coincide con account ID en ads.txt
- [ ] `domain` en sellers.json coincide con el dominio del publisher
- [ ] `is_confidential: 0` en sellers.json (o coordinar con SSP si es `1`)
- [ ] Para apps: app-ads.txt accesible, developer domain en el store correcto
- [ ] schain en bid requests con `complete=1` y un solo nodo para relación directa
