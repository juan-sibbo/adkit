# OpenRTB Deal Object — Referencia técnica

## Deal object en OpenRTB 2.x (dentro de `pmp`)

```json
{
  "pmp": {
    "private_auction": 1,
    "deals": [
      {
        "id": "DEAL-ID-AQUI",
        "at": 1,
        "bidfloor": 5.00,
        "bidfloorcur": "USD",
        "wseat": ["seat-id-buyer"],
        "wadomain": ["advertiser.com"],
        "ext": {}
      }
    ]
  }
}
```

---

## Campos del deal object — obligatorios y opcionales

| Campo | Tipo | Obligatorio | Descripción |
|---|---|---|---|
| `id` | string | **Sí** | Deal ID único — debe coincidir exactamente con el configurado en el DSP |
| `at` | integer | Recomendado | Tipo de auction: `1` = first price, `2` = second price, `3` = fixed price (PG) |
| `bidfloor` | float | Recomendado | Floor del deal en CPM — buyers por debajo de este valor son descartados |
| `bidfloorcur` | string | Recomendado | Moneda del floor — por defecto USD si no se especifica |
| `wseat` | array[string] | Opcional | Seat IDs de buyers autorizados — si vacío, cualquier buyer puede pujar |
| `wadomain` | array[string] | Opcional | Dominios de anunciante autorizados |
| `ext` | object | Opcional | Extensiones propietarias del SSP |

**Campo crítico para PG:** `at=3` (fixed price) es obligatorio en deals PG. Si llega `at=1` o `at=2`, el comprador puede ganar por debajo del precio acordado.

---

## `private_auction` en el objeto `pmp`

| Valor | Significado |
|---|---|
| `0` | Open auction — el deal ID da acceso preferencial pero el inventario también es open |
| `1` | Private auction — solo los buyers con deal ID configurado pueden pujar |

**Anti-pattern frecuente:** configurar `private_auction=1` en un deal PMP y no incluir el deal ID correcto en `wseat`, lo que bloquea todas las pujas incluyendo las del buyer objetivo.

---

## Extensiones frecuentes por SSP

### Google AdX / Open Bidding
Google no usa el campo estándar `pmp.deals` en Open Bidding — el deal se gestiona íntegramente desde GAM a través de la configuración del yield group y el line item PG/PD. El deal ID no viaja en el bid request estándar de la misma forma.

- En Open Bidding, el targeting del deal se configura en GAM (`gam-adops`)
- Diagnóstico de fill bajo: verificar yield group activo, line item PG con deal ID correcto, buyer seat autorizado en AdX

### Magnite / Rubicon
```json
"ext": {
  "rubicon": {
    "pmp": {
      "type": "pmp"  // o "pg" o "pd"
    }
  }
}
```
- Magnite expone reporting de bid rates y win rates por deal ID en su UI — usar como primera fuente de diagnóstico
- Para PG, el campo `at=3` es obligatorio — verificar en los bid request logs
- Magnite soporta `wseat` para restringir buyers — si el deal no entrega, verificar que el seat del comprador está en la lista
- Deal Health Report disponible en UI: impresiones, bid rate, win rate, motivos de pérdida por categoría

### Triplelift
- Triplelift usa deal IDs alfanuméricos propietarios — el formato es sensible a mayúsculas/minúsculas
- En deals de native, el deal object incluye extensiones de formato nativo en `ext.triplelift`
- Reporting de deal health disponible en Triplelift UI — incluye impressions ganadas, bid rate, y motivos de pérdida
- Creative review obligatorio para native antes de que el deal pueda entregar

### Xandr / Microsoft
- Xandr usa el término "deal" para PMP y "guaranteed deal" para PG
- El deal ID en Xandr es numérico (e.g., `12345678`)
- En bid requests: `pmp.deals[0].ext.appnexus` para extensiones propietarias
- Diagnóstico: Deal Monitor en la UI de Xandr — muestra bid activity, win rate, y reasons de no entrega
- Seat ID para `wseat` en Xandr corresponde al "member ID" del buyer

### Index Exchange (IX)
- IX usa deal IDs con prefijo "IX-" — verificar formato exacto con el account manager
- Reporting de deal health disponible via Deal ID Report en UI o via API
- IX tiene deal types: "Private Auction", "Preferred Deal", "Guaranteed"
- Diagnóstico de bajo fill: IX permite ver bid rate y motivos de pérdida a nivel de deal ID

### PubMatic
- Deal IDs en PubMatic son numéricos generados por la plataforma
- PubMatic Deal Health Report en UI: impresiones, bid rate, win rate, revenue
- Para PG: `at=3` en el deal object — verificar en logs
- PubMatic expone "Deal Troubleshooter" en la UI para diagnosticar deals sin entrega

### Criteo
- Criteo actúa habitualmente como buyer (DSP), no como SSP — los deals con Criteo son PMPs donde Criteo es el buyer
- El deal se configura en el SSP primario (Magnite, IX, etc.) con Criteo como buyer autorizado
- Seat ID de Criteo en OpenRTB varía por SSP — obtener del account manager de Criteo
- Criteo tiene restricciones propias de ad quality y brand safety que pueden bloquear el deal aunque esté bien configurado

### Teads
- Teads es principalmente un SSP de outstream vídeo y display contextual
- Los deals en Teads tienen componente de attention metrics — buyers pueden filtrar por attention score
- Si el deal no entrega, verificar si el buyer tiene configurado un minimum attention threshold
- Deal IDs en Teads son alfanuméricos — sensibles al formato exacto

### Richaudience / Adagio
- Richaudience: SSP especializado en vídeo outstream. Deals son típicamente PMPs directos.
- Adagio: SSP con foco en attention. Buyers pueden configurar filtros de attention score que bloquean el fill.
- Para ambos: verificar que el buyer no tiene configurado un threshold de atención o viewability que el inventario no alcanza

### The Trade Desk (TTD) — como buyer
TTD es el DSP de referencia. Cuando TTD es el buyer y el deal no entrega:
- Verificar que el deal está en estado "Active" en TTD (no "Pending" o "Paused")
- TTD usa Merchant IDs para identificar publishers — el SSP debe tener el Merchant ID correcto
- TTD tiene validación estricta de ads.txt — línea del SSP ausente o incorrecta bloquea completamente
- TTD expone "Deal Health" report en su UI para ver bid rate y motivos de pérdida
- Para PG: TTD llama a los deals PG "Guaranteed Contracts" — verificar que el tipo de deal coincide

---

## Tipos de deal — diferencias operativas

| Tipo | `at` | `private_auction` | Descripción | Riesgo principal |
|---|---|---|---|---|
| **PMP / PA** (Private Marketplace / Private Auction) | `1` o `2` | `1` | El publisher ofrece inventario preferencial a un grupo de buyers. Compiten entre sí y con el mercado abierto si `private_auction=0`. | Deal ID mal configurado en el DSP; floor demasiado alto |
| **PD** (Preferred Deal) | `2` | `1` | El buyer tiene first look al inventario a un precio fijo antes de la subasta. No hay garantía de volumen. | Buyer no puja aunque tiene acceso; floor no competitivo |
| **PG** (Programmatic Guaranteed) | `3` | `1` | Volumen y precio garantizados. El buyer debe entregar el volumen acordado. | `at` incorrecto en bid request; line item GAM sin activar; creative no aprobada |

---

## Diagnóstico por síntoma — campos del deal object

| Síntoma | Campo a verificar | Verificación |
|---|---|---|
| Deal ID no reconocido por el DSP | `id` | Comparar carácter por carácter — espacios y mayúsculas importan |
| CPM final por debajo del floor | `at` + `bidfloor` | Para PG, `at` debe ser `3` (fixed price) |
| Buyer correcto no puede pujar | `wseat` | Verificar que el seat ID del buyer está en la lista o que `wseat` está vacío |
| Deal entrega pero con anunciantes no previstos | `wadomain` | Campo vacío = cualquier anunciante puede ganar |
| PMP entrega en open auction cuando no debería | `private_auction` | Debe ser `1` para auction privada |

---

## Debugging de bid requests — checklist

Para verificar que el deal object llega correctamente al comprador:

1. Obtener muestra de bid requests desde el SSP (log de debug o herramienta de auditoría del SSP)
2. Confirmar que `pmp.deals[0].id` coincide exactamente con el deal ID configurado en el DSP
3. Confirmar `at` según tipo de deal
4. Confirmar `bidfloor` y `bidfloorcur`
5. Si `wseat` está poblado, confirmar que incluye el seat del buyer objetivo
6. Verificar que `pmp.private_auction` tiene el valor esperado
7. Solicitar al buyer confirmación de que el deal ID está activo en su DSP y el seat correcto
