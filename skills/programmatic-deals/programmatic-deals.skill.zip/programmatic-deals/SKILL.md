---
name: programmatic-deals
description: >
  Gestión y troubleshooting de deals publisher-side con foco en GAM/GAM360, SSPs y
  compradores. Especializado en casos donde el buyer no compra, no escucha suficiente
  inventario, no recibe avails suficientes o el deal no escala pese a parecer correctamente
  configurado. Cubre: funnel de salud del deal (avails → listening → bidding → delivery),
  diagnóstico de mismatch entre oferta real y expectativas comerciales, activación buyer
  (seat, DSP, supply path), configuración deal-side (floor, targeting, brand safety,
  creative approval), y supply chain (sellers.json, ads.txt) como prerequisito. Actívala
  ante: buyer no gasta, deal activo sin impresiones, bajo bid rate, "no recibo requests",
  fill rate muy por debajo del objetivo, discrepancia entre lo que ven publisher/SSP/buyer.
  No cubre: deal desde GAM (yield groups, line items, pricing rules) → gam-adops;
  Prebid → prebid-adtech.
---

# Programmatic Deals — Publisher-side, GAM/GAM360

## Frontera de cobertura

**Centro:** troubleshooting de deals publisher-side donde el buyer no compra, no escala o no escucha inventario suficiente. GAM/GAM360 como eje de la entrega final. SSPs (AdX/OB, Magnite, Triplelift, Xandr, IX, PubMatic, Teads, Adagio, Richaudience, Criteo) como soporte diagnóstico. OpenRTB, sellers.json, ads.txt como prerrequisitos o checks laterales — necesarios pero no el eje narrativo.

**No cubre:** configuración de line items PG/PD, yield groups, pricing rules, Open Bidding eligibility en GAM → `gam-adops`. Integración Prebid↔GAM → `prebid-adtech`. VAST/CTV → `video-adtech`.

**Overlap intencionado:** cuando el problema cruza SSP y GAM (e.g., el SSP ve wins pero GAM no registra impresiones), diagnosticar desde este skill hasta el punto de entrega en GAM, luego derivar a `gam-adops` para el lado del servidor de anuncios.

**Indicador:** `[360]` para features exclusivos de GAM 360.

---

## Postura y nivel de análisis

Análisis técnico de nivel senior publisher-side. El objetivo es llegar a la causa raíz, no validar que "el deal parece correcto". La mayoría de los deals que no escalan tienen la causa raíz en una de estas tres categorías: (1) el inventario elegible real es mucho menor de lo que se asumió, (2) el buyer no está realmente escuchando ese inventario, o (3) el problema no es técnico sino comercial. Separar estas tres antes de diagnosticar en profundidad.

### Niveles de evidencia

| Nivel | Cuándo aplica |
|---|---|
| **Verificado** | Comportamiento documentado en specs IAB, documentación del SSP, o reproducible en plataforma |
| **Probable** | Patrón consistente con la lógica del sistema, sin confirmación directa para el caso concreto |
| **Requiere datos** | No se puede concluir sin métricas del SSP, logs de bid request, o confirmación del buyer |
| **Sin evidencia suficiente** | No hay base para afirmar ni refutar — es una respuesta válida |

---

## Funnel de salud del deal

La columna vertebral del diagnóstico. Identificar en qué escalón se rompe el funnel antes de diagnosticar en profundidad.

```
1.  Deal creado           → ¿Existe el deal en el SSP y está activo?
2.  Deal activo           → ¿Tiene fechas vigentes, floor, targeting configurado?
3.  Inventario elegible   → ¿Hay avails reales que cumplen todos los filtros del deal?
4.  Requests al buyer     → ¿El SSP está enviando bid requests con el deal ID?
5.  Buyer escucha         → ¿El buyer tiene el supply path / seat / exchange activo?
6.  Buyer puja            → ¿El buyer está pujando? ¿A qué CPM?
7.  Buyer gana            → ¿Las pujas superan el floor y ganan la subasta?
8.  Creative sirve        → ¿La creative está aprobada y es compatible con el formato?
9.  GAM contabiliza       → ¿GAM registra la impresión? ¿El line item la captura?
10. Spend escala          → ¿El buyer tiene presupuesto y pacing para escalar?
```

**Diagnóstico por punto de ruptura:**

| Falla en | Categoría | Skills involucrados |
|---|---|---|
| 1–2 | Setup del deal en SSP | Este skill |
| 3 | Supply real / targeting / forecasting | Este skill — avails check |
| 4–5 | Activación buyer / supply path / seat / DSP | Este skill |
| 6 | Precio / floor / strategy / budget buyer | Este skill |
| 7–9 | Delivery / creative / GAM / policy | Este skill + `gam-adops` |
| 10 | Problema comercial o de optimización — no necesariamente técnico | Este skill — separar de lo técnico |

---

## Modos de operación

### Modo A — Buyer no compra / bajo spend / no escala *(modo principal)*

Activar cuando el deal parece bien configurado pero el buyer no gasta o el fill rate es muy inferior al esperado. Recorrer el funnel bloque a bloque, emitiendo hipótesis con nivel de evidencia en cuanto hay datos suficientes.

**Bloque 1 — Supply real: ¿Hay avails suficientes y elegibles?**

La causa más frecuente de bajo spend. El forecast se hizo sobre inventario amplio; el deal quedó restringido a una combinación estrecha de filtros.

- ¿Cuántos avails elegibles calcula el SSP o GAM para exactamente los filtros del deal (formato + geo + device + ad unit + domain + tamaño + floor)?
- ¿El inventario prometido comercialmente coincide con el inventario técnicamente targeteado?
- Si hay varios SSPs activos: ¿el deal está en el SSP donde realmente vive ese inventario?

Acción diagnóstica: solicitar avail estimate al SSP con los parámetros exactos del deal. Si hay gap significativo entre el volumen estimado y el elegible real → el problema es de oferta, no de demanda.

**Bloque 2 — Activación buyer: ¿El buyer realmente escucha ese inventario?**

El SSP confirmar que el deal está bien configurado por su lado no garantiza que el buyer esté targetando ese SSP, ese seat, y ese inventario.

- ¿El buyer tiene el deal en estado "Active" en su DSP — no solo "saved" o "pending"?
- ¿Está targetando el SSP/exchange correcto y con el seat ID correcto?
- TTD: ¿Merchant ID correcto para el publisher? DV360/AdX: ¿deal en line item activo con budget?
- ¿El buyer reporta "not seeing enough requests" o "no bid requests received"?
- ¿El SSP ve requests enviados pero sin bids de ese buyer?

Acción diagnóstica: pedir al buyer (1) deal activo en su plataforma, (2) seat y exchange configurados, (3) bid rate en las últimas 24-48h desde su UI.

**Bloque 3 — Restricciones del deal: ¿La configuración limita demasiado?**

Ordenado por frecuencia:
- Floor CPM: ¿es alcanzable por este buyer en este inventario? Verificar con CPMs de mercado o historial de pujas en el SSP.
- Targeting: geo, device, formato, tamaños, horario — ¿alguna restricción no intencionada?
- Domain / app bundle: ¿la lista incluye realmente donde vive el inventario?
- Brand safety / ad quality del buyer: ¿categorías del publisher bloqueadas en el DSP?
- `wseat`: si está poblado, ¿incluye el seat correcto?
- Creative: ¿aprobada en el SSP? ¿Compatible con el formato (tamaños, MIME types)?

**Bloque 4 — Paso por GAM: ¿GAM está dejando pasar el deal?**

Si el SSP reporta wins pero GAM no registra impresiones, o el fill es anómalo:
- Yield group activo con el SSP/buyer correcto `[360]`
- Line item activo, deal ID mapeado correctamente, prioridad apropiada
- Competencia con fuentes de demanda de mayor prioridad que consumen el mismo inventario
- Brecha entre "bid won" en el SSP e "impression served" en GAM `[360]` → Data Transfer logs en BigQuery como fuente definitiva
- `gam-adops` Delivery Tools → Troubleshooter del line item: "Losing to higher-priority line item" como señal de contención

**Bloqueadores silenciosos — verificar antes de derivar a `gam-adops`:**

Si el SSP reporta wins pero GAM no muestra actividad, dos causas frecuentes que no requieren diagnóstico profundo de GAM para identificarse:

1. **Filtro de privacidad / TCF:** ¿El buyer está descartando bid requests por falta de TC string válido o ausencia de consentimiento para Propósito 1? Síntoma: el SSP ve bid requests enviados al buyer pero el buyer no puja — y el problema es transversal a todos los deals del publisher, no solo a este. Si es así, no es un problema del deal: es infraestructura de consentimiento. → `cmp-consent-flows`

2. **Conflicto con UPR:** ¿Hay una Unified Pricing Rule en GAM con floor superior al del deal? El SSP considera la puja ganadora; GAM la descarta por la UPR antes de servir la impresión. Especialmente relevante en PD — los PG generalmente bypasean las UPR, los PD no siempre. Síntoma: wins en el SSP, cero impresiones en GAM, sin error visible. → `gam-adops` para revisión de reglas de precios

→ Diagnóstico profundo en GAM: `gam-adops`

**Bloque 5 — ¿Es técnico o comercial?**

Un deal puede ser técnicamente correcto y tener bajo spend porque el buyer no tiene intención real de escalar, está en fase de test, o aceptó el deal sin commitment de volumen.

| Señal | Interpretación |
|---|---|
| SSP muestra pujas ocasionales, buyer escucha pero poco | Comercial: budget, pacing, KPI, optimización interna del DSP |
| Cero pujas a pesar de deal activo | Investigar técnico primero (bloques 1-3) |
| Buyer puja pero CPM consistentemente bajo | Floor strategy o pricing — no técnico |
| Buyer escala en otros publishers pero no en este | Brand safety o performance del publisher |
| Deal activo, setup correcto, buyer "lo está mirando" semanas | Compromiso comercial, no problema técnico |
| Buyer pide bajar el floor sin dar datos de por qué no compra | Señal de problema comercial — no dar por técnico sin evidencia |
| Buyer dice "estamos optimizando" o "viendo el performance" | DSP optimizando away — pedir métricas concretas de qué métrica falla |
| El buyer escala cuando hay presión comercial pero no antes | El problema era compromiso, no técnica — cerrar diagnóstico técnico |
| Spend arranca y luego se frena sin cambios técnicos | Presupuesto agotado, frequency cap alcanzado, o KPI no cumplido en el DSP |

---

### Modo B — Revisión de configuración de deal

1. Recorrer el funnel escalón por escalón con los datos disponibles.
2. Identificar riesgos de supply insuficiente, restricciones excesivas, y activación incorrecta.
3. Cargar `references/anti-patterns.md`.
4. Verificar prerrequisitos: `references/supply-chain.md`.

### Modo C — Escéptico (revisión de terceros)

Activar cuando: "el SSP dice que todo está correcto", "el buyer dice que está activo", "revisa lo que nos mandaron". Tratar todos los claims como hipótesis. Identificar en qué escalón del funnel está la evidencia real vs. el claim.

### Modo D — Arquitectura de estrategia de deals

1. Identificar volumen elegible real antes de proponer nada.
2. Proponer mix de deal types (PG vs PD vs PMP) con trade-offs de garantía vs. flexibilidad.
3. Advertir mismatch entre oferta real y expectativas comerciales antes de que se firme el deal.
4. Floor strategy: equilibrio entre revenue protection y fill rate; aclarar siempre si el floor es neto o bruto.

**Checklist pre-firma — verificar antes de comprometer volumen:**
- Avail estimate solicitado al SSP con los filtros exactos que tendrá el deal (no estimación amplia)
- Floor acordado con claridad neto vs. bruto, y verificado que es alcanzable por el buyer objetivo
- Seat ID correcto del buyer confirmado con el SSP — no asumir que el buyer sabrá configurarlo
- Domain list / app bundle del deal revisada para que incluya el inventario real relevante
- Restricciones de brand safety y categorías del buyer confirmadas contra el contenido del publisher
- Creatives del buyer compatibles con el formato del deal (tamaños, MIME types) y sin restricciones de revisión pendientes
- Timezone del deal acordada explícitamente si buyer y publisher operan en zonas distintas
- Commitment de volumen y presupuesto del buyer confirmado explícitamente — "estamos interesados" no es un commitment

---

## Intake mínimo — orientado a avails + listening + bidding

No pedir todo en bloque. Emitir hipótesis con los datos disponibles y pedir solo lo que resolvería la ambigüedad del síntoma concreto.

**Datos del deal:**
- SSP/exchange exacto y tipo de deal (PG / PD / PMP / Auction Package / Preferred)
- Deal ID, estado en el SSP, fechas vigentes
- Floor CPM y targeting configurado (geo, device, formato, tamaños, ad unit, domain list)

**Datos de supply:**
- Avails estimados por SSP o GAM para los parámetros exactos del deal
- Volumen prometido comercialmente vs. volumen elegible técnico

**Datos del buyer:**
- Buyer + DSP + seat ID
- Confirmación de listening activo (deal activo, exchange/seat configurado)
- Si reporta "not seeing requests" o bajo bid request volume

**Datos de performance:**
- Bid rate · win rate · impression rate (los tres puntos de conversión del funnel)
- CPMs de pujas observados vs. floor
- Si GAM muestra eligible requests para el deal

---

## Checks troncales — aplicar siempre

- Inventario elegible real verificado con los filtros exactos del deal — no con estimaciones amplias
- Buyer con deal en estado "Active" en su DSP — no solo confirmado por el SSP
- Seat ID del buyer en el SSP coincide con el seat desde el que el buyer está targetando; para TTD verificar Merchant ID específicamente
- Floor CPM coherente con CPMs reales de ese inventario para ese buyer; confirmar con el SSP si el floor es neto o bruto antes de comunicarlo al buyer
- Targeting sin restricciones no intencionadas; domain/app bundle list verificada contra el inventario real del publisher
- Creative del buyer aprobada en el SSP antes de concluir que el problema es de demanda
- GAM yield group y line item verificados si el SSP reporta wins pero GAM no registra impresiones
- Fechas y timezone del deal coherentes entre SSP y buyer — un deal configurado en UTC puede no coincidir con las expectativas del buyer en CET/otras zonas
- Separar problema técnico de problema comercial antes de escalar
- ads.txt correcto para el SSP involucrado (prerrequisito, no diagnóstico principal)

---

## Referencias — cuándo cargar cada una

| Referencia | Cuándo cargarla |
|---|---|
| `references/anti-patterns.md` | Modo A y B — siempre. Tabla síntoma → diagnóstico orientada a buyer no compra |
| `references/openrtb-deal-object.md` | Cuando el diagnóstico llega a nivel de bid request: campos, extensiones por SSP, `at`, `wseat`, `dealid` |
| `references/supply-chain.md` | Cuando sellers.json, ads.txt o schain son sospechosos de bloquear el deal |

---

## Formato de salida

### Modo A — Buyer no compra
Localizar el escalón de ruptura en el funnel primero. Hipótesis etiquetadas con nivel de evidencia. Formato: `[escalón funnel] → [causa probable] → [dato que lo confirmaría]`. Separar qué puede verificar el publisher vs. qué requiere datos del SSP o del buyer. Concluir siempre con: ¿es esto técnico o comercial?

### Modo B — Revisión de configuración
Secciones: **Contexto entendido** · **Riesgos de supply** · **Riesgos de activación buyer** · **Riesgos de configuración** · **Prerrequisitos pendientes** · **Veredicto** en una frase.

### Modo C — Escéptico
Secciones: **Análisis independiente** · **Comparación con claims** · **Veredicto** · **Checklist de evidencia**: `[claim] → [escalón del funnel] → [nivel de evidencia] → [cómo verificar]`.

### Modo D — Arquitectura
Propuesta estructurada con: stack asumido · volumen elegible real · mix de deal types · floor strategy · riesgos de mismatch comercial · diferencias por SSP si aplican.
