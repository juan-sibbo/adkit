---
name: client-context-loader
description: Carga el archivo de contexto técnico de un cliente broadcaster desde Google Drive al inicio de sesión. Actívalo siempre que el usuario mencione uno de los clientes conocidos (Telemadrid, EITB, CRTVG, RTPA, IB3, CarTV, RTVC, Apuntmedia, G24, CMMedia) como contexto de trabajo, o cuando diga frases como "vamos a trabajar con [cliente]", "sesión de [cliente]", "abre el contexto de [cliente]", "carga [cliente]", "¿qué sabes de [cliente]?", "contexto de [cliente]", o cuando un nombre de cliente aparezca al inicio de sesión sin contexto previo. También activar ante "/contexto [cliente]" o "/cargar [cliente]". No activar si el cliente ya ha sido mencionado previamente en la misma sesión y el contexto ya está cargado.
---

# Client Context Loader

**Versión:** 1.0.0
**Estado:** Estable
**Última actualización:** 2026-04-27
**Depende de:** Google Drive MCP (conectado)
**Usado por:** Inicio de sesión con cliente — precede a cualquier skill técnico

> Carga el archivo `context.md` del cliente desde Drive y lo inyecta en la sesión,
> eliminando el coste de re-contextualización manual entre sesiones.

---

## Flujo de ejecución

### Paso 1 — Identificar y normalizar el nombre del cliente

Extraer el nombre del cliente del mensaje del usuario y normalizarlo al nombre canónico:

| Variante detectada | Nombre canónico | Carpeta en Drive |
|-------------------|----------------|-----------------|
| telemadrid, Telemadrid, TM | Telemadrid | `Sibbo/clients/Telemadrid` |
| eitb, EITB, Euskal Irrati Telebista | EITB | `Sibbo/clients/EITB` |
| crtvg, CRTVG, Galicia | CRTVG | `Sibbo/clients/CRTVG` |
| rtpa, RTPA, Asturias | RTPA | `Sibbo/clients/RTPA` |
| ib3, IB3, Baleares | IB3 | `Sibbo/clients/IB3` |
| cartv, CarTV, Aragón | CarTV | `Sibbo/clients/CarTV` |
| rtvc, RTVC, Canarias | RTVC | `Sibbo/clients/RTVC` |
| apuntmedia, Apunt, À Punt | Apuntmedia | `Sibbo/clients/Apuntmedia` |
| g24, G24 | G24 | `Sibbo/clients/G24` |
| cmmedia, CMMedia, Castilla-La Mancha | CMMedia | `Sibbo/clients/CMMedia` |

Si el nombre no coincide con ningún cliente conocido, preguntar al usuario cuál es el cliente antes de continuar.

### Paso 2 — Buscar el archivo en Google Drive

Usar las herramientas de Google Drive MCP disponibles para localizar el archivo:

- **Búsqueda por nombre:** buscar `context.md` dentro de la carpeta `Sibbo/clients/[CLIENTE]`
- **Ruta canónica esperada:** `Mi unidad / Sibbo / clients / [CLIENTE] / context.md`
- **Query de búsqueda sugerida:** `"context.md" in:[CLIENTE]` o buscar por path

Si hay múltiples resultados, priorizar el que esté en la carpeta correcta del cliente.

### Paso 3 — Leer el contenido del archivo

Obtener el contenido completo del archivo `context.md` usando la herramienta de lectura del Drive MCP.

### Paso 4 — Manejo de errores

**Si el archivo no se encuentra:**
```
No encuentro el archivo de contexto para [CLIENTE].

Ruta esperada en Drive: Mi unidad / Sibbo / clients / [CLIENTE] / context.md

Opciones:
1. Verifica que el archivo existe en esa ruta exacta
2. Puedo generar un context.md nuevo para [CLIENTE] si me indicas que arrancamos el onboarding
3. Continúa sin contexto cargado (la sesión funcionará con menos contexto específico del cliente)
```

**Si Drive MCP no está disponible:**
```
El MCP de Google Drive no está disponible en esta sesión.
Para cargar el contexto de [CLIENTE] manualmente, pega el contenido
del archivo context.md directamente en el chat.
```

### Paso 5 — Confirmar carga y resumir estado

Una vez cargado el contexto, responder con un resumen conciso en este formato:

```
✓ Contexto de [CLIENTE] cargado (v[VERSION] · actualizado [FECHA])

Stack activo:
• Entrega: [CSAI/SSAI/híbrido]
• Dispositivos CTV: [lista de dispositivos activos]
• PPID: [estado]
• SSPs: [lista]
• CMP: [proveedor]

[N] campos pendientes de completar: [lista de los [VERIFICAR] más críticos si los hay]

¿En qué trabajamos hoy?
```

Ajustar el nivel de detalle del resumen al contexto: si el usuario ya indicó la tarea (e.g., "carga Telemadrid y revisamos el deal de PubMatic"), no hacer la pregunta final — pasar directamente a la tarea.

### Paso 6 — Mantener el contexto activo durante la sesión

Una vez cargado, el contexto del cliente está disponible para todos los skills técnicos de la sesión:
- `video-adtech` usará los dispositivos activos y versiones de IMA SDK del cliente
- `programmatic-deals` usará los SSPs y deals documentados
- `discrepancy-forensics` usará el Network Code y los datasets del cliente
- `gam-adops` usará la estructura de ad units y key-values del cliente

No volver a cargar el contexto en la misma sesión salvo que el usuario lo pida explícitamente con `/recargar [cliente]`.

---

## Comando de actualización de contexto

Si durante la sesión se obtiene información nueva sobre el cliente (nuevo deal, RDID verificado, incidencia resuelta), ofrecer actualizarla:

```
He aprendido algo nuevo sobre [CLIENTE]: [dato].
¿Quieres que lo registre en el context.md de Drive?
```

Si el usuario confirma, actualizar el archivo usando las herramientas de escritura del Drive MCP si están disponibles, o indicar al usuario el campo exacto a editar si no lo están.

---

## Flags de integridad del contexto

Al cargar, detectar y notificar estos campos como críticos si están marcados como `[VERIFICAR]`:

| Campo | Por qué es crítico |
|-------|-------------------|
| Network Code GAM | Sin él, todos los ad tags del cliente son genéricos |
| Bundle IDs de apps CTV | Sin ellos, app-ads.txt y diagnósticos CTV son inoperables |
| SSPs activos | Sin ellos, programmatic-deals trabaja a ciegas |
| Estado PPID | Crítico especialmente para tvOS y HbbTV |
| CMP provider | Sin él, cmp-consent-flows no puede diagnosticar |

Si 3 o más de estos campos están como `[VERIFICAR]`, avisar al usuario antes de proceder:

```
⚠ El contexto de [CLIENTE] tiene [N] campos críticos sin completar.
Los diagnósticos técnicos pueden ser menos precisos hasta que se rellenen.
Campos pendientes: [lista]
```

---

## Changelog

### v1.0.0 — 2026-04-27
**Tipo:** MAJOR (creación)
**Origen:** Arquitectura del ecosistema — implementación de D1 (memoria por cliente)
- Crear: skill inicial con flujo completo de carga desde Drive
- Crear: tabla de normalización de nombres de cliente
- Crear: detección de campos críticos [VERIFICAR]
- Crear: integración con skills técnicos downstream
