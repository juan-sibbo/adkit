---
name: broadcaster-onboarding
description: Orquesta el setup completo de un nuevo cliente broadcaster (TV autonómica española típica) sobre el stack Sibbo. Actívalo cuando el usuario diga "nuevo cliente", "onboarding de [TV]", "vamos a dar de alta [TV]", "alta de [nombre]", "empezamos con [TV]", o cuando mencione una TV autonómica que no esté todavía en el ecosistema. No cubre la operativa diaria post-onboarding (eso es gam-adops y programmatic-deals).
---

# Broadcaster Onboarding

**Versión:** 1.0.0
**Estado:** Estable
**Última actualización:** 2026-04-27
**Depende de:** gam-adops, cmp-consent-flows, video-adtech, programmatic-deals, client-context-loader
**Usado por:** Agente β (Broadcaster Onboarder)

> Convierte el alta de un nuevo cliente broadcaster en un flujo guiado
> de configuración mínima viable + lista de tareas concretas con propietario.

---

## Cuestionario inicial (5 preguntas, en este orden)

Antes de generar ningún artefacto, recopilar estos datos. Hacer las 5 preguntas en un solo mensaje:

```
Para arrancar el onboarding de [CLIENTE] necesito 5 datos:

1. Modelo de ad delivery:
   a) Solo CSAI (IMA SDK client-side en todos los entornos)
   b) CSAI en web + SSAI/DAI en CTV
   c) Solo SSAI/DAI

2. Dispositivos CTV que hay que monetizar ahora mismo (marca todos los que apliquen):
   Android TV / Fire TV / Samsung Tizen / LG webOS / tvOS / HbbTV / Roku / Chromecast

3. Intermediario de monetización:
   a) Newixmedia (habitual)
   b) Otro: [cuál]
   c) Directo (sin intermediario)

4. ¿Primer SSP a integrar? (el más urgente o el que ya tiene relación el cliente)
   PubMatic / Magnite / Xandr / otro: [cuál]

5. ¿La TV tiene presencia en OTT (apps en tiendas) además de web y TDT/HbbTV?
   Sí (especificar stores: Google Play / App Store / Fire TV Store / Samsung / LG / otro)
   No (solo web + HbbTV si aplica)
```

---

## Flujo de onboarding por fases

### Fase 1 — Prerequisites (verificar antes de configurar nada)

```
□ Dominio del cliente verificado (DNS, HTTPS activo)
□ Acceso a GAM 360 del cliente confirmado (cuenta existente o crear)
□ Intermediario confirmado y sellers.json verificado:
   - Newixmedia: https://newixmedia.com/sellers.json — buscar el publisher
   - Si no aparece: coordinar alta con Newixmedia antes de continuar
□ Contacto técnico del cliente identificado (quién implementará el código)
□ CMS del cliente identificado (para futura integración de content signals)
```

Si algún prerequisito falla → documentar en §6 del context.md como incidencia abierta y no avanzar a Fase 2 hasta resolución.

### Fase 2 — Supply chain (ads.txt / app-ads.txt)

Generar el bloque de ads.txt para el cliente:

```
# ads.txt — [CLIENTE] — generado [fecha]
# Intermediario: Newixmedia

# Newixmedia (intermediario principal)
newixmedia.com, [PUBLISHER_ACCOUNT_ID], RESELLER, [TAG_ID]

# SSP 1: [nombre]
[dominio_ssp], [account_id], DIRECT, [TAG_ID]

# SSP 2 (si aplica)
[dominio_ssp], [account_id], DIRECT, [TAG_ID]

# Google (Open Bidding)
google.com, pub-[XXXXXXXXXXXXXXXX], RESELLER, f08c47fec0942fa0
```

> **Nota:** los valores exactos de account_id y tag_id deben venir de cada SSP.
> Marcar como [VERIFICAR] los que no se conocen en este momento.

Si hay apps CTV, generar también `app-ads.txt` con la misma estructura + bundle IDs.

### Fase 3 — GAM 360: estructura de inventario

Definir la arquitectura de ad units para el cliente nuevo:

**Estructura canónica Sibbo para broadcaster autonómico:**

```
/[NETWORK_CODE]/[cliente]/
  ├── web/
  │   ├── preroll
  │   ├── midroll
  │   └── display/
  │       ├── billboard
  │       ├── megabanner
  │       └── robapaginas
  └── ctv/
      ├── preroll
      └── midroll
```

Checklist de configuración en GAM:
```
□ Ad network creada o acceso verificado
□ Ad units creadas con la estructura anterior
□ Key-values básicos creados: pos, env, rdid, idtype, is_lat, ppid
□ Ad rules configuradas para CTV (pre-roll + mid-roll si aplica)
□ Open Bidding habilitado para los SSPs del cliente
□ Yield groups iniciales configurados
□ Competitive exclusions definidas (telecos si aplica)
□ Pricing rule inicial: floor mínimo definido con el cliente
```

### Fase 4 — IMA SDK: configuración por dispositivo

Para cada dispositivo CTV activo, generar el ad tag base:

**Template CSAI — CTV genérico:**
```
https://pubads.g.doubleclick.net/gampad/ads
  ?iu=/[NETCODE]/[cliente]/ctv/preroll
  &sz=640x480
  &gdfp_req=1&output=vast&unviewed_position_start=1
  &env=vp&impl=s
  &correlator=[CACHEBUSTER]
  &rdid=[RDID]&idtype=[IDTYPE]&is_lat=[IS_LAT]
  &ppid=[PPID]
  &gdpr=1&gdpr_consent=[GDPR_CONSENT]
  &cust_params=env%3Dctv%26pos%3Dpre
```

Adaptar macros por dispositivo (ver §3.2.4 del context.md del cliente).

**Checklist IMA SDK por dispositivo:**
```
Android TV / Fire TV:
  □ IMA Android SDK integrado en el player
  □ ExoPlayer IMA extension configurada
  □ TIFA/AFAI recogido y pasado al ad tag
  □ Consent signal configurado si hay CMP en la app

Samsung Tizen:
  □ IMA HTML5 SDK cargado (verificar versión Tizen OS para ES6 compat)
  □ RIDA obtenido via Samsung Ads API
  □ Orden de carga: googletag antes de IMA SDK

LG webOS:
  □ IMA HTML5 SDK cargado
  □ Permission ID_GENERATION declarada en appinfo.json
  □ LGUDID obtenido y pasado al ad tag

tvOS / Apple TV:
  □ IMA tvOS SDK integrado con AVPlayer
  □ ATT prompt implementado antes de la primera solicitud de ad
  □ PPID configurado como señal principal (IDFA no fiable)

HbbTV:
  □ IMA HTML5 SDK (verificar capacidad del terminal)
  □ Diseñado para modo degradado (sin señal de retorno en TDT)
  □ Sin RDID — señal alternativa definida (PPID o IP)
```

### Fase 5 — CMP y señales de consentimiento

```
□ CMP identificada (Didomi / OneTrust / otro / ninguna)
□ TCF v2.2 configurado para web
□ TC string pasado correctamente en ad tags web
□ Para apps CTV: consent gestionado a nivel de app (ver §3.2.5 del context.md)
□ Vendor list del SSP y GAM declarados en la CMP
□ Purposes TCF mapeados correctamente (ver cmp-consent-flows para detalle)
```

### Fase 6 — Primer SSP: setup inicial de deal

```
□ Cuenta del publisher dada de alta en el SSP
□ Seller ID del publisher verificado en sellers.json del SSP
□ Inventario mapeado en la plataforma del SSP
□ Floor inicial configurado (alineado con GAM pricing rule)
□ Deal template inicial creado (PMP abierto como punto de partida)
□ Test de bid request verificado (logs del SSP muestran tráfico)
```

### Fase 7 — PPID: plan de implementación

Dado que PPID es crítico especialmente para tvOS y HbbTV:

```
□ Identity partner seleccionado (LiveRamp / ID5 / hashed email propio)
□ Método de hashing definido (SHA-256 del email de usuario registrado)
□ Entornos priorizados para implementación:
   Prioridad 1: tvOS (IDFA no disponible — PPID es la única señal)
   Prioridad 2: HbbTV (sin RDID — PPID o IP como única alternativa)
   Prioridad 3: Web (complementa cookies)
□ Timeline de implementación acordado con el equipo técnico del cliente
```

---

## Artefactos generados por este skill

Al completar el onboarding, producir:

1. **`[cliente]-context.md`** — archivo de contexto rellenado con todos los datos del onboarding (subir a Drive en `Sibbo/clients/[CLIENTE]/context.md`)
2. **`[cliente]-ads.txt`** — borrador del ads.txt para revisión del cliente
3. **`[cliente]-app-ads.txt`** — si hay apps CTV
4. **Lista de tareas en Zoho Projects** — una tarea por cada ítem de checklist pendiente, con propietario y fecha estimada
5. **Draft de Slack** — mensaje inicial para el canal del cliente o para comunicación interna

---

## Checklist de cierre de onboarding

```
□ context.md creado y subido a Drive
□ ads.txt / app-ads.txt generados y enviados al cliente para aprobación
□ Ad units en GAM verificadas (test de impresión manual)
□ IMA SDK en al menos un dispositivo CTV generando bid requests
□ Primer bid recibido del SSP (aunque sea cero wins — confirma que el inventario es visible)
□ knowledge-capture activado con los anti-patterns detectados durante el onboarding
```

---

## Anti-patterns de onboarding

- **Avanzar sin sellers.json verificado:** el inventario no será elegible para programmatic hasta que el publisher aparezca correctamente
- **Configurar IMA SDK antes de tener el ad tag base:** el ad tag define las macros — sin él el SDK no sabe qué pedir
- **No definir floor mínimo:** el inventario saldrá en open auction sin protección de precio
- **Ignorar PPID en tvOS desde el principio:** el fill en Apple TV será estructuralmente bajo hasta que PPID esté activo

---

## Changelog

### v1.0.0 — 2026-04-27
**Tipo:** MAJOR (creación)
**Origen:** Auditoría ecosistema — pain point P4
- Crear: skill inicial con flujo de 7 fases
- Crear: cuestionario inicial de 5 preguntas
- Crear: templates de ads.txt y ad tags por dispositivo
- Crear: checklists por fase y por dispositivo CTV
- Crear: lista de artefactos de salida
