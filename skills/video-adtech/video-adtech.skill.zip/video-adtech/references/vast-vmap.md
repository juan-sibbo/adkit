# VAST / VMAP — Referencia técnica

## Tabla de contenidos
1. Versiones VAST y compatibilidad
2. Estructura VAST InLine vs Wrapper
3. Error codes VAST con causa/solución CTV
4. VMAP: estructura y timeOffset
5. Wrapper chains y SSU
6. MediaFile selection
7. Macros de tracking

---

## 1. Versiones VAST y compatibilidad

| Versión | Nodos clave añadidos | Soporte CTV |
|---|---|---|
| VAST 2.0 | Estructura básica InLine/Wrapper, TrackingEvents | Universal, legacy |
| VAST 3.0 | AdVerifications (parcial), skippable ads, icons | Amplio |
| VAST 4.0 | AdVerifications (completo, OMID), Mezzanine file, UniversalAdId, Category | Recomendado para CTV |
| VAST 4.1 | Mejoras en Interactive Creative File, server-side stitching signals | Soporte creciente |
| VAST 4.2 | Mejoras menores, clarificaciones | Soporte emergente |

**Para CTV:** usar `output=xml_vast4` en GAM. Si el player es legacy, verificar compatibilidad y usar `output=xml_vast3` como fallback.

---

## 2. Estructura VAST InLine vs Wrapper

**InLine:** contiene el ad completo (MediaFiles, TrackingEvents, creatividad).

**Wrapper:** contiene URL a otro VAST (redirect). Cada nivel añade latencia (200-500ms por hop).

```xml
<!-- Wrapper example -->
<VAST version="4.0">
  <Ad>
    <Wrapper>
      <AdSystem>SSP_A</AdSystem>
      <VASTAdTagURI><![CDATA[https://ssp-b.com/vast?id=456]]></VASTAdTagURI>
      <Impression><![CDATA[https://ssp-a.com/impression]]></Impression>
      <Error><![CDATA[https://ssp-a.com/error?code=[ERRORCODE]]]></Error>
    </Wrapper>
  </Ad>
</VAST>
```

**Límite de wrappers:** IAB VAST spec recomienda que players soporten al menos 5 niveles. GAM configura `maxRedirects`. Más allá → error 302 (wrapper limit reached).

---

## 3. Error codes VAST — causa y solución en CTV

| Código | Nombre | Causa común CTV | Diagnóstico | Solución |
|---|---|---|---|---|
| 100 | XML Parsing Error | SSP devuelve XML inválido | Validar VAST con VSI | Contactar SSP; habilitar SSU (GAM valida XML server-side) |
| 101 | VAST Schema Error | Elementos de versión incorrecta mezclados | Inspeccionar VAST response | Alinear versión VAST en GAM y SSP |
| 200 | Trafficking Error | Line item mal configurado | GAM Publisher Console | Revisar targeting y creative assignment |
| 201 | Video Player Error | Codec no soportado (HEVC en device legacy) | Verificar codec de MediaFile vs capacidades device | Usar H.264 universal; fallback 720p |
| 202 | Ad Request Timeout | Latencia red >timeout, Open Bidding lento | Medir time-to-first-byte del ad request | Reducir timeout; reducir SSPs en Open Bidding |
| 203 | Wrapper Timeout | Múltiples redirects exceden tiempo | Contar wrappers en cadena | Habilitar SSU; limitar maxRedirects |
| 301 | Wrapper Limit | Excede máximo de redirects configurado | Contar niveles de wrapper | Reducir cadena; SSU |
| 302 | No VAST After Wrapper | Wrapper chain termina sin InLine | Fetch manual de cada URL en la cadena | Verificar endpoint final; contactar SSP |
| 303 | No Ad In VAST | VAST vacío (no-fill o WTA compliance) | Publisher Console: ver razones de no-match | Verificar WTA, creativos non-personalized disponibles |
| 400 | General Linear Error | Problema con MediaFile | Ver subcódigos 4xx | — |
| 401 | MediaFile Not Found | Creative borrado de CDN | curl -I de MediaFile URL | Re-upload creative |
| 402 | MediaFile Timeout | CDN lento o creative muy grande | Medir tamaño y tiempo de descarga | Optimizar bitrate; usar CDN con edge servers locales |
| 403 | MediaFile Access Denied | URL firmada expirada o geo-blocking | Verificar headers de respuesta | Verificar URL signing y CDN permissions |
| 405 | Unsupported MIME | WebM en device que solo soporta MP4 | Verificar MIME type del MediaFile | Usar MP4/H.264 universal |
| 900 | Undefined Error | Catch-all | Revisar logs completos del SDK | Stack trace, contexto del error |
| 901 | VPAID Error | Creativa VPAID en CTV | Verificar tipo de creative | VPAID está bloqueado en CTV; usar VAST lineal |

---

## 4. VMAP: estructura y timeOffset

VMAP define la estructura de ad breaks para un contenido completo.

```xml
<vmap:VMAP xmlns:vmap="http://www.iab.net/videosuite/vmap" version="1.0">
  <vmap:AdBreak timeOffset="start" breakType="linear">
    <vmap:AdSource><vmap:VASTAdData>...</vmap:VASTAdData></vmap:AdSource>
  </vmap:AdBreak>
  <vmap:AdBreak timeOffset="00:15:00.000" breakType="linear">
    <vmap:AdSource><vmap:AdTagURI><![CDATA[https://...]]></vmap:AdTagURI></vmap:AdSource>
  </vmap:AdBreak>
  <vmap:AdBreak timeOffset="end" breakType="linear">
    <vmap:AdSource>...</vmap:AdSource>
  </vmap:AdBreak>
</vmap:VMAP>
```

**timeOffset:** `start` | `end` | `HH:MM:SS.mmm` | `#N` (posición porcentual, raramente usado).

**Relación con Ad Rules:** cuando GAM tiene Ad Rules configuradas y `ad_rule=1` en la tag, GAM devuelve VMAP con los ad breaks definidos. IMA SDK parsea VMAP automáticamente.

---

## 5. Wrapper chains y SSU

**Sin SSU (client-side unwrapping):**
Device hace N requests secuenciales para resolver la cadena de wrappers.
Latencia acumulativa: N × (200-500ms).

**Con SSU (Server-Side Unwrapping):**
GAM resuelve la cadena server-side y devuelve VAST InLine final al device.
Device hace 1 solo request.

**Capacidades verificadas de SSU:**
- Resuelve wrappers hasta el límite configurado [Verificado]
- Inspecciona cadena para brand safety (bloquea domains sospechosos) [Probable]
- Requiere que el third-party ad server esté en lista de certified servers [Verificado]
- Configuración: Admin > Video > Server-side ad unwrapping

**Limitación:** SSU no puede resolver wrappers de ad servers no certificados por Google.

---

## 6. MediaFile selection

IMA SDK selecciona MediaFile basándose en:
1. **Codec compatibility** del device (H.264 preferido, HEVC si soportado)
2. **Bandwidth** detectado (adaptive)
3. **Resolución** de pantalla del device
4. **MIME type** soportado

Para CTV: incluir siempre MediaFile H.264/MP4 en 1080p y 720p como mínimo.

---

## 7. Macros de tracking

| Macro | Sustitución | Quién sustituye |
|---|---|---|
| `[ERRORCODE]` | Código de error VAST | Player/SDK |
| `[CACHEBUSTING]` | Valor aleatorio | Player/SDK |
| `[TIMESTAMP]` | Epoch timestamp | Ad server o player |
| `[CONTENTPLAYHEAD]` | Posición del contenido (HH:MM:SS.mmm) | Player |
| `[ASSETURI]` | URI del MediaFile reproducido | Player/SDK |

**En GAM:** las macros de GAM (como `%%CLICK_URL_ESC%%`) se sustituyen server-side. Las macros VAST estándar las sustituye el SDK/player client-side.
