# OpenRTB Video — Referencia técnica

## 1. imp.video en bid request CTV

Campos clave del objeto `imp.video` en OpenRTB 2.5/2.6:

| Campo | Tipo | Descripción | Valor típico CTV |
|---|---|---|---|
| `mimes` | array | MIME types soportados | `["video/mp4"]` |
| `minduration` | int | Duración mínima en segundos | 15 |
| `maxduration` | int | Duración máxima | 30 (o 60 para long-form) |
| `protocols` | array | Protocolos soportados | `[2,3,5,6]` (VAST 2.0-4.0) |
| `w` | int | Ancho del player | 1920 |
| `h` | int | Alto del player | 1080 |
| `startdelay` | int | Posición: 0=pre-roll, >0=mid-roll (offset en s), -1=generic mid, -2=generic post | 0 |
| `placement` | int | 1=in-stream, 2=in-banner, 3=in-article, 4=floating, 5=interstitial | 1 |
| `linearity` | int | 1=linear (in-stream), 2=non-linear (overlay) | 1 |
| `skip` | int | 0=not skippable, 1=skippable | 0 (CTV típicamente non-skip) |
| `pos` | int | Posición en pod (si aplica) | 1 (1st position) |
| `api` | array | APIs soportados: 1=VPAID 1.0, 2=VPAID 2.0, 3=MRAID-1, 5=MRAID-2, 6=MRAID-3, 7=OMID-1 | `[7]` (OMID) |
| `companiontype` | array | Tipos de companion: 1=static, 2=HTML, 3=iframe | Raramente usado en CTV |

---

## 2. device object en CTV

| Campo | Descripción | Notas CTV |
|---|---|---|
| `devicetype` | 3=Connected TV (OpenRTB 2.5+), 7=Set-Top Box | Distinguir Smart TV vs STB |
| `make` | Fabricante | "Samsung", "LG", "Amazon" |
| `model` | Modelo | "SmartTV", "BRAVIA", etc. |
| `os` | Sistema operativo | "Tizen", "webOS", "Android", "tvOS", "Fire OS" |
| `osv` | Versión OS | "4.0", "5.0", "11.0" |
| `ifa` | Identifier for Advertisers (device ID) | Mapeado desde rdid |
| `lmt` | Limit Ad Tracking | 0=tracking OK, 1=opt-out |
| `ua` | User Agent | Señal de device identification |
| `ip` | IP address | Geo-targeting, fraud detection |
| `connectiontype` | Tipo de conexión | 2=wifi, 7=cellular |

---

## 3. PMP CTV — deals en bid request

```json
{
  "pmp": {
    "private_auction": 1,
    "deals": [
      {
        "id": "PG_12345",
        "bidfloor": 12.0,
        "bidfloorcur": "EUR",
        "at": 3
      }
    ]
  }
}
```

**Tipos de auction (`at`):**
- 1 = First Price Auction
- 2 = Second Price Auction
- 3 = Fixed Price (Programmatic Guaranteed)

---

## 4. Bid response para CTV

DSP responde con:

```json
{
  "seatbid": [{
    "bid": [{
      "id": "bid_001",
      "impid": "1",
      "price": 15.50,
      "adm": "<VAST version='4.0'>...</VAST>",
      "crid": "creative_12345",
      "dealid": "PG_12345",
      "w": 1920,
      "h": 1080,
      "cat": ["IAB1-6"],
      "dur": 30
    }]
  }]
}
```

**`adm`:** contiene VAST XML inline (la creatividad). En algunos casos es URL a VAST wrapper.

---

## 5. Señales de contenido en OpenRTB

| Campo OpenRTB | Fuente publisher | Descripción |
|---|---|---|
| `site.content.id` | vid / Content ID | ID del contenido |
| `site.content.title` | MRSS / cust_params | Título |
| `site.content.series` | MRSS | Nombre de la serie |
| `site.content.season` | MRSS | Temporada |
| `site.content.episode` | MRSS | Episodio |
| `site.content.cat` | cc / IAB taxonomy | Categoría de contenido |
| `site.content.contentrating` | MRSS / cust_params | Rating (TV-MA, etc.) |
| `site.content.language` | cust_params | Idioma |
| `site.content.len` | MRSS / duration | Duración en segundos |
| `site.content.livestream` | Tipo de contenido | 0=VOD, 1=live |

**Más señales → DSPs targetean mejor → pujan más alto → CPMs más altos.**
