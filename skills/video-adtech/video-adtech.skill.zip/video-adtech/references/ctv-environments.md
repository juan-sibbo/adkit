# CTV Environments — Referencia técnica

## Tabla de contenidos
1. Framework Tier 1/2/3 por device
2. Plataformas y sus particularidades
3. HbbTV: perfiles y limitaciones
4. FAST channels
5. CORS/CSP en CTV
6. App versioning y device tiers
7. localStorage y persistencia

---

## 1. Framework Tier 1/2/3 por device

| Tier | Características | Devices | Estrategia de ads |
|---|---|---|---|
| **Tier 1** (Moderno, 2020+) | SDK completo, OM, HEVC, 4K, buen CPU/RAM | Samsung Tizen 5.5+, LG webOS 5.0+, Android TV 10+, Apple TV 4K, Fire TV Stick 4K | Full features: IMA SDK, Open Bidding 5 SSPs, OMID, 1080p/4K |
| **Tier 2** (Mid-range, 2017-2019) | SDK soportado, H.264, 1080p, CPU/RAM moderados | Samsung Tizen 3.0-5.0, LG webOS 3.5-4.5, Android TV 8-9, Fire TV Gen 2 | Reducido: Open Bidding 3 SSPs, OMID, 1080p |
| **Tier 3** (Legacy, pre-2017) | SDK limitado o sin soporte, H.264 720p, CPU/RAM bajos | Samsung Tizen 2.4, LG webOS 2.0, STBs de operadora | Mínimo: directo o 1 SSP, Inferred Viewability, 720p, timeout 3s |

**Decisión de soporte Tier 3:** trade-off de negocio. Si revenue < coste de mantenimiento → deprecar con aviso.

---

## 2. Plataformas y sus particularidades

### Samsung Tizen
- **Runtime:** WebView (JavaScript) para apps web; nativo C++ para apps Tizen nativas
- **IMA SDK:** HTML5 variant
- **Device ID:** TIFA (Tizen Identifier for Advertising) via `webapis.adinfo.getTIFA()`
- **idtype:** `tifa` [Verificado]
- **LAT:** `webapis.adinfo.isLATEnabled()`
- **Particularidades:** Memory leaks frecuentes en WebView; `localStorage` disponible pero con límites; HEVC solo en modelos 2017+
- **Market share Europa:** ~30-35% (líder en ES, FR)

### LG webOS
- **Runtime:** WebView (JavaScript) + webOS Media API
- **IMA SDK:** HTML5 variant
- **Device ID:** LGUDID (LG Advertising ID) via API propietaria LG
- **idtype:** `lgudid` [Probable]
- **Particularidades:** API de ads propietaria de LG; `localStorage` disponible; Web Inspector para debug
- **Market share Europa:** ~15-20%

### Android TV
- **Runtime:** Android nativo (Java/Kotlin)
- **IMA SDK:** Android SDK
- **Device ID:** GAID via `AdvertisingIdClient.getAdvertisingIdInfo()`
- **idtype:** `adid` [Verificado]
- **Particularidades:** ExoPlayer recomendado; requiere permiso `com.google.android.gms.permission.AD_ID`; Leanback UI
- **Market share Europa:** ~15% (creciente con Chromecast con Google TV)

### Fire TV (Amazon)
- **Runtime:** Android fork (Fire OS)
- **IMA SDK:** Android SDK (compatible)
- **Device ID:** AFAI via `AdRegistration.getAdvertisingId()`
- **idtype:** `afai` [Probable]
- **Particularidades:** Fire OS es fork Android pero con Amazon app store; debugging similar a Android (adb)
- **Market share Europa:** ~10-12%

### Apple TV (tvOS)
- **Runtime:** tvOS nativo (Swift/ObjC)
- **IMA SDK:** iOS SDK
- **Device ID:** IDFA via `ASIdentifierManager`; requiere ATT framework en tvOS 14.5+
- **idtype:** `idfa` [Verificado]
- **Particularidades:** AVPlayer obligatorio; sin HLS interstitials para ads; HEVC soportado
- **Market share Europa:** ~5-8%

### Roku
- **Runtime:** BrightScript (propietario)
- **IMA SDK:** Roku variant
- **Device ID:** RIDA (Roku ID for Advertising) via Roku API
- **idtype:** `rida` [Verificado]
- **Particularidades:** Entorno cerrado; SDK propietario; mercado principal US/UK
- **Market share Europa:** <5%

---

## 3. HbbTV: perfiles y limitaciones

| Perfil | Año | Capacidades de ads |
|---|---|---|
| HbbTV 1.4 | 2014 | VAST básico, sin OMID, JavaScript limitado |
| HbbTV 2.0 | 2016 | Mejor soporte de video, DRM, WebSocket |
| HbbTV 3.0 | 2021 | Companion screen, mejor integración programática |

**Limitaciones comunes HbbTV:**
- CPU/RAM muy limitados (se ejecuta en TV, no en STB)
- Sin device ID resettable en muchas implementaciones (depende del broadcaster)
- CORS puede ser problemático (restricciones de seguridad variables)
- `localStorage` limitado o no disponible en perfiles antiguos
- Prebid.js SÍ se usa en algunos casos HbbTV (es entorno JavaScript)
- Timeout recomendado: 3s máximo

---

## 4. FAST channels (Free Ad-Supported Television)

- Contenido programado 24/7 (similar a TV lineal)
- Ad breaks síncronos, controlados por el broadcaster/plataforma
- Mismas reglas que live TV: fill crítico, fallback obligatorio
- Ejemplos: Pluto TV, Samsung TV+, Rakuten TV, Amazon Freevee
- SSAI generalmente preferido sobre CSAI para FAST (UX seamless)

---

## 5. CORS/CSP en CTV

**CORS:** las apps CTV hacen requests a dominios de ad serving (pubads.g.doubleclick.net, tracking domains de SSPs). Si CORS no está configurado:
- Tracking pixels pueden fallar silenciosamente
- VAST fetch puede ser bloqueado

**CSP (Content Security Policy):** algunas plataformas CTV imponen CSP restrictivas.
- Verificar que los dominios de ad serving están permitidos
- Incluir dominios de: GAM, SSPs activos, CDNs de creatividades, tracking providers

**Diagnóstico:** si beacons no disparan → verificar CORS headers en la respuesta del tracking endpoint.

---

## 6. App versioning y device tiers

**Problema real:** no todos los devices tienen la misma versión de la app.
- Rollout gradual: v2.0 en 30% de devices, v1.9 en 70%
- Feature flags para habilitar/deshabilitar features de ads por versión
- `app_version` como cust_param → targeting de line items por versión

**Tier detection en código:**
```
if (device.year < 2017 || device.ram < 1GB) → Tier 3 config
else if (device.year < 2020) → Tier 2 config
else → Tier 1 config
```

---

## 7. localStorage y persistencia

**No asumir que `localStorage` está disponible en CTV.**

| Plataforma | localStorage | Alternativa |
|---|---|---|
| Samsung Tizen | ✅ Disponible (con límites) | — |
| LG webOS | ✅ Disponible | — |
| Android TV | N/A (nativo usa SharedPreferences) | SharedPreferences |
| Fire TV | N/A (nativo usa SharedPreferences) | SharedPreferences |
| Apple TV | N/A (nativo usa UserDefaults) | UserDefaults |
| HbbTV | ⚠️ Variable (depende de perfil/implementación) | Puede no estar disponible |

**Anti-pattern:** asumir `localStorage` disponible para almacenar user IDs o configuración → falla silenciosamente en algunos entornos CTV.
