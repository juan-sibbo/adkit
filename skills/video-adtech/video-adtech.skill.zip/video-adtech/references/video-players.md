# Video Players — Referencia técnica

## Tabla de contenidos
1. Matriz de players por entorno CTV
2. ContentPlayhead: implementación correcta
3. Video.js + IMA SDK
4. JW Player: ad schedule y callbacks
5. Shaka Player: ad manager e integración
6. ExoPlayer (Android TV) + IMA extension
7. AVPlayer (tvOS) + IMA iOS SDK
8. hls.js / dash.js en entornos web-based CTV
9. Anti-patterns de integración player + SDK

---

## 1. Matriz de players por entorno CTV

| Entorno | Player recomendado | IMA SDK variant | Notas |
|---|---|---|---|
| Android TV | ExoPlayer | IMA Android SDK (ExoPlayer extension) | Integración oficial via `ImaAdsLoader` |
| Fire TV | ExoPlayer | IMA Android SDK | Idéntico a Android TV |
| tvOS / Apple TV | AVPlayer | IMA iOS SDK | AVPlayer obligatorio por política Apple |
| Tizen (Samsung) | Video.js / Shaka / custom | IMA HTML5 SDK | WebView; cuidado con memory leaks |
| webOS (LG) | Video.js / Shaka / custom | IMA HTML5 SDK | WebView + webOS Media API |
| HbbTV | Custom (broadcaster) / Video.js | IMA HTML5 SDK | Muy variable por broadcaster; recursos limitados |
| Web (OTT) | Video.js / JW Player / Shaka | IMA HTML5 SDK | Entorno más flexible |
| Chromecast | CAF receiver custom | IMA CAF SDK | Receiver app en Cast device |

---

## 2. ContentPlayhead: implementación correcta

El IMA SDK HTML5 consulta `ContentPlayhead.getCurrentTime()` aproximadamente 4 veces por segundo para detectar cue points de mid-rolls. Una implementación incorrecta es la causa más frecuente de mid-rolls que nunca disparan.

**Implementación correcta:**
```javascript
// La interfaz ContentPlayhead debe retornar la posición REAL del player en tiempo real
const contentPlayhead = {
  getCurrentTime: () => videoElement.currentTime  // leer directamente del DOM
};

adsManager.init(width, height, google.ima.ViewMode.NORMAL);
// Pasar el playhead al SDK
adsLoader.addEventListener(
  google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
  (event) => {
    adsManager = event.getAdsManager(contentPlayhead);
  }
);
```

**Anti-pattern — valor cacheado:**
```javascript
// MAL: el SDK siempre lee el mismo valor → cue points nunca se detectan
let cachedTime = 0;
videoElement.addEventListener('timeupdate', () => { cachedTime = videoElement.currentTime; });
const contentPlayhead = { getCurrentTime: () => cachedTime }; // MAL
```

**Por qué el segundo falla:** `timeupdate` puede dispararse hasta ~250ms después del frame actual. Si el SDK consulta `getCurrentTime()` justo entre dos eventos `timeupdate`, recibe un valor con hasta 250ms de retraso. Con cue points cercanos al umbral de detección, esto puede hacer que el SDK los salte. Leer `videoElement.currentTime` directamente elimina este retraso.

---

## 3. Video.js + IMA SDK

**Plugin oficial:** `videojs-ima` (Google, open source)

**Integración básica:**
```javascript
const player = videojs('video-element', { ... });

player.ima({
  adTagUrl: 'https://pubads.g.doubleclick.net/gampad/ads?...',
  debug: false,
  timeout: 5000,
  // Para CTV: desactivar autoplay de ads si la política lo requiere
  autoPlayAdBreaks: true
});
```

**Eventos relevantes para monitoreo:**
```javascript
player.ima.addEventListener(google.ima.AdEvent.Type.AD_ERROR, (event) => {
  console.error('IMA error:', event.getError().getErrorCode());
  // No bloquear playback — el plugin gestiona resume automáticamente
});

player.ima.addEventListener(google.ima.AdEvent.Type.ALL_ADS_COMPLETED, () => {
  // Opcional: analytics
});
```

**Quirks en Tizen / webOS (WebView):**
- El plugin crea un `<div>` para el `AdDisplayContainer`. En algunos firmwares de Tizen, el `z-index` no se respeta correctamente → el ad se renderiza detrás del contenido. Solución: establecer explícitamente `position: absolute` y `z-index: 9999` en el contenedor de ads.
- Memory leaks: si el usuario navega entre contenidos sin destruir el player, `videojs-ima` puede retener referencias. Llamar `player.ima.destroy()` antes de `player.dispose()`.

---

## 4. JW Player: ad schedule y callbacks

JW Player tiene su propia capa de abstracción de ads sobre IMA SDK.

**Configuración con ad schedule (VMAP):**
```javascript
jwplayer('player').setup({
  file: 'https://cdn.example.com/content.m3u8',
  advertising: {
    client: 'googima',
    adscheduleid: 'pre_mid_post',
    schedule: {
      adbreak1: {
        offset: 'pre',
        tag: 'https://pubads.g.doubleclick.net/gampad/ads?...'
      },
      adbreak2: {
        offset: '00:10:00',
        tag: 'https://pubads.g.doubleclick.net/gampad/ads?...'
      }
    }
  }
});
```

**Alternativa con Master Video Tag (GAM Ad Rules):**
```javascript
advertising: {
  client: 'googima',
  tag: 'https://pubads.g.doubleclick.net/gampad/ads?ad_rule=1&...'
  // GAM devuelve VMAP; JW Player deja que IMA SDK gestione todos los breaks
}
```

**Callbacks de diagnóstico:**
```javascript
jwplayer().on('adError', (event) => {
  console.log('Ad error:', event.message, event.tag);
});
jwplayer().on('adRequest', (event) => {
  console.log('Ad request fired:', event.tag);
});
jwplayer().on('adImpression', (event) => {
  console.log('Ad impression:', event.adtitle);
});
```

**Limitación JW Player en CTV:** la versión web de JW Player (HTML5) en Tizen/webOS tiene el mismo comportamiento de WebView que Video.js. Para Android TV/Fire TV, JW Player ofrece un SDK nativo separado que no usa IMA SDK directamente — verificar documentación de JW Player SDK for Android si es el caso.

---

## 5. Shaka Player: ad manager e integración

Shaka Player tiene un `ui.Overlay` y un `ads.Client` experimental para IMA SDK. Es el player más usado en Android TV via ExoPlayer (en su variante Android), pero también disponible en HTML5.

**Integración HTML5 con IMA:**
```javascript
const video = document.getElementById('video');
const ui = new shaka.ui.Overlay(player, video.parentElement, video);
const adManager = player.getAdManager();

adManager.initClientSide(
  ui.getControls().getClientSideAdContainer(),
  video
);

const adRequest = new google.ima.AdsRequest();
adRequest.adTagUrl = 'https://pubads.g.doubleclick.net/gampad/ads?...';

adManager.requestClientSideAds(adRequest);
```

**Nota:** la integración IMA de Shaka es marcada como experimental en algunas versiones. Verificar la versión exacta de Shaka antes de asumir que `getAdManager()` está disponible.

**Shaka + DAI (SSAI):**
```javascript
adManager.initServerSide(
  ui.getControls().getServerSideAdContainer(),
  video
);
const streamRequest = new google.ima.dai.api.VodStreamRequest();
streamRequest.contentSourceId = 'CONTENT_SOURCE_ID';
streamRequest.videoId = 'VIDEO_ID';
adManager.requestServerSideStream(streamRequest);
```

---

## 6. ExoPlayer (Android TV) + IMA extension

**Dependencia:**
```gradle
implementation 'com.google.android.exoplayer:extension-ima:2.x.x'
```

**Integración:**
```kotlin
val imaAdsLoader = ImaAdsLoader.Builder(context)
    .setAdEventListener(adEventListener)
    .build()

val player = ExoPlayer.Builder(context).build()
val mediaSource = buildMediaSourceWithAds(
    contentUri,
    Uri.parse("https://pubads.g.doubleclick.net/gampad/ads?..."),
    imaAdsLoader,
    playerView
)

player.setMediaSource(mediaSource)
player.prepare()
```

**Destroy correcto:**
```kotlin
override fun onDestroy() {
    imaAdsLoader.release()  // liberar IMA antes que el player
    player.release()
    super.onDestroy()
}
```

**Quirks Android TV:**
- `ImaAdsLoader` gestiona `ContentPlayhead` internamente al integrarse con ExoPlayer — no hace falta implementarla manualmente.
- En Fire TV (Fire OS), la integración es idéntica. Solo difiere el mecanismo de obtención del device ID (AFAI vs GAID).
- `AD_ID` permission en `AndroidManifest.xml` es obligatorio para recibir el GAID. Sin él, el campo llega vacío → fill bajo en programática.

---

## 7. AVPlayer (tvOS) + IMA iOS SDK

**Constraint de Apple:** en tvOS no se puede usar un player propio para contenido DRM o en apps distribuidas en App Store. AVPlayer es obligatorio.

**Integración básica:**
```swift
let adsLoader = IMAAdsLoader(settings: nil)
adsLoader.delegate = self

let adDisplayContainer = IMAAdDisplayContainer(
    adContainer: self.view,
    viewController: self
)

let request = IMAAVPlayerContentPlayhead(avPlayer: player)
// IMAAVPlayerContentPlayhead implementa ContentPlayhead automáticamente
// leyendo avPlayer.currentTime() directamente — no hay que implementarla manualmente

let adsRequest = IMAAdsRequest(
    adTagUrl: "https://pubads.g.doubleclick.net/gampad/ads?...",
    adDisplayContainer: adDisplayContainer,
    contentPlayhead: request,
    userContext: nil
)
adsLoader.requestAds(with: adsRequest)
```

**ATT (App Tracking Transparency) en tvOS 14.5+:**
```swift
ATTrackingManager.requestTrackingAuthorization { status in
    let idfa = status == .authorized
        ? ASIdentifierManager.shared().advertisingIdentifier.uuidString
        : "00000000-0000-0000-0000-000000000000"
    // Pasar idfa como rdid en la ad tag URL
}
```
Si no se solicita ATT o el usuario deniega → IDFA es todos ceros → programática sin targeting → CPM bajo. Es un prerequisito de monetización, no opcional.

---

## 8. hls.js / dash.js en entornos web-based CTV

hls.js y dash.js son parsers/players de bajo nivel usados frecuentemente en Tizen y webOS cuando el publisher construye su propio player en lugar de usar Video.js/Shaka.

**hls.js + IMA SDK (patrón manual):**
```javascript
const hls = new Hls();
hls.loadSource('https://cdn.example.com/content.m3u8');
hls.attachMedia(videoElement);

// IMA SDK se inicializa en paralelo, sobre el mismo videoElement
const adDisplayContainer = new google.ima.AdDisplayContainer(adContainer, videoElement);
const adsLoader = new google.ima.AdsLoader(adDisplayContainer);

// ContentPlayhead: leer currentTime directamente (ver §2)
const contentPlayhead = { getCurrentTime: () => videoElement.currentTime };
```

**Importante:** hls.js no gestiona cue points de ads — esa responsabilidad es del IMA SDK. hls.js gestiona el streaming del contenido; IMA SDK detecta cuándo pausarlo para un ad break.

**dash.js es menos común en CTV** porque DASH no es el formato dominante en Tizen/webOS (prefieren HLS). Relevante principalmente en Android TV cuando se construye un player web-based (caso raro).

---

## 9. Anti-patterns de integración player + SDK

| Anti-pattern | Síntoma | Causa | Solución |
|---|---|---|---|
| `ContentPlayhead` retorna valor cacheado | Mid-rolls nunca disparan o se disparan tarde | `getCurrentTime()` no lee del player en tiempo real | Leer `videoElement.currentTime` directamente [Probable] |
| Crear `AdDisplayContainer` después de `requestAds` | SDK lanza error de inicialización; ads no cargan | SDK necesita el container antes de cualquier request | Crear container en `init()`, siempre antes de cualquier request [Verificado: IMA SDK docs] |
| No llamar `adsManager.destroy()` al cambiar contenido | Ads de contenido anterior interfieren; comportamiento indefinido | AdsManager retiene estado y listeners | `destroy()` obligatorio antes de nuevo `AdsLoader.requestAds()` [Verificado] |
| Player intenta parsear VAST o construir URLs de tracking | Lógica duplicada, tracking inconsistente | Confusión de responsabilidades | El player solo gestiona playback y `ContentPlayhead`; todo lo demás es del SDK |
| `muted` no declarado en autoplay en WebView (Tizen/webOS) | WebView bloquea reproducción del ad | Política de autoplay de Chromium engine en WebView | `vpa=auto&vpmute=1` si muted; o gestionar permiso de autoplay explícitamente |
| No implementar `ContentPlayhead` en integración manual | Mid-rolls nunca disparan | SDK no puede detectar posición del player | Implementar siempre cuando se usa IMA SDK sin ExoPlayer/AVPlayer |
| Bloquear content en `AD_ERROR` esperando recuperación | Blank screen; usuario bloqueado | La app espera un ad que no va a llegar | SDK auto-resume; app solo loggea y nunca bloquea playback [Verificado] |
| `AdsLoader` instanciado múltiples veces por sesión | Memory leaks, comportamiento impredecible | Reutilizar el mismo `AdsLoader` para múltiples requests | Un `AdsLoader` por sesión de player; múltiples `requestAds()` sobre el mismo loader |
