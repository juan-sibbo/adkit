# QA y Observabilidad — Referencia técnica

## 1. Test matrix priorizado por market share europeo

**Priorización de testing (Europa):**

| Prioridad | Plataformas | % esfuerzo | Market share aprox. |
|---|---|---|---|
| Alta | Samsung Tizen (latest + legacy 2.4), LG webOS (latest) | 50% | ~50% |
| Media | Android TV, Fire TV | 30% | ~25% |
| Baja | Apple TV, Roku, consolas | 20% | ~15% |

**Dimensiones del test matrix:**

| Dimensión | Valores a testear |
|---|---|
| OS/device | Tizen 5.5+, Tizen 2.4 (legacy), webOS 5.0+, Android TV 10+, Fire TV Gen 3 |
| Resolución | 1080p, 720p (legacy), 4K (si aplica) |
| Red | WiFi fiber (50+ Mbps), WiFi estándar (20 Mbps), mobile hotspot (5 Mbps), throttled 3G (simulado) |
| Contenido | VOD, Live, FAST |
| Posición | Pre-roll, mid-roll, post-roll |

**Mínimo viable:** 3 OS × 2 resoluciones × 2 redes × 2 contenidos = 24 combinaciones.

---

## 2. Checklist pre-lanzamiento por bloques

### Configuración GAM
- [ ] App registrada y reclamada en GAM
- [ ] app-ads.txt publicado y validado
- [ ] Ad units creados con nomenclatura consistente
- [ ] Key-values definidos
- [ ] Line items configurados (directos + house ads)
- [ ] Creatividades subidas y aprobadas (múltiples resoluciones)
- [ ] Ad Rules configuradas (timing correcto)
- [ ] Frequency caps establecidos
- [ ] Unified Pricing Rules (floors por geo/content)
- [ ] Open Bidding yield groups activos
- [ ] Third-party verification configurada (OMID vendors)

### Integración técnica
- [ ] IMA SDK (o PAL/PAI) integrado correctamente
- [ ] Device ID se obtiene y pasa (rdid, idtype, is_lat)
- [ ] cust_params se construyen dinámicamente y están URL-encoded
- [ ] GDPR consent string se pasa (gdpr, gdpr_consent)
- [ ] Content metadata incluida (vid o cust_params)
- [ ] Session ID implementado (fallback is_lat=1)
- [ ] Error handling robusto (timeouts, no-fill, VAST errors)
- [ ] Fallback strategy implementada (ad → house → content)
- [ ] Event tracking funcional (impression, quartiles, complete)

### Metadata y contenido
- [ ] MRSS feed configurado y GAM sincroniza (si aplica)
- [ ] Content bundles diseñados
- [ ] IAB taxonomy mapeada
- [ ] Content ratings asignados
- [ ] Cue points definidos

### Testing
- [ ] Test matrix ejecutado (mínimo 5 devices)
- [ ] Red lenta testeada (timeout funciona)
- [ ] No-fill testeado (app no se congela)
- [ ] Error VAST testeado (403, 404, timeout)
- [ ] Device ID validado (formato, tipo, LAT handling)
- [ ] Consent string validada

### Performance
- [ ] Latencia ad request <5s (median)
- [ ] Timeout handling funcional
- [ ] Sin memory leaks después de 10+ ad breaks
- [ ] CPU razonable durante ad playback

---

## 3. Herramientas de debugging

| Herramienta | Para qué | Plataformas |
|---|---|---|
| **GAM Publisher Console** | Ver line items elegibles, razones de no-match | Todas (web-based) |
| **Charles Proxy / Proxyman** | Interceptar tráfico HTTP/HTTPS del device | Todas (requiere proxy en misma WiFi) |
| **Google Video Suite Inspector** | Validar VAST XML | Todas (web-based) |
| **adb logcat** | Logs del SDK en Android TV/Fire TV | Android TV, Fire TV |
| **Xcode Console** | Logs del SDK en tvOS | Apple TV |
| **Tizen Web Inspector** | Console JavaScript en Samsung | Samsung Tizen |
| **Network Link Conditioner** | Simular red lenta | Mac (proxy a device) |
| **curl** | Fetch manual de VAST URL y MediaFile URL | Diagnóstico manual |

---

## 4. SLAs internos (entre AdOps y Dev/CMS)

| SLA | Descripción | Target |
|---|---|---|
| Frescura del dato | Frecuencia de actualización de metadata MRSS | Cada 6-12h |
| Disponibilidad device ID | % de ad requests con rdid válido | 100% (cuando is_lat=0) |
| Timeout CMS | Tiempo máximo que la app espera metadata antes de ad request sin ella | 2s |
| Auditoría PPS | Verificar que cust_params enviados coinciden con CMS | Mensual |

---

## 5. KPIs de referencia

| KPI | Qué medir | Alertar si |
|---|---|---|
| Fill rate | Impresiones servidas / ad requests | <40% (general) o caída >10% en 24h |
| Error rate | Errores VAST / ad requests totales | >5% |
| Latencia (p50) | Tiempo ad request → primer frame de ad | >3s (CTV), >2s (live) |
| VCR | Completions / starts | <80% en CTV |
| Discrepancia | GAM vs SSP/DSP | >12% |
| House ad rate | House ads / total impresiones servidas | >5% (indica falta de demanda) |
