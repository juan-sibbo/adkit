# HLS / DASH — Referencia técnica

## 1. Manifests y ad insertion points

### HLS (HTTP Live Streaming)
- Apple standard, soportado universalmente en CTV
- Master playlist (`.m3u8`) → media playlists → segmentos (`.ts` o `.fmp4`)
- Ad insertion points marcados por:
  - `#EXT-X-CUE-OUT` / `#EXT-X-CUE-IN` (método legacy)
  - `#EXT-X-DATERANGE` (método moderno, HLS spec)
  - Señales SCTE-35 embebidas en segmentos o manifest

### DASH (Dynamic Adaptive Streaming over HTTP)
- ISO standard (MPEG-DASH), usado en Android TV, Fire TV, some Smart TVs
- MPD (Media Presentation Description) → Periods → AdaptationSets → Representations → Segments
- Ad insertion points marcados por:
  - `<Period>` boundaries (nuevo Period = potencial ad break)
  - `<EventStream>` con mensajes SCTE-35
  - `<InbandEventStream>` para señales in-band

### Apple TV / tvOS
- Solo HLS (DASH no soportado nativamente)
- HLS Interstitials (HLS spec extension) para ad insertion nativa — pero raramente usado para programática

---

## 2. SCTE-35 en streams

**SCTE-35** señaliza ad insertion opportunities en broadcast/cable, y se traslada a OTT/CTV via manifests.

**En HLS:**
```
#EXT-X-CUE-OUT:DURATION=120.0
[ad segments aquí]
#EXT-X-CUE-IN
```
O via `#EXT-X-DATERANGE` con atributos SCTE-35:
```
#EXT-X-DATERANGE:ID="splice-123",START-DATE="2025-01-01T20:15:00Z",
PLANNED-DURATION=120.0,SCTE35-CMD=0xFC...
```

**En DASH:**
```xml
<EventStream schemeIdUri="urn:scte:scte35:2013:xml">
  <Event duration="1200000" id="123">
    <scte35:SpliceInfoSection>
      <scte35:SpliceInsert spliceEventId="123" outOfNetworkIndicator="true"/>
    </scte35:SpliceInfoSection>
  </Event>
</EventStream>
```

---

## 3. Ad insertion en manifest (SSAI)

**Cómo funciona stitching:**
1. SSAI provider recibe manifest original del content
2. Provider detecta SCTE-35 markers
3. Provider hace ad request a GAM
4. Provider recibe VAST response con MediaFile URL
5. Provider reemplaza segmentos marcados con segmentos del ad (transcodificados a mismo formato)
6. Provider entrega manifest modificado al device

**Requisitos para stitching correcto:**
- Ad creative debe estar transcodificado al mismo codec, bitrate, y formato de segmentos que el content
- Misma duración de segmento (típicamente 2-6s)
- Misma estructura de audio (sample rate, canales)
- Si mismatch → glitches, audio desync, o black frames en transiciones

---

## 4. Diagnóstico de problemas de manifest

| Síntoma | Verificar en manifest | Causa probable |
|---|---|---|
| Mid-rolls no se insertan | ¿Hay SCTE-35 markers? | Encoder no inserta markers |
| Black screen en transición | ¿Hay gap entre content y ad segments? | Stitching incorrecto, segmentos de ad no alineados |
| Audio desync | ¿Mismo codec/sample rate en content y ad? | Mismatch de audio params |
| Ad se corta | ¿Duración del slot vs duración del ad? | Slot más corto que creative |
| Buffering en ad | ¿Bitrate del ad vs bandwidth? | Ad con bitrate excesivo para la conexión |

**Herramientas de diagnóstico:**
- `ffprobe` para inspeccionar propiedades de segmentos
- Descarga manual de manifest y verificación de estructura
- Player developer tools (si disponibles) para timeline de segmentos

---

## 5. CMAF vs fMP4 vs TS en SSAI

| Formato | Contenedor | Uso CTV | Stitching SSAI |
|---|---|---|---|
| MPEG-TS (`.ts`) | Legacy | Android TV legacy, HbbTV, STBs | Tolerante a pequeñas desincronías de PTS; más fácil de stitch |
| fMP4 (`.mp4` fragmentado) | Moderno | tvOS, Tizen 5.5+, webOS 5+ | Requiere alineación exacta de `tfdt` timestamps entre content y ad |
| CMAF | fMP4 + HLS + DASH unificados | Tier 1 devices | Un solo asset sirve HLS y DASH; mayor complejidad de pipeline |

**Implicaciones para SSAI:**

- **MPEG-TS:** stitch más tolerante porque el muxer puede absorber pequeños gaps de PTS. Sigue siendo el denominador común en pipelines legacy.
- **fMP4:** el SSAI provider debe asegurar que el `Movie Fragment` del primer segmento de ad continúa el timeline de PTS del último segmento de content. Si hay discontinuidad → black frames o freeze en transición.
- **CMAF:** si el proveedor no soporta CMAF nativo, necesitas dos pipelines paralelos (HLS TS para devices legacy, DASH fMP4 para Android TV/Fire TV). Coste operativo real.

**Diagnóstico de mismatch de contenedor:**
```bash
ffprobe -v quiet -print_format json -show_streams segment_content.ts
ffprobe -v quiet -print_format json -show_streams segment_ad.ts
```
Comparar `codec_name`, `sample_rate`, `r_frame_rate` entre segmento de content y segmento de ad.

---

## 6. HLS Interstitials (referencia, no usar para programática estándar)

- Extensión de la HLS spec de Apple (`#EXT-X-DATERANGE` con `X-ASSET-URI`) para inserción nativa en AVPlayer
- **No se usa en programática CTV estándar** — no hay integración con GAM/IMA SDK por esta vía
- AVPlayer con IMA SDK sigue usando CSAI: IMA gestiona el ad break, AVPlayer pausa el content
- Relevante solo si el publisher construye un player propio en tvOS sin IMA SDK y quiere ad insertion nativa del OS
- Mencionar para descartar explícitamente cuando alguien pregunta por "ad insertion nativa en tvOS"
