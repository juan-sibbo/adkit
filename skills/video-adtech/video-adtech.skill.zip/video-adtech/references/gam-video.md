# GAM Video — Referencia técnica

## Tabla de contenidos
1. App registration y prerrequisitos
2. Ad Rules y Master Video Tag
3. Ad Pods: fixed vs dynamic, bumpers
4. Competitive exclusion y correlator
5. Pod bidding (AdX)
6. MRSS → GAM (Video Content Sources)
7. Content ID vs cust_params
8. WTA compliance en GAM
9. Open Bidding server-side
10. Server-Side Unwrapping (SSU) config
11. Publisher Provided Signals (PPS) en GAM
12. Yield groups y demand channels

---

## 1. App registration y prerrequisitos

Verificar PRIMERO en diagnóstico de fill bajo:

- [ ] App registrada en GAM: Inventario > Aplicaciones > app reclamada y activa
- [ ] Store ID correcto por plataforma (formato varía: Roku numérico, Samsung con prefijo G, etc.)
- [ ] app-ads.txt publicado en dominio del desarrollador y validado (IAB crawler)
- [ ] Ad unit configurado como tipo vídeo (no display)
- [ ] Parámetro `msid` (bundle ID / app ID) llegando correcto en la VAST tag
- [ ] `an` (app name) presente en la tag

**Consecuencia de app-ads.txt inválido:** DSPs bloquean el inventario → fill rate cae drásticamente.

---

## 2. Ad Rules y Master Video Tag

**Ad Rules:** motor de GAM que define cuándo/dónde/cuántos ads insertar.

**Componentes:**
- **Ad break timing:** pre-roll (0:00), mid-rolls (cada X min o en cue points), post-roll (end)
- **Pod config:** max duración, max ads por pod, duraciones permitidas (15s, 30s)
- **Restricciones:** no mid-roll antes de min 5, no post-roll si content <10min, separación mínima entre mid-rolls

**Master Video Tag:** URL única con `ad_rule=1` que contiene toda la configuración. Se pasa al IMA SDK una vez; SDK gestiona todos los ad breaks automáticamente basándose en el VMAP response de GAM.

Parámetros obligatorios en la tag:
- `iu` (ad unit path)
- `sz` (size, tipicamente 640x480)
- `env=vp` (video player)
- `gdfp_req=1` (request a GAM)
- `output=xml_vast4` (o xml_vast3)
- `correlator` (timestamp para cache-busting y competitive exclusion)
- `ad_rule=1` (si usa Ad Rules)
- `cmsid` + `vid` (si usa Video Content Sources)

---

## 3. Ad Pods: fixed vs dynamic, bumpers

**Fixed duration pod:** siempre X segundos (ej: 120s). Si no hay suficientes ads → rellenar con house ads o dejar gap.
**Dynamic duration pod:** duración varía según fill. Mejor UX (sin house ads forzados) pero revenue menos predecible.

**Bumpers:** slates breves (3-5s) antes/después del pod.
- **Implementación recomendada:** app-side (no consume ad request, no afecta métricas)
- **Implementación alternativa:** GAM como line item priority máxima (cuenta como impresión)

---

## 4. Competitive exclusion y correlator

**Competitive exclusion labels:** en GAM, Admin > Inventario > Competitive Exclusion Labels. Asignar a advertisers que no deben aparecer en el mismo pod.

**Correlator:** parámetro numérico (timestamp) en la ad tag.
- Mismo correlator = misma "page view" / sesión de contenido [Verificado]
- GAM usa correlator para:
  - Competitive exclusion dentro del pod (no servir 2 ads con mismo label)
  - Roadblocking (servir ads del mismo campaign juntos)
  - Deduplicación (no servir el mismo creative repetido en el mismo pod)
- **Nuevo correlator = nuevo contenido** [Verificado]
- **Anti-pattern:** reutilizar correlator entre contenidos diferentes → competitive exclusion se aplica incorrectamente

---

## 5. Pod bidding (AdX)

- Buyers pueden pujar por posición específica dentro del pod
- Posiciones premium: 1st (mayor attention) y last (recency effect)
- Habilitado automáticamente en AdX para CTV [Probable]
- Configuración de pricing diferencial por posición via line items con targeting de pod position

---

## 6. MRSS → GAM (Video Content Sources)

- GAM ingesta feeds MRSS via Video > Content Sources [Verificado]
- Frecuencia de sincronización configurable [Verificado]
- Campos obligatorios: `<guid>` (content ID), `<title>`, `<media:content>` (URL + duration)
- Campos recomendados: `<media:category>`, `<media:rating>`, `<media:keywords>`
- Cue points desde MRSS: `<media:cuepoint time="300"/>` [Verificado]
- Latencia de ingesta: típicamente 1-2 horas post-crawl

---

## 7. Content ID vs cust_params

**Método preferido (GAM native):** Content ID via MRSS
- Ad request solo pasa `vid=CONTENT_ID` + `cmsid=CMS_ID`
- GAM enriquece automáticamente con metadata del Content
- Ventaja: URL corta, metadata centralizada

**Método alternativo:** metadata en cust_params
- `cust_params=genre%3Ddrama%26rating%3Dtv_ma`
- Ventaja: flexible, no requiere pre-registro
- Limitación: URL length ~2000 chars, encoding manual

**Cuándo usar cada uno:** Content ID si catálogo estable y pre-registrado en MRSS; cust_params si contenido muy dinámico o third-party.

---

## 8. WTA compliance en GAM

- Configurable a nivel de red: Admin > WTA settings
- Si activo: GAM requiere que ads puedan mostrar transparencia
- CTV: muchos user agents no soportan rendering WTA → `wta=0`
- Si `wta=0` y no hay creativos non-personalized → VAST vacío [Probable]
- Ver ima-sdk.md §6 para diagnóstico detallado

---

## 9. Open Bidding server-side

**Qué es:** subasta server-side en GAM donde múltiples SSPs/exchanges compiten.

**Diferencia con client-side header bidding:**
- Client-side (Prebid): device ejecuta auction en paralelo → latencia 1-3s, CPU intensive
- Server-side (Open Bidding): GAM server ejecuta auction → latencia más baja [heurística: 200-500ms, depende de partners y red]

**Partners típicos CTV Europa:** Xandr (Microsoft), Magnite, Index Exchange, PubMatic

**Configuración:** Admin > Yield Management > Yield Partners

**Trade-off:** más partners = más competencia = mejor yield, pero también más latencia potencial. En CTV con timeout agresivo, limitar a 3-5 partners.

---

## 10. Server-Side Unwrapping (SSU)

Ver vast-vmap.md §5 para detalle técnico.

**Configuración en GAM:** Admin > Video > Server-side ad unwrapping
- Habilitar para ads de vídeo
- Max redirects configurable
- Timeout por redirect configurable

---

## 11. Publisher Provided Signals (PPS) en GAM

**Configuración:**
1. Admin > Publisher Provided Signals: definir señales custom, mapear a IAB taxonomy
2. Admin > Programmatic Setup > Demand Channels: habilitar sharing por canal (Authorized Buyers, Open Bidding, Open Auction)
3. Señales se pasan automáticamente en bid request OpenRTB

**Tipos de señales:**
- Contextuales: género, rating, keywords del contenido
- Audiencia: segmentos first-party (high-value viewers, binge watchers)
- Técnicas: device type, OS, connection type

**Impacto:** más señales → DSPs pujan mejor → CPMs más altos, más competencia en auction, mejor fill.

---

## 12. Yield groups y demand channels

**Yield groups:** agrupaciones de yield partners (Open Bidding) para inventario específico.
- Crear yield group por tipo de inventario (CTV Sports, CTV VOD, etc.)
- Asignar SSPs específicos por grupo
- Configurar floors por yield group

**Demand channels:** tipos de demanda que acceden al inventario
- Google Ads
- Display & Video 360
- Authorized Buyers
- Open Bidding partners

**Verificar en diagnóstico de fill bajo:** ¿hay yield groups activos para el tipo de inventario CTV?
