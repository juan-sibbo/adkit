# Measurement CTV — Referencia técnica

## Tabla de contenidos
1. OMID (Open Measurement) en CTV
2. Inferred Viewability: metodología GAM
3. Tracking beacons: ciclo de vida
4. Discrepancias GAM vs SSP/DSP
5. VCR (Video Completion Rate)
6. Frequency capping con Device IDs

---

## 1. OMID (Open Measurement) en CTV

**Qué es:** IAB Tech Lab standard (v1.3+) que unifica medición de viewability/fraud/brand safety. Un SDK, múltiples vendors.

**Sin OMID:** integrar 5 SDKs de medición por separado.
**Con OMID:** IMA SDK incluye OM SDK built-in. Vendors proporcionan verification scripts via `<AdVerifications>` en VAST 4.x.

**Flujo:**
1. GAM genera VAST con `<AdVerifications>` node
2. IMA SDK parsea, detecta vendors (Moat, IAS, DoubleVerify)
3. SDK carga OM SDK + verification scripts
4. Vendors miden viewability, fraud, brand safety
5. Vendors reportan a sus plataformas

**Configuración GAM:** Admin > Video > Third-party verification > añadir providers

**Métricas medidas:**
- **Viewability** (MRC standard): 50% pixels visibles, 2s continuos
- **Fraud detection**: invalid traffic, device spoofing, geo-spoofing
- **Brand safety**: verificación de contenido

**Impacto en CPM:** inventario OM-verified puede comandar +10-15% CPM vs no verificado.

**Limitación CTV:** en devices sin soporte de OM SDK → Inferred Viewability (ver §2).

---

## 2. Inferred Viewability: metodología GAM

**Qué es:** metodología de GAM para devices/entornos donde medición directa OMID no es posible.

**Cuándo se usa:**
- CTV devices legacy sin soporte OM SDK
- Gaming consoles (entornos restringidos)
- Set-top boxes con SDKs limitados

**Metodología [Probable — GAM no publica detalles internos exactos]:**
- Inventario tipo in-stream video (linear ad en content stream)
- Asunción: CTV = full screen, no otros windows/tabs → 100% in-screen durante playback
- Si ad reproduce ≥2s continuos → se cuenta como viewable (MRC standard para video)
- Si skip/error antes de 2s → no viewable

**Reporting en GAM:**
- Dimension: "Measurement Source with Active View" [Verificado]
- Valores: "Direct" (OM SDK medición directa) vs "Inferred"
- Filtrar por Measurement Source = "Inferred" para ver inventario CTV con esta metodología

**Limitaciones de Inferred — qué NO puede detectar:**
- Si la TV está encendida pero nadie la mira
- Atención del viewer (mirando TV vs teléfono)
- Nivel de audio (TV silenciada)
- Fraude sofisticado (bot que reproduce 2s+)

**Impacto en pricing:** inventario Inferred puede tener ligero descuento vs OM-verified (~5% CPM), pero es aceptado por la industria para CTV.

---

## 3. Tracking beacons: ciclo de vida

**Timeline de un ad de 30s:**
```
0.00s → impression (ad comienza a renderizar)
0.00s → start (playback comienza)
7.50s → firstQuartile (25%)
15.0s → midpoint (50%)
22.5s → thirdQuartile (75%)
30.0s → complete (100%)
```

**Cada beacon = GET request a tracking URL.** Response ignorada (fire-and-forget).

**Múltiples tracking pixels:** VAST puede contener múltiples URLs por evento (GAM + advertiser + third-party verification). Todos se disparan simultáneamente.

**Error beacon:** `<Error>` node con macro `[ERRORCODE]`. Se dispara si el ad falla.

**En SSAI:** beacons deben dispararse server-side si el player no tiene visibilidad de los ads en el stream. Ver ssai-sgai-dai.md §2.

---

## 4. Discrepancias GAM vs SSP/DSP

**Rango aceptable:** 0-10% discrepancia [heurística de industria].
**Investigar si:** >10-12%.
**Problema serio si:** >15%.

**Causas comunes:**

| Causa | Efecto | Quién cuenta más |
|---|---|---|
| Timing diferente de impression pixel | GAM dispara al responder VAST; DSP al iniciar playback | GAM (cuenta ads que no llegaron a reproducirse) |
| Filtros IVT del DSP | DSP filtra tráfico inválido más agresivamente | DSP (cuenta menos) |
| DNS-based ad blockers (Pi-hole) | Bloquean tracking domains | GAM (DSP pixel bloqueado) |
| Network timeouts | GAM pixel dispara OK; DSP pixel timeout | GAM (cuenta más) |
| Attribution window | GAM cuenta si starts antes de midnight; DSP si completes | Depende del evento y timezone |
| Timezone mismatch | Reports en UTC vs local time | Mismatch artificial |

**Proceso de reconciliación:**
1. Pull reports mismas fechas, mismo timezone
2. Comparar day-by-day
3. Identificar outliers (>10% en un día específico → investigar)
4. Acordar source of truth: promedio, GAM, DSP, o third-party neutral
5. Credit/debit si hay under/over-delivery

---

## 5. VCR (Video Completion Rate)

**Fórmula:** (Completions / Starts) × 100

**Rangos habituales CTV** [heurística de industria, sin fuente verificable específica]:
- CTV: significativamente más alto que web video
- Factores: lean-back experience, no skip button típicamente, full screen

**Factores que afectan VCR:**
- Posición del ad: pre-roll > mid-roll early > mid-roll late > post-roll
- Calidad del creative: buffering → drop-off
- Duración: 15s suele tener mayor completion que 60s
- Ad load: demasiados ads → viewer fatigue → abandono

**VCR bajo como señal de diagnóstico:**
- <80% en CTV → investigar: creatividades rotas, VAST wrapper defectuoso, codec issues, bitrate excesivo para el device/red

---

## 6. Frequency capping con Device IDs

**Mecanismo:** GAM trackea cuántas veces un device ID (rdid) ha visto un creative/advertiser.

**Configuración GAM:** Line Item Settings > Frequency Caps
- Nivel creative: max N per day
- Nivel advertiser: max N per day
- Nivel campaign: max N per week

**Limitaciones CTV:**

| Limitación | Impacto | Mitigación |
|---|---|---|
| Requiere rdid válido con is_lat=0 | Sin rdid → sin frequency cap | Session ID (sid) para cap intra-sesión |
| Household-level, no user-level | 3 viewers × cap 3/day = 9 exposiciones hogar | Caps conservadores (5-7/day para household) |
| No cross-device | 2 TVs = 2 device IDs = caps independientes | Sin solución nativa |
| User puede resetear ID | Cap se pierde al resetear | Impacto mínimo (pocos users lo hacen) |
