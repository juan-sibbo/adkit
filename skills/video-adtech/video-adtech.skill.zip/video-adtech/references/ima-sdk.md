# IMA SDK — Referencia técnica

## Tabla de contenidos
1. Variantes del SDK por plataforma
2. Comparativa IMA SDK vs PAL SDK vs SDK-less (PAI)
3. Ciclo de vida del SDK
4. Tabla de responsabilidades Player / SDK / App
5. Contratos de interface
6. WTA (Where The Ads) en CTV
7. PAL SDK: nonce y señales programáticas
8. Error handling y fallback strategy
9. Configuraciones clave

---

## 1. Variantes del SDK por plataforma

| Plataforma | SDK | Lenguaje | Notas CTV |
|---|---|---|---|
| Android TV | IMA Android SDK | Java/Kotlin | ExoPlayer recomendado; usa Google Play Services para GAID |
| tvOS / Apple TV | IMA iOS SDK | Swift/ObjC | AVPlayer obligatorio; requiere ATT framework para IDFA en iOS 14.5+ |
| Tizen (Samsung) | IMA HTML5 SDK | JavaScript | Ejecuta en WebView; acceso a TIFA via `webapis.adinfo.getTIFA()` |
| webOS (LG) | IMA HTML5 SDK | JavaScript | WebView + webOS media API; LGUDID via API propietaria LG |
| Fire TV | IMA Android SDK | Java/Kotlin | Fork Android; AFAI via `AdRegistration` API |
| Roku | IMA Roku SDK | BrightScript | Entorno propietario; RIDA via Roku API |
| Cast (Chromecast) | IMA CAF SDK | JavaScript | Receiver app; hereda device info del cast device |
| Web / HbbTV | IMA HTML5 SDK | JavaScript | HbbTV: perfiles 1.4/2.0/3.0 con limitaciones variables |

---

## 2. Comparativa IMA SDK vs PAL SDK vs SDK-less (PAI)

| Aspecto | IMA SDK | PAL SDK | SDK-less (PAI) |
|---|---|---|---|
| Ad request | ✅ Completo | ❌ No | ❌ No (server-side) |
| VAST parsing | ✅ Automático | ❌ No | ❌ Manual |
| Ad rendering | ✅ Automático | ❌ No | ❌ Manual |
| Tracking pixels | ✅ Automático | ❌ No | ❌ Manual |
| Señales programáticas | ✅ Automático | ✅ Via nonce | ⚠️ Limitado |
| Open Measurement | ✅ Built-in | ⚠️ Limitado | ❌ No |
| Google Ads demand | ✅ Sí | ❌ Solo AdX/AB | ❌ Solo AdX/AB |
| Complejidad integración | Baja | Media | Alta |
| Device support | Amplio | Amplio | Legacy sin SDK |

**Decision tree:**
- Player estándar (ExoPlayer, AVPlayer) → **IMA SDK**
- Player custom con lógica de ads propietaria → **PAL SDK** (captura señales sin modificar player)
- Device sin soporte SDK (STB legacy, consolas antiguas) → **SDK-less/PAI** (última opción)

---

## 3. Ciclo de vida del SDK

```
1. Crear ImaSdkSettings (una vez por app)
2. Crear AdDisplayContainer (una vez por sesión de player)
3. Crear AdsLoader (una vez por sesión de player)
4. Construir AdsRequest con ad tag URL
5. adsLoader.requestAds(adsRequest)
6. onAdsLoaded → obtener AdsManager
7. adsManager.init()
8. adsManager.start() → empieza pre-roll
9. SDK emite eventos: CONTENT_PAUSE_REQUESTED, STARTED, quartiles, COMPLETED, CONTENT_RESUME_REQUESTED
10. ALL_ADS_COMPLETED → todo el pod terminó
11. Al cambiar de contenido: adsManager.destroy()
12. Repetir desde paso 4 para nuevo contenido
```

**Regla crítica:** Siempre `destroy()` antes de crear nuevo AdsManager. Reutilizar sin destroy → comportamiento indefinido [Verificado].

---

## 4. Tabla de responsabilidades

| Función | Content Player | IMA SDK | App |
|---|---|---|---|
| Reproducir contenido | ✅ | ❌ | ❌ |
| Reportar playhead position | ✅ (cada ~250ms) | Consume | ❌ |
| Solicitar ads (ad request) | ❌ | ✅ | ❌ |
| Parsear VAST | ❌ | ✅ | ❌ |
| Reproducir creatividades | ❌ | ✅ | ❌ |
| Disparar tracking pixels | ❌ | ✅ (automático) | ❌ |
| Detectar cue points | ❌ | ✅ (monitorea playhead) | ❌ |
| Pause/resume content | ✅ (ejecuta) | Solicita via evento | Coordina |
| Error handling de ads | ❌ | ✅ (auto-resume) | Log + monitoring |
| Mostrar UI "Ad X of Y" | ❌ | ❌ | ✅ |

**Anti-pattern:** que el player intente gestionar VAST URLs, parsear wrappers, o disparar quartiles. Eso es responsabilidad del SDK.

---

## 5. Contratos de interface

**Player → SDK:** `ContentPlayhead` interface
- `getCurrentTime()` → posición en segundos (SDK llama ~4x/s para detectar cue points)
- `getDuration()` → duración total del contenido

**SDK → App:** eventos
- `CONTENT_PAUSE_REQUESTED` → app pausa content player
- `CONTENT_RESUME_REQUESTED` → app resume content player
- `STARTED`, `FIRST_QUARTILE`, `MIDPOINT`, `THIRD_QUARTILE`, `COMPLETED` → informativos
- `AD_ERROR` → SDK ya manejó; app solo log
- `ALL_ADS_COMPLETED` → pod completo terminó

**Regla fundamental:** NUNCA bloquear contenido por error de ads. Si ad falla → log, analytics, content resume automático.

---

## 6. WTA (Where The Ads) en CTV

WTA = "Why This Ad" / transparencia publicitaria.

**Comportamiento:**
- Si la red GAM tiene WTA compliance activo, GAM requiere que los ads puedan mostrar información de transparencia
- En CTV, muchos user agents no soportan el rendering de WTA overlay
- IMA SDK puede setear `wta=0` automáticamente basándose en el user agent [Probable]
- Si `wta=0` y no hay creativos non-personalized disponibles → GAM puede devolver VAST vacío (error 303) [Probable]

**Diagnóstico:**
1. Interceptar ad request → verificar si `wta=0` está presente
2. Publisher Console → verificar si hay creativos elegibles
3. Si el problema es WTA → verificar configuración de WTA compliance en GAM

**Mitigación:** asegurar que hay creativos non-personalized disponibles como fallback; o verificar la configuración de WTA para el tipo de inventario CTV.

---

## 7. PAL SDK: nonce y señales programáticas

**Qué hace PAL:**
- Genera un nonce (token criptográfico) que encapsula señales del entorno
- El nonce se pasa en la ad tag como parámetro `givn=`
- GAM usa el nonce para validar el entorno y mejorar señales programáticas

**Granularidad del nonce:**
- **Nuevo nonce por stream/contenido** [Verificado en docs PAL]
- Reutilizable para múltiples ad requests dentro del mismo stream
- Reutilizar entre streams diferentes → señales incorrectas [Probable: puede afectar detección de tráfico inválido]

**Plataformas PAL soportadas:** HTML5, tvOS, iOS, Android, Cast, Roku, Samsung Tizen

**Limitación PAL:** no tiene acceso a Google Ads demand (solo AdX, Authorized Buyers). Si se necesita Google Ads demand → usar IMA SDK.

---

## 8. Error handling y fallback strategy

**Waterfall de fallback recomendado:**

```
1. Ad request principal (GAM con Open Bidding)
   └─ Falla (timeout, error VAST, no-fill)
   ↓
2. Fallback tag (GAM directo, sin Open Bidding — menor latencia)
   └─ Falla
   ↓  
3. House ad desde GAM (priority 16, line item network)
   └─ Falla
   ↓
4. House ad local (asset bundled en app — instant, sin red)
   └─ Falla
   ↓
5. Resume content (nunca blank screen)
```

**Timeouts recomendados (heurística, medir en cada entorno):**
- CTV general: 5s
- Live TV: 2-3s (viewer menos tolerante)
- Legacy devices: 3s (CPU/red limitados)

---

## 9. Configuraciones clave

| Setting | Valor recomendado | Razón |
|---|---|---|
| `vastLoadTimeout` | 5000ms (CTV), 3000ms (live) | Balance entre fill y UX |
| `maxRedirects` | 3-5 | Limitar latencia de wrapper chains |
| `language` | ISO 639-1 del contenido | Localización de UI ads |
| `autoPlayAdBreaks` | true (default) | SDK gestiona ad breaks automáticamente |
