# Ad Request Signals — Referencia técnica

## Tabla de contenidos
1. Parámetros VAST URL completos
2. Device IDs por plataforma (idtype verificados)
3. PPID vs rdid
4. Session ID (sid) y is_lat=1 fallback
5. Consent signals (GDPR, COPPA)
6. Content signals y metadata
7. PPS y cust_params
8. Secure Signals
9. Buyer expectations en OpenRTB

---

## 1. Parámetros VAST URL completos

| Parámetro | Obligatorio | Descripción |
|---|---|---|
| `iu` | ✅ | Ad unit path en GAM |
| `sz` | ✅ | Tamaño (ej: 640x480) |
| `env=vp` | ✅ | Environment: video player |
| `gdfp_req=1` | ✅ | Request a GAM |
| `output` | ✅ | Formato: `xml_vast4`, `xml_vast3` |
| `correlator` | ✅ | Timestamp para cache-busting y competitive exclusion |
| `url` | Recomendado | App URL o bundle |
| `description_url` | Recomendado | URL del contenido (metadata) |
| `rdid` | Crítico CTV | Resettable Device ID |
| `idtype` | Crítico CTV | Tipo de ID (ver tabla §2) |
| `is_lat` | Crítico CTV | Limit Ad Tracking: 0=no, 1=yes |
| `msid` | Crítico CTV | App store ID / bundle ID |
| `an` | Recomendado | App name (human-readable) |
| `sid` | Recomendado | Session ID (efímero) |
| `dth` | Recomendado | Device type hint: 5=CTV |
| `plcmt` | Recomendado | Placement: 1=in-stream |
| `vpa` | Recomendado | Video playback: auto/click |
| `vpmute` | Recomendado | Muted: 0=unmuted, 1=muted |
| `cust_params` | Recomendado | Custom parameters URL-encoded |
| `cc` | Recomendado | Content category (IAB taxonomy) |
| `vid` | Recomendado | Video content ID (si usa MRSS/Content Sources) |
| `cmsid` | Recomendado | CMS ID (si usa MRSS) |
| `ad_rule` | Condicional | 1 si usa Ad Rules |
| `gdpr` | Condicional | 0/1 si audiencia en EEE |
| `gdpr_consent` | Condicional | TC String completo |
| `ppid` | Opcional | Publisher-provided ID (hash de login) |
| `givn` | Condicional | PAL nonce (si usa PAL SDK) |

---

## 2. Device IDs por plataforma

| Plataforma | Nombre del ID | idtype en VAST | API para obtener ID | Nivel evidencia |
|---|---|---|---|---|
| Samsung Tizen | TIFA | `tifa` | `webapis.adinfo.getTIFA()` | Probable (material fuente indica `ssai` pero inconsistente con docs Samsung) |
| LG webOS | LGUDID / LGADI | `lgudid` | API propietaria LG | Probable |
| Android TV | GAID | `adid` | `AdvertisingIdClient.getAdvertisingIdInfo()` | Verificado |
| Fire TV | AFAI | `afai` | `AdRegistration.getAdvertisingId()` | Probable |
| Apple TV | IDFA | `idfa` | `ASIdentifierManager.shared().advertisingIdentifier` | Verificado |
| Roku | RIDA | `rida` | Roku API | Verificado |

**Formato:** todos UUID v4 (36 caracteres con guiones).

**⚠️ Nota sobre Samsung:** el valor `ssai` como idtype aparece frecuentemente en material de la industria pero no está confirmado en documentación oficial de Google o Samsung. Usar `tifa` es más consistente con la nomenclatura de Samsung. Verificar con el SSAI provider o GAM support si hay dudas.

---

## 3. PPID vs rdid

| Campo | rdid | ppid |
|---|---|---|
| **Qué es** | Advertising device identifier (hardware/OS) | Publisher-provided ID (hash de login, ID de cuenta) |
| **Quién lo genera** | OS del device | Publisher |
| **Resettable** | Sí (por el usuario en settings) | No (controlado por publisher) |
| **Scope** | Device-level | User-level (cross-device si hay login) |
| **Uso** | Frequency capping, attribution, audience segments | Cross-session identity, first-party segments |
| **is_lat** | Sí (si user opt-out, no usar para targeting) | No aplica (es ID del publisher) |

**Anti-pattern:** pasar rdid como valor de ppid → campos semánticamente distintos [Verificado]. Mantenerlos separados.

---

## 4. Session ID (sid) y is_lat=1 fallback

**Session ID:** UUID efímero generado al inicio de sesión de app. Se regenera cada vez que la app se cierra y reabre.

**Cuándo es crítico:** cuando `is_lat=1` (usuario optó out de tracking):
- `rdid` presente pero NO debe usarse para targeting
- Sin frequency capping cross-session
- **Fallback:** GAM usa `sid` para frequency cap dentro de la sesión activa
- Limitación: si user cierra app y reabre → nuevo sid → cap se resetea

**Household problem:**
- 1 TV = 1 device ID = múltiples usuarios en el hogar
- Device ID NO es user-level, es device-level
- No hay cross-device tracking nativo en CTV
- Mitigación: viewing patterns como proxy, o login-based identification (ppid)

---

## 5. Consent signals (GDPR, COPPA)

**GDPR:**
- `gdpr=1` si usuario en EEE
- `gdpr_consent=<TC_STRING>` — TC String completo (TCF v2.2)
- TC String: empieza con CO/CP, ~100-200 chars, Base64 URL-safe
- Decodificar: https://iabtcf.com/#/decode
- Si TC String inválido o ausente → DSPs no pujan o solo non-personalized ads → CPM baja significativamente

**COPPA:**
- `coppa=1` si contenido dirigido a menores de 13 años
- Restricciones: no behavioral targeting, no frequency cap con device ID, no third-party ads

---

## 6. Content signals y metadata

**Via Content ID (MRSS):** `vid=CONTENT_ID&cmsid=CMS_ID`
- GAM enriquece con metadata pre-registrada

**Via cust_params:** `cust_params=genre%3Ddrama%26rating%3Dtv_ma`
- Límite: ~2000 chars en query string total
- Encoding: `=` → `%3D`, `&` → `%26`
- Anti-pattern: double encoding (`%253D` en vez de `%3D`)

**Via content category:** `cc=IAB1-6` (IAB taxonomy)
- Múltiples: `cc=IAB1-6,IAB17`

---

## 7. PPS y cust_params

**cust_params** son visibles en query string (logs, proxies). Para datos sensibles → Secure Signals.

**Best practices cust_params:**
- Normalizar valores: lowercase, no spaces, underscores
- 10-15 key-values máximo
- Cachear cálculos por sesión (daypart, etc.)
- Verificar encoding con herramienta de decode URL

---

## 8. Secure Signals

**Qué son:** señales encriptadas/ofuscadas que NO son visibles en URLs. Solo reveladas en bid stream a buyers autorizados.

**Configuración en GAM:** Admin > Secure Signals
- Definir señales
- Asignar buyers autorizados
- Configurar consent requirements

**Implementación:** NO existe un método público `setSecureSignals()` en IMA SDK como método estándar documentado. La integración se hace:
- Via signal providers (third-party adapters integrados en el SDK)
- Via configuración server-side en GAM
- Los detalles exactos de implementación dependen de la versión de GAM y SDK

**Testing:** señales son opacas (encriptadas). Validar via:
1. GAM admin: verificar signal definition activa
2. Test deal con buyer: buyer confirma visibilidad en bid request
3. Reporting indirecto: crear line item con targeting por señal

---

## 9. Buyer expectations en OpenRTB

Lo que DSPs esperan ver en bid request CTV:

| Campo OpenRTB | Mapeo desde VAST tag | Importancia |
|---|---|---|
| `device.ifa` | rdid | Crítico: frequency cap, attribution |
| `device.lmt` | is_lat | Crítico: privacy compliance |
| `device.ua` | User Agent | Alto: device identification, fraud detection |
| `device.ip` | IP del device | Alto: geo-targeting, fraud detection |
| `device.geo` | Derivado de IP | Alto: geographic targeting |
| `site.content.cat` | cc (IAB taxonomy) | Alto: categorical targeting |
| `site.content.language` | Del contenido | Medio: language targeting |
| `imp.video.w/h` | sz | Medio: creative selection |
| `imp.video.startdelay` | Posición (pre/mid/post) | Medio: positioning |
| `user.consent` | gdpr_consent | Crítico: GDPR compliance |
| `app.bundle` | msid | Alto: app verification |

**Señales ausentes → menor CPM:** DSPs pujan menos (o no pujan) si faltan señales clave como device ID, consent, o app bundle.
