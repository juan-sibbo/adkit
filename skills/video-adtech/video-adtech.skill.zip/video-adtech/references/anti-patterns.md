# Anti-patterns — Referencia extendida

Complementa los top-7 del SKILL.md core con anti-patterns adicionales por capa y plataforma.

---

## IMA SDK anti-patterns

| Anti-pattern | Síntoma | Causa | Solución |
|---|---|---|---|
| AdsManager reutilizado sin destroy() | Ads no reproducen, eventos no disparan | Leak de estado del AdsManager anterior | `destroy()` antes de crear nuevo AdsManager [Verificado] |
| AdDisplayContainer creado después de requestAds | Error de inicialización del SDK | SDK necesita container antes de request | Crear container en init, antes de cualquier request [Probable] |
| muted no declarado en autoplay (Tizen/webOS) | Browser/WebView bloquea reproducción | Política autoplay de Chrome/Safari engine | Declarar `vpa=auto&vpmute=0` o `vpmute=1` si muted [Verificado para web-based CTV] |
| PAL nonce reutilizado entre streams | Señales programáticas incorrectas | Nonce encapsula info del stream específico | Nuevo nonce por stream; reutilizable dentro del mismo [Probable] |
| Player intenta parsear VAST/construir tracking URLs | Lógica duplicada, tracking inconsistente | Confusión de responsabilidades Player vs SDK | Dejar que SDK gestione toda la lógica de ads |
| No implementar ContentPlayhead interface / implementarla con valor cacheado | Mid-rolls nunca disparan o se disparan tarde | SDK consulta `getCurrentTime()` ~4x/s; si retorna valor estático o cacheado, los cue points no se detectan | Implementar `getCurrentTime()` leyendo `videoElement.currentTime` directamente, no un valor actualizado por `timeupdate` [Probable] |
| Bloquear contenido en error de ad | Blank screen, user frustrado | App espera ad que nunca llega | SIEMPRE resume content en error; SDK auto-resume [Verificado] |

---

## VAST anti-patterns

| Anti-pattern | Síntoma | Causa | Solución |
|---|---|---|---|
| Wrapper chains >5 niveles | Timeout, error 302/303 | Cadena de redirects excesiva | Habilitar SSU; limitar maxRedirects a 3-5 [Verificado: IAB spec] |
| Correlator ausente | Ads no rotan, competitive exclusion no funciona | Sin correlator, GAM no puede deduplicar | Generar correlator (timestamp) al inicio de contenido [Verificado] |
| Correlator reutilizado entre contenidos | Competitive exclusion incorrecta entre contenidos | Mismo correlator = GAM cree que es mismo page view | Nuevo correlator por contenido |
| VPAID creative en CTV | Error 901, creative no renderiza | VPAID bloqueado en CTV | Solo VAST linear; verificar tipo de creative antes de servir |
| MediaFile solo HEVC | Playback falla en devices legacy | HEVC no soportado en Tizen <2017, etc. | Incluir siempre H.264 fallback |

---

## SSAI anti-patterns

| Anti-pattern | Síntoma | Causa | Solución |
|---|---|---|---|
| Beaconing client-side en SSAI sin SDK | Beacons no disparan | Player no sabe dónde están los ads en stream cosido | Server-side beaconing o integrar SDK DAI [Verificado] |
| SCTE-35 sin duración | Ad breaks sin control de timing | Marker marca inicio pero no duración | Incluir DURATION en SCTE-35 splice_insert |
| Ad creative sin transcodificar a formato del stream | Glitches, black frames, audio desync | Mismatch de codec/bitrate/sample rate | SSAI provider debe transcodificar al formato del stream |
| Sin house ads/slates en live | Dead air durante no-fill | No hay fallback cuando no hay demanda | Siempre tener slates/house ads disponibles para live |

---

## Señales e identidad anti-patterns

| Anti-pattern | Síntoma | Causa | Solución |
|---|---|---|---|
| rdid pasado como PPID | Confusión semántica, targeting incorrecto | Campos distintos: device vs publisher ID | Mantener separados [Verificado] |
| idtype hardcoded sin detectar plataforma | idtype incorrecto en algunas plataformas | Código no diferencia Samsung vs Fire TV vs Android TV | Detectar plataforma dinámicamente |
| is_lat siempre 0 (hardcoded) | Privacy violation, DSPs pueden bloquear | App ignora configuración del usuario | Leer valor real de la API del OS |
| Device ID cacheado indefinidamente | rdid stale después de que user lo resetea | App no refresca el ID | Obtener device ID fresh en cada sesión o al menos cada X horas |
| cust_params con double encoding | GAM no parsea key-values | `%253D` en vez de `%3D` | Encodear una sola vez |
| cust_params >2000 chars | URL truncada, params perdidos | Demasiados key-values o valores largos | Priorizar params; usar Content ID en vez de pasar todo |
| Consent string cacheada sin refresh | Consent expirado o cambiado por usuario | App no re-consulta CMP | Re-fetch consent en cada ad request o al menos cada 24h |
| app-ads.txt no publicado o inválido | DSPs bloquean inventario | Falta verificación de autorización | Publicar y validar con IAB crawler |

---

## Plataforma-específicos

### Samsung Tizen
| Anti-pattern | Síntoma | Causa |
|---|---|---|
| Asumir >1GB RAM disponible en Tizen 2.4 | OOM crash durante ad playback | Tizen 2.4 tiene ~512MB total; IMA+OM+creative buffer puede exceder |
| No desactivar OMID en Tier 3 | Performance degradada | OM SDK consume CPU/RAM significativos |
| WebView memory leaks no gestionados | App se vuelve lenta después de N ad breaks | WebView acumula memoria; hacer cleanup periódico |

### LG webOS
| Anti-pattern | Síntoma | Causa |
|---|---|---|
| Usar APIs de webOS sin verificar versión | API call falla silenciosamente | APIs cambian entre versiones de webOS |

### HbbTV
| Anti-pattern | Síntoma | Causa |
|---|---|---|
| localStorage asumido disponible | User ID y config fallan silenciosamente | No todos los perfiles HbbTV soportan localStorage |
| Timeout >5s | Viewer frustrado, broadcaster rechaza | CPU/RAM muy limitados en HbbTV |
| Muchos SSPs en Open Bidding | Latencia excesiva | Resources muy limitados; limitar a 1-2 SSPs |

---

## Diagnóstico por síntoma

| Síntoma | Primera hipótesis | Segunda hipótesis | Tercera hipótesis |
|---|---|---|---|
| No-fill (0 impresiones) | App no registrada/reclamada en GAM | app-ads.txt inválido | msid/store ID incorrecto |
| Fill bajo (<40%) | Señales incompletas (rdid, consent) | Floors demasiado altos | Over-segmentation de content bundles |
| Error rate alto (>5%) | Wrapper chains excesivas | MediaFile CDN con problemas | Creative codec incompatible |
| Latencia alta (>5s) | Open Bidding con demasiados SSPs | CDN de creative lejano | No SSU habilitado |
| VCR bajo (<80%) | Creative con buffering (bitrate excesivo) | VAST wrapper defectuoso | Audio/video desync |
| Mid-rolls no disparan | `ContentPlayhead.getCurrentTime()` retorna valor cacheado o no implementado | Ad Rules mal configuradas o cue points ausentes en MRSS | Player pausado o `AdsManager` no iniciado |
| Black screen | No-fill sin fallback/house ads | SSAI stitching failure | SCTE-35 markers ausentes |
| Discrepancia >15% | Filtro IVT del SSP | Timezone mismatch en reports | Tracking pixel bloqueado |
