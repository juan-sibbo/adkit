# SSAI / SGAI / DAI — Referencia técnica

## Tabla de contenidos
1. Tipos de ad insertion server-side
2. Beaconing: server-side vs client-side
3. SCTE-35 y señalización de ad breaks
4. Live vs VOD: diferencias operativas
5. Gap management y black screens
6. Google DAI: tipos de SDK
7. Diagnóstico de problemas SSAI

---

## 1. Tipos de ad insertion server-side

| Tipo | Descripción | Quién cose | Control de ad breaks |
|---|---|---|---|
| **SSAI (Server-Side Ad Insertion)** | Ads cosidos en el manifest/stream antes de llegar al device | SSAI provider (Yospace, AWS Elemental, etc.) | Publisher/ad server |
| **SGAI (Server-Guided Ad Insertion)** | Server prepara la decisión de ad pero el player ejecuta la inserción | Combinación server + player | Server guía, player ejecuta |
| **DAI (Dynamic Ad Insertion — Google)** | Servicio Google que gestiona stitching + tracking integrado con GAM | Google servers | GAM Ad Rules |

**Cuándo usar cada uno:**
- **CSAI (client-side)**: apps con IMA SDK, sin infraestructura server-side
- **SSAI**: live/FAST de alto volumen, devices sin soporte SDK, UX seamless
- **DAI Google**: ecosistema GAM completo, dispuesto a usar SDK DAI de Google

---

## 2. Beaconing: server-side vs client-side

**Client-side beaconing:**
- Player/SDK dispara tracking pixels directamente desde el device
- Requiere que el player/SDK sepa cuándo el ad está reproduciéndose
- **Problema en SSAI:** si el ad está cosido en el manifest, el player reproduce un stream continuo sin saber dónde empiezan/terminan los ads → beacons no se disparan [Verificado: por definición arquitectural]

**Server-side beaconing:**
- El SSAI provider dispara los tracking pixels desde sus servidores
- El provider sabe cuándo sirvió cada segmento de ad
- Cuartiles calculados por posición temporal del ad en el stream

**Beaconing con SDK DAI:**
- Google DAI SDK se integra en el player
- SDK recibe metadata del stream que indica posiciones de ad
- SDK dispara beacons client-side con datos del server
- Híbrido: precisión de client-side con la información del server

**Anti-pattern:** configurar beaconing client-side cuando se usa SSAI sin SDK → beacons no disparan.

---

## 3. SCTE-35 y señalización de ad breaks

**SCTE-35:** estándar ANSI para señalización de ad insertion opportunities en streams de broadcast/cable [Verificado].

**Tipos de mensajes SCTE-35 relevantes:**
- `splice_insert`: marca inicio/fin de ad break
- `time_signal` + segmentation descriptors: señala tipo de break (content, ad, chapter)

**En HLS:** SCTE-35 se transporta como tags `#EXT-X-DATERANGE` o `#EXT-X-CUE-OUT` / `#EXT-X-CUE-IN`.

**En DASH:** SCTE-35 se transporta en `EventStream` elements dentro del MPD.

**Diagnóstico de SCTE-35 ausente:**
- Síntoma: ad breaks no se insertan en live stream
- Verificar: manifest del stream → buscar markers SCTE-35
- Si ausentes: problema upstream (encoder/transcoder no está insertando markers)

---

## 4. Live vs VOD: diferencias operativas

| Aspecto | Live/FAST | VOD |
|---|---|---|
| Ad breaks | Síncronos, marcados por SCTE-35 o EPG | Dinámicos, basados en cue points o ad rules |
| Latency tolerance | Muy baja (≤2-3s) | Moderada (≤5s) |
| Fill priority | Crítico (no puede haber gap/silence) | Flexible (puede resumir sin ad) |
| Fallback | House ads obligatorios | Resume content aceptable |
| Manifest | Continuo, segmentos en tiempo real | Estático/semi-estático, pre-generado |
| Pod composition | Fija (duración determinada por SCTE-35) | Dinámica (GAM puede ajustar) |

---

## 5. Gap management y black screens

**Causas de black screen en SSAI:**
1. No-fill: no hay ad para el slot → gap en el stream
2. Timeout: ad decision demasiado lenta para live
3. Stitching failure: SSAI provider no puede coser el ad a tiempo
4. Manifest corruption: ad segments no correctamente insertados

**Mitigaciones:**
- Slates/bumpers: contenido de relleno (logo canal, "volvemos enseguida")
- House ads: siempre tener disponibles como fallback
- Slate de duración fija como backup (3-5s de branded content)
- Timeout agresivo en SSAI provider (response deadline antes del ad break)

**En VOD:** menos crítico — puede resumir contenido sin ad.
**En Live/FAST:** crítico — gap = "dead air" = peor UX posible.

---

## 6. Google DAI: tipos de SDK

| Tipo | Plataforma | Uso |
|---|---|---|
| DAI HTML5 SDK | Web, HbbTV, Tizen, webOS | Entornos JavaScript |
| DAI Android SDK | Android TV, Fire TV | Apps nativas Android |
| DAI iOS SDK | tvOS, Apple TV | Apps nativas iOS |
| DAI Cast SDK | Chromecast | Receiver apps |

**DAI vs IMA SDK (CSAI):**
- IMA SDK = CSAI (client decide y renderiza ads, separate del content)
- DAI SDK = SSAI asistido por SDK (stream cosido, SDK trackea)

---

## 7. Diagnóstico de problemas SSAI

| Síntoma | Verificar | Causa probable |
|---|---|---|
| Ads no se insertan | Manifest del stream → ¿hay ad segments? | SSAI provider no recibe ad response a tiempo |
| Beacons no disparan | ¿Beaconing es server-side o client-side? | Client-side beaconing en SSAI sin SDK |
| Black screen durante ad break | Manifest → ¿gap entre content y ad segments? | No-fill + sin slate/house ad |
| Ad se corta a mitad | Duración del ad vs duración del slot en manifest | Slot más corto que el ad; transcoding issue |
| Audio desync | Codec del ad vs codec del content stream | Mismatch de sample rate o codec de audio |
| Latencia alta en ad break | Tiempo entre SCTE-35 y primer frame de ad | SSAI provider tarda en resolver + coser |
